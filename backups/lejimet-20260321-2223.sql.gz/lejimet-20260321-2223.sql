--
-- PostgreSQL database dump
--

\restrict 7nuy2SeBmTWmezfPM5gg1MPVPuFLsFTJbbAdc4XykThMxDOVhBvlWYFxVX5rg1f

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: req_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.req_status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE public.req_status OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'agent',
    'team_lead',
    'division_manager',
    'sales_director',
    'admin'
);


ALTER TYPE public.user_role OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_limits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_limits (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    period text NOT NULL,
    max_amount numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_limits_period_check CHECK ((period = ANY (ARRAY['weekly'::text, 'monthly'::text])))
);


ALTER TABLE public.agent_limits OWNER TO postgres;

--
-- Name: agent_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_limits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_limits_id_seq OWNER TO postgres;

--
-- Name: agent_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_limits_id_seq OWNED BY public.agent_limits.id;


--
-- Name: approval_delegations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_delegations (
    id bigint NOT NULL,
    from_user_id integer NOT NULL,
    to_user_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    reason text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT no_self_delegation CHECK ((from_user_id <> to_user_id))
);


ALTER TABLE public.approval_delegations OWNER TO postgres;

--
-- Name: approval_delegations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approval_delegations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_delegations_id_seq OWNER TO postgres;

--
-- Name: approval_delegations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.approval_delegations_id_seq OWNED BY public.approval_delegations.id;


--
-- Name: approval_thresholds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_thresholds (
    id integer NOT NULL,
    key text NOT NULL,
    value numeric(12,2) NOT NULL,
    label text,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by integer
);


ALTER TABLE public.approval_thresholds OWNER TO postgres;

--
-- Name: approval_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approval_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_thresholds_id_seq OWNER TO postgres;

--
-- Name: approval_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.approval_thresholds_id_seq OWNED BY public.approval_thresholds.id;


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approvals (
    id integer NOT NULL,
    request_id integer,
    approver_id integer,
    approver_role public.user_role NOT NULL,
    action public.req_status NOT NULL,
    comment text,
    acted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.approvals OWNER TO postgres;

--
-- Name: approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approvals_id_seq OWNER TO postgres;

--
-- Name: approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.approvals_id_seq OWNED BY public.approvals.id;


--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    sell_price numeric(12,2) NOT NULL,
    barkod text,
    pb_sifra text
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    user_id integer,
    user_email text,
    action text NOT NULL,
    entity text,
    entity_id integer,
    detail jsonb,
    ip text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: buyer_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buyer_sites (
    id integer NOT NULL,
    buyer_id integer,
    site_code text NOT NULL,
    site_name text NOT NULL,
    pb_sifra_obj integer
);


ALTER TABLE public.buyer_sites OWNER TO postgres;

--
-- Name: buyer_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buyer_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.buyer_sites_id_seq OWNER TO postgres;

--
-- Name: buyer_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buyer_sites_id_seq OWNED BY public.buyer_sites.id;


--
-- Name: buyers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buyers (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    pb_sifra_kup text
);


ALTER TABLE public.buyers OWNER TO postgres;

--
-- Name: buyers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buyers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.buyers_id_seq OWNER TO postgres;

--
-- Name: buyers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buyers_id_seq OWNED BY public.buyers.id;


--
-- Name: divisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.divisions (
    id integer NOT NULL,
    name text NOT NULL,
    default_team_leader_id integer
);


ALTER TABLE public.divisions OWNER TO postgres;

--
-- Name: divisions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.divisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.divisions_id_seq OWNER TO postgres;

--
-- Name: divisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.divisions_id_seq OWNED BY public.divisions.id;


--
-- Name: ip_whitelist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ip_whitelist (
    id bigint NOT NULL,
    cidr text NOT NULL,
    label text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ip_whitelist OWNER TO postgres;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ip_whitelist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ip_whitelist_id_seq OWNER TO postgres;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ip_whitelist_id_seq OWNED BY public.ip_whitelist.id;


--
-- Name: known_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.known_devices (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    fingerprint text NOT NULL,
    ip text,
    label text,
    first_seen timestamp with time zone DEFAULT now(),
    last_seen timestamp with time zone DEFAULT now()
);


ALTER TABLE public.known_devices OWNER TO postgres;

--
-- Name: known_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.known_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.known_devices_id_seq OWNER TO postgres;

--
-- Name: known_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.known_devices_id_seq OWNED BY public.known_devices.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_tokens_id_seq OWNER TO postgres;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: report_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_runs (
    id bigint NOT NULL,
    period text NOT NULL,
    ran_at timestamp with time zone DEFAULT now(),
    status text DEFAULT 'ok'::text,
    detail jsonb
);


ALTER TABLE public.report_runs OWNER TO postgres;

--
-- Name: report_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.report_runs_id_seq OWNER TO postgres;

--
-- Name: report_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_runs_id_seq OWNED BY public.report_runs.id;


--
-- Name: request_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request_comments (
    id bigint NOT NULL,
    request_id integer NOT NULL,
    user_id integer NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    edited_at timestamp with time zone
);


ALTER TABLE public.request_comments OWNER TO postgres;

--
-- Name: request_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.request_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_comments_id_seq OWNER TO postgres;

--
-- Name: request_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.request_comments_id_seq OWNED BY public.request_comments.id;


--
-- Name: request_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request_items (
    id bigint NOT NULL,
    request_id integer NOT NULL,
    article_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    line_amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    barkod text,
    lot_kod text,
    cmimi_baze numeric(18,6),
    rabat_pct numeric(10,4),
    ddv_pct numeric(10,4),
    cmimi_pas_rabateve numeric(18,6),
    price_match_level text,
    sifra_kup text,
    sifra_obj integer,
    lejim_pct numeric(10,4)
);


ALTER TABLE public.request_items OWNER TO postgres;

--
-- Name: request_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.request_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_items_id_seq OWNER TO postgres;

--
-- Name: request_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.request_items_id_seq OWNED BY public.request_items.id;


--
-- Name: request_photos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request_photos (
    id bigint NOT NULL,
    request_id integer NOT NULL,
    url text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.request_photos OWNER TO postgres;

--
-- Name: request_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.request_photos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_photos_id_seq OWNER TO postgres;

--
-- Name: request_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.request_photos_id_seq OWNED BY public.request_photos.id;


--
-- Name: requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requests (
    id integer NOT NULL,
    agent_id integer,
    division_id integer,
    buyer_id integer,
    site_id integer,
    article_id integer,
    quantity integer DEFAULT 1,
    amount numeric(12,2) NOT NULL,
    invoice_ref text,
    reason text,
    status public.req_status DEFAULT 'pending'::public.req_status,
    required_role public.user_role NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    assigned_to_user_id integer,
    assigned_reason text,
    assigned_at timestamp with time zone,
    photo_url text
);


ALTER TABLE public.requests OWNER TO postgres;

--
-- Name: requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requests_id_seq OWNER TO postgres;

--
-- Name: requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.requests_id_seq OWNED BY public.requests.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    token_hash text NOT NULL,
    device_name text,
    ip text,
    user_agent text,
    last_active timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    revoked boolean DEFAULT false
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public.user_role NOT NULL,
    division_id integer,
    pda_number text,
    created_at timestamp with time zone DEFAULT now(),
    team_leader_id integer,
    last_login timestamp with time zone,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_verified boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: agent_limits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_limits ALTER COLUMN id SET DEFAULT nextval('public.agent_limits_id_seq'::regclass);


--
-- Name: approval_delegations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_delegations ALTER COLUMN id SET DEFAULT nextval('public.approval_delegations_id_seq'::regclass);


--
-- Name: approval_thresholds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_thresholds ALTER COLUMN id SET DEFAULT nextval('public.approval_thresholds_id_seq'::regclass);


--
-- Name: approvals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals ALTER COLUMN id SET DEFAULT nextval('public.approvals_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: buyer_sites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyer_sites ALTER COLUMN id SET DEFAULT nextval('public.buyer_sites_id_seq'::regclass);


--
-- Name: buyers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers ALTER COLUMN id SET DEFAULT nextval('public.buyers_id_seq'::regclass);


--
-- Name: divisions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions ALTER COLUMN id SET DEFAULT nextval('public.divisions_id_seq'::regclass);


--
-- Name: ip_whitelist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_whitelist ALTER COLUMN id SET DEFAULT nextval('public.ip_whitelist_id_seq'::regclass);


--
-- Name: known_devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.known_devices ALTER COLUMN id SET DEFAULT nextval('public.known_devices_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: report_runs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_runs ALTER COLUMN id SET DEFAULT nextval('public.report_runs_id_seq'::regclass);


--
-- Name: request_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_comments ALTER COLUMN id SET DEFAULT nextval('public.request_comments_id_seq'::regclass);


--
-- Name: request_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_items ALTER COLUMN id SET DEFAULT nextval('public.request_items_id_seq'::regclass);


--
-- Name: request_photos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_photos ALTER COLUMN id SET DEFAULT nextval('public.request_photos_id_seq'::regclass);


--
-- Name: requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests ALTER COLUMN id SET DEFAULT nextval('public.requests_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: agent_limits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_limits (id, user_id, period, max_amount, created_at, updated_at) FROM stdin;
2	5	weekly	123.00	2026-03-21 18:54:28.270223+00	2026-03-21 18:54:28.270223+00
\.


--
-- Data for Name: approval_delegations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_delegations (id, from_user_id, to_user_id, start_date, end_date, reason, active, created_at) FROM stdin;
\.


--
-- Data for Name: approval_thresholds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_thresholds (id, key, value, label, updated_at, updated_by) FROM stdin;
1	team_lead_max	99.00	Maksimumi p??r Team Lead (???)	2026-03-20 20:06:00.999554+00	\N
2	division_manager_max	199.00	Maksimumi p??r Division Manager (???)	2026-03-20 20:06:00.999554+00	\N
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approvals (id, request_id, approver_id, approver_role, action, comment, acted_at) FROM stdin;
1	3	2	team_lead	approved	gg	2026-03-20 22:58:26.557166+00
2	7	2	team_lead	approved	Asd	2026-03-21 11:18:26.183778+00
3	8	2	team_lead	approved	asd	2026-03-21 12:18:21.311348+00
4	9	2	team_lead	approved	asd	2026-03-21 12:41:02.287259+00
5	10	2	team_lead	approved	\N	2026-03-21 12:54:46.723656+00
6	11	2	team_lead	approved	\N	2026-03-21 17:08:14.844713+00
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (id, sku, name, sell_price, barkod, pb_sifra) FROM stdin;
1	JAM001	Jamnica Orange	1.20	\N	\N
2	MLK010	Milk 1L	0.89	\N	\N
42	AHM037	Ahmad Tea Jasmine Green Tea 6/(20x2g)	1.69	054881005654                                      	\N
3	1	1	0.00	\N	\N
43	AHM038	Ahmad Tea Raspberry&Pomegranate 6/(20x2g	1.69	054881012423                                      	\N
44	AHM039	Ahmad Tea Blackcurrant Burst 6/(20x2g)	1.69	054881007108                                      	\N
45	AHM040	Ahmad Tea Mango Magic 6/(20x2g)	1.69	054881006989                                      	\N
46	AHM041	Ahmad Tea Vanilla,Cinnamon&Apple6/(20x2g	1.69	054881028295                                      	\N
47	AHM042	Ahmad Tea Camomile,Honey&Vanilla6/(20x2g	2.19	054881017879                                      	\N
48	AHM043	Ahmad Tea Green Tea 12/(10x2g)	0.85	054881003162                                      	\N
49	AHM044	Ahmad Tea Mint Green Tea 12/(10x2g)	0.85	054881003193                                      	\N
51	AHM046	Ahmad Tea Strawberry Sensation 12/(10x2g	0.85	054881004312                                      	\N
52	AIA001	AIA Virshlle Wudy Family Classic 12/500g	1.66	8008110001803                                     	\N
53	AIA002	AIA Wudy Classic Party 240gvirshlle/ P12	1.19	8008110002503                                     	\N
54	AIA003	AIA Virshlle Wudy Classic Snack 35/100g	0.40	8008110002015                                     	\N
55	AIA004	AIA Virshlle Wudy Maxipack Classic 7/1kg	3.14	8008110037369                                     	\N
56	AIA005	AIA Virshlle Wudy me Djathë 25/150g	0.73	8008110002107                                     	\N
57	AIA006	AIA Virshlle Wudy Classic 15/250g	0.85	8008110002008                                     	\N
58	AIA007	AIA Sallam Wudy Pop 8/500g	1.45	8008110001049                                     	\N
59	AIA008	Gjoks Bibe të Pjekur Grand Aroma/Kg/	12.65	8005153511828                                     	\N
60	AIA009	Gjoks Pule e Pjekur/Kg/P1	11.56	8005153511996                                     	\N
61	AIA010	AIA Aequilibrium Gjoks Pule 14/145g	1.80	8008110034054                                     	\N
62	AIA011	AIA Aequilibrium Gjoks Gjeldeti 14/145g	1.70	8008110034115                                     	\N
63	AIA012	AIA Sallame gjeli 4.5kg/P1	0.07	\N	\N
64	AIA013	AIA Sallame pule 4.5kg/P1	0.07	\N	\N
65	AIA014	AIA Wudy Pop 500gr+VIRSHLE 100g GRATI/p8	1.39	d8008110001049                                    	\N
66	AIA015	Mushkeri qure A6534 /10kg /P1	10.22	3215648214232                                     	\N
6	AHM001	Ahmad Tea Beauty 6/(20x1.5g)	2.15	054881020398                                      	\N
7	AHM002	Ahmad Tea Digest 6/(20x2g)	2.15	054881020374                                      	\N
8	AHM003	Ahmad Tea Energy 6/(20x1.5g)	2.15	054881020367                                      	\N
9	AHM004	Ahmad Tea Immune 6/(20x1.5g)	2.15	054881020343                                      	\N
10	AHM005	Ahmad Tea Sleep 6/(20x1.5g)	2.15	054881020381                                      	\N
11	AHM006	Ahmad Tea Slim 6/(20x1.5g)	2.15	054881020350                                      	\N
12	AHM007	Ahmad Tea Kamomil Lemongras 6/(20x1.5g)	1.73	054881000062                                      	\N
13	AHM008	Ahmad Tea Detox 6/(20x2g)	1.73	054881013666                                      	\N
14	AHM009	Ahmad Tea Lemon Ginger 6/(20x2g)	1.73	054881000208                                      	\N
16	AHM011	Ahmad Tea Fruta te Perzier Citrus 6/(20x	1.73	054881000048                                      	\N
17	AHM012	Ahmad Tea Pepermin Lemon 6/(20x1.5g)	1.73	054881000024                                      	\N
18	AHM013	Ahmad Tea ?aj i Zi 24/(25x2g)	1.29	054881004794                                      	\N
19	AHM014	Ahmad Tea English Breakfast 24/(25x2g)	1.29	054881005906                                      	\N
20	AHM015	Ahmad Tea ?aj i Gjelbërt 24/(25x2g)	1.29	054881005890                                      	\N
21	AHM016	Ahmad Tea ?aj i Zi 6/(20x2g)	1.73	054881005630                                      	\N
22	AHM017	Ahmad Tea English Breakfast 6/(20x2g)	1.73	054881005555                                      	\N
23	AHM018	Ahmad Tea Çaj i Gjelbërt 6/(20x2g)	1.73	054881008945                                      	\N
24	AHM019	Ahmad Tea English Breakfast 12/(100x2g)	7.39	054881007924                                      	\N
25	AHM020	Ahmad Tea Çaj i Gjelbërt 12/(100x2g)	6.99	054881011952                                      	\N
26	AHM021	Ahmad Tea ?aj i Zi Gjethe 24/100g	2.15	054881005845                                      	\N
27	AHM022	Ahmad Tea English Breakfast Gjethe 24/10	2.15	054881007993                                      	\N
28	AHM023	Ahmad Tea ?aj i Gjelbërt Gjethe 24/100g	2.15	054881008020                                      	\N
29	AHM024	Ahmad Tea Rosehip&Hibiskus&Qershi 6/(20x	1.73	054881000031                                      	\N
30	AHM025	Ahmad Tea Ceylon 24/500g	6.79	54881005791                                       	\N
31	AHM026	Ahmad Tea Ceylon 12/250g	4.32	54881008921                                       	\N
32	AHM027	Ahmad Tea Decaff Evening Tea 6/(20x2g)	1.91	054881008471                                      	\N
33	AHM028	Ahmad Tea Decaff Black Tea 6/(20x2g)	2.11	054881025195                                      	\N
34	AHM029	Ahmad Tea Decaff Green Tea 6/(20x2g)	2.11	54881025225                                       	\N
35	AHM030	Ahmad tea Lemon Balm	0.00	\N	\N
36	AHM031	Ahmad Tea Mango & Orange	0.00	\N	\N
37	AHM032	Ahmad Tea Blueberry & Cinnamon	0.00	\N	\N
38	AHM033	Ahmad Tea Anise	0.00	\N	\N
39	AHM034	Ahmad Tea Tagged tb Forest Berries	0.00	\N	\N
40	AHM035	Ahmad Tea Caddy- Earl Grey 12x100g	3.99	054881006286                                      	\N
41	AHM036	Ahmad Tea Tagged t/b Earl Grey 24x25g	1.15	054881009690                                      	\N
104	AIA054	PROQ COPA DI ZIBELLO BOGX10	0.00	\N	\N
105	AIA055	S.DANIELLE SO KG	0.00	\N	\N
106	AIA056	Cordon bleu 245g AIA/P12	1.30	8008110258740                                     	\N
107	AIA057	AIA Sallam Wudy Pop 12/350g	1.08	8008110010133                                     	\N
108	AIA058	AIA Virshlle Wudy Supercmim 12/300g	1.15	\N	\N
110	AIA060	File pule e fresket AIA 550g/P8	4.23	8008110003036                                     	\N
111	AIA061	Pule e fresket Aia kg/P6	3.33	AIA061                                            	\N
112	AIA062	AIA Sallam Wudy Pop 500+350g 6/850g	1.39	3908920750722                                     	\N
113	AIA063	Pule e ngrire AIA 1.3kg P/7	3.45	8008110027636                                     	\N
114	AIA064	Proshute AIA	3.00	9031000014873                                     	\N
115	AIA065	AIA Sallam Wudy Pop 2x500g 4/1kg	1.30	3908920760158                                     	\N
116	AIA066	AIA Sallam Wudy Pop 2x350g 6/700g	1.04	3908920760165                                     	\N
117	AIA067	AIA Aequilibrium Rriska Gjeldeti 14/145g	1.50	8008110034726                                     	\N
118	AIA068	AIA Nuggets Pule 10/300g	2.49	8008110121006                                     	\N
119	AIA069	AIA Kotleta me Spinaq 9/300g	2.09	8008110132132                                     	\N
120	AIA070	AIA Kotleta Pule 9/280g	2.36	8008110110550                                     	\N
121	AIA071	AIA Fileto Cordon Bleu 9/240g	2.19	8008110131227                                     	\N
122	AIA072	PAVO Hotdog 35/100g	0.31	8004248002002                                     	\N
123	AIA073	PAVO Hotdog 37/1kg	2.51	8008110037277                                     	\N
124	AIA074	AIA Kebab Gjeldeti 10/300g	3.51	8008110030322                                     	\N
125	AIA075	AIA Krahë Pule Durango 6/600g	4.69	8008110100704                                     	\N
126	AIA076	AIA Shkopinjë Pule 12/220g	2.56	8008110034511                                     	\N
127	AIA077	AIA Nuggets Pule 10/260g	2.20	8008110100706                                     	\N
128	AIA078	AIA Virshlle Wudy Classic 15/300g	0.90	8008110040642                                     	\N
129	AIA079	AIA Virshlle Wudy Classic Snack 35/125g	0.52	8008110043230                                     	\N
130	AIA080	AIA Virshlle Wudy Supercmim 12/375g	1.52	3908920750272                                     	\N
131	AIA081	PAVO Virshlle Supercmim 12/300g	0.91	3908207710043                                     	\N
132	ALF001	KIHI Pite feta cheese	0.00	\N	\N
133	ALF002	KIHI Pite Spinach dhe Feta 800g	0.00	\N	\N
134	ALF003	ZAGORI KASSIATA ME FETA 650G	0.00	\N	\N
135	ALF004	ZAGORI ME CHESSE DHE SPINAXH 650 G	0.00	\N	\N
136	ALF005	PITE MINI TSALKOTA 700G	0.00	\N	\N
137	ALF006	PITE MINI TSALAKOTA 700G	0.00	\N	\N
68	AIA017	Nuggets copëza file pule 1kg A4748/P4	7.07	8008110101114                                     	\N
69	AIA018	Nuggets pule me domate 1kg A4751/P4	7.43	8008110101152                                     	\N
70	AIA019	Nuggets pule me proshtuë 960g A4752/P4	7.74	8008110101169                                     	\N
71	AIA020	Kofsha pule te ziera 1kg A5482/P5	6.19	8008110101138                                     	\N
73	AIA022	Kaqika pule me patate 1kg  A8077/P5	6.66	8008110103002                                     	\N
74	AIA023	Nuggets pule me limon 280g A8203/P9	2.27	AIA023                                            	\N
75	AIA024	Nuggets pule me domate 300g B7559/P10	2.50	8008110121006                                     	\N
76	AIA025	Pulë e plotë  Aia A2400/P1	3.72	\N	\N
77	AIA026	Virshlle Dakota Polo 360g/P10	1.86	8008110998103                                     	\N
78	AIA027	Kofsha pule A4776 Aia/P1	4.60	\N	\N
79	AIA028	File pule B2226 Aia/P1	7.95	\N	\N
80	AIA029	Kaqika pule B2306 Aia/P1	4.96	\N	\N
81	AIA030	AIA Virshlle Wudy Classic 3+1 gra.9/400g	0.89	3908920730540                                     	\N
82	AIA031	Mish pule i bardhë 400g B2834 Aia/P6	3.56	8008110260705                                     	\N
83	AIA032	Shpatull me kaqika pule B2771 Aia/P1	3.63	\N	\N
84	AIA033	Kaqika pule A2402 AIA/P1	5.15	\N	\N
85	AIA034	Nuggets salqiqe(virshlle) 210g/P12	0.00	\N	\N
86	AIA035	AIA Wudy Classic1kg+100g GRATIS virshlle	2.82	\N	\N
87	AIA036	AIA Wudy Snack Class.3x100g virshlle/P12	1.01	3908920730915                                     	\N
88	AIA037	Gjoks qure granpodere A4687 Aia/P1	8.15	2715864029088                                     	\N
89	AIA038	AIA Wudy Snack Classic 2x100g+ Abc djath	0.67	3908920730816                                     	\N
90	AIA039	Pule durango 1kg A4769/P4	7.22	8008110251017                                     	\N
91	AIA040	Virshlle Dakota Di Pollo 180g/P20	1.14	8008110557126                                     	\N
92	AIA041	Virshlle Wudy Bratwurst 360g/P10	2.19	8008110998127                                     	\N
93	AIA042	AIA Virshlle Wudy XXL 10/360g	1.39	8008110559830                                     	\N
94	AIA043	Wudy pop 1kg+2kg campionature	0.01	\N	\N
95	AIA044	Virshlle 100g 2+1 gratis/P12	0.00	\N	\N
96	AIA045	AIA Sallam Wudy Pop 5/1kg	2.15	8008110562335                                     	\N
97	AIA046	AIA Sallam Wudy 2kg/P2	3.82	8008110562311                                     	\N
98	AIA047	Nuggets  A5524 AIA	4.67	2855240008594                                     	\N
99	AIA048	Cordon bleu A5509 AIA	4.67	2858095010476                                     	\N
100	AIA049	SHISHQEBAP PAVANO AIA	3.81	2855242008615                                     	\N
101	AIA051	Virshlle Wudy me keqap 150g/P25	0.66	8008110002206                                     	\N
102	AIA052	NEGRONELLO	0.00	\N	\N
103	AIA053	BRQQ CULATELLO DI ZIBELLO	0.00	\N	\N
176	ALP019	Alpro Pije Tërshëre pa Sheqer 8/1L	2.31	5411188124689                                     	\N
177	ALP020	Alpro Pije Proteine me Çokollatë 8/1L	2.56	5411188130055                                     	\N
178	ALP021	Alpro Pije Bademi Barista 8/1L	2.31	5411188129899                                     	\N
179	ALT001	ADA382-Gota Whisky 300cc 6/1/P8	3.81	8692952074592                                     	\N
180	ALT002	ADR05-Gota uji  190cc 6/1/P8	2.78	8692952006012                                     	\N
181	ALT003	ADR15-Gota Whisky 290cc 6/1/P8	3.04	8692952001895                                     	\N
182	ALT004	ARA218-Gota uji 200cc 6/1/P8	2.59	8692952006531                                     	\N
183	ALT005	ARA263-Gota te Gjata 300cc 6/1/P8	3.41	8692952065118                                     	\N
184	ALT006	ARA265-Gota te Gjata 360cc 6/1/P8-DK0497	3.57	8692952013218                                     	\N
185	ALT007	ARG62- Ene per sheqer 100mm 6/1/P8	2.27	8692952004315                                     	\N
186	ALT008	ARS05-Gota Whisky 195cc 6/1/P8	2.93	8692952004148                                     	\N
187	ALT009	ARS15-Gota Whisky 305cc 6/1/P8	3.22	8692952004155                                     	\N
188	ALT010	ARY523-Gota Wine 24cc 6/1/P4	5.69	8692952078439                                     	\N
189	ALT011	ATM321-Gota Uji/P48	0.54	8692952005916                                     	\N
190	ALT012	AZN10-Gota uji 240cc 6/1/P8	2.73	8692952003172                                     	\N
191	ALT013	BUR63-Ene per perime 125mm 6/1/P8	2.38	8692952003288                                     	\N
192	ALT014	BUR69-Ene per perime 230 1/1/P6	2.71	8692952003646                                     	\N
193	ALT015	CRE367-Filxhan ICE CREAM190 6/1/P6	4.34	8692952065170                                     	\N
194	ALT016	DEF244-Ene per perime 230mm 2/1/P12	1.22	8692952064791                                     	\N
195	ALT017	DEF255-Ene per perime 400cc 2/1/P12	1.75	8692952061370                                     	\N
196	ALT018	DEF267-Mbajtese per perime 2/1/P12	2.07	8692952064777                                     	\N
197	ALT019	DIA05-Gota uji 215cc 6/1/P8	2.60	8692952000348                                     	\N
198	ALT020	ELG305-Gota elastike 215cc/Pako72	0.37	8692952001123                                     	\N
139	ALF008	ROLLS MINI SPINACH AND FETA CHEESE 500G	0.00	\N	\N
140	ALF009	BOUGATSA SWEET CREAM PIE 800G	0.00	\N	\N
141	ALF010	BOUGATS ME VANILLA CREAM	0.00	\N	\N
143	ALK002	Liker Kruskovac 25%  0.7L Maraska/P6	6.92	3850158403102                                     	\N
144	ALK003	Liker bimor Pelinkovac 28% 1L Lagana/P6	7.81	3850158406752                                     	\N
145	ALK004	Liker bimor Pelinkovac 28% 1L Retro/P6	8.11	3850158406806                                     	\N
146	ALK005	Liker MARASCHINO 32% 1L Maraska/P6	10.14	3850158404703                                     	\N
147	ALK006	Liker prej mjalte Medica 24% 1L Marsk/P6	8.76	3850158202255                                     	\N
148	ALK007	Vodkë Cosmopolitan 37.5% 1L Maraska/P6	7.10	3850158409005                                     	\N
149	ALK008	Vodkë Cosmopolitan 37.5% 0.7L Marska/P6	5.45	3850158409203                                     	\N
150	ALK009	Raki Kumbulle Sljiovica 40% 1L Marask/P6	12.03	3850158301705                                     	\N
151	ALK010	Raki Kumbulle Sljiovica 40% 0.7L Mara/P6	9.44	3850158301002                                     	\N
152	ALK011	Pije alkool.Travarica 37.5% 1L Marka/P6	8.27	3850158302009                                     	\N
153	ALK012	Shurup frutash Amarena 1L Maraska/P6	2.99	3850158102708                                     	\N
154	ALK013	Shurup Boronicë,mollë 1L Maraska/P6	2.92	3850158102722                                     	\N
155	ALK014	Shurup Portokalli 1L Maraska/P6	2.51	3850158102869                                     	\N
156	ALK015	Shirup vishnje Amarena Premium 0.75L/P6	5.84	3850158100162                                     	\N
157	ALK016	Lëng Boronicë,rrush i zi,mollë 1L Marask	1.37	3850158601485                                     	\N
158	ALP001	Alpro Pije Soje Origjinal 8/1L	1.89	5411188543381                                     	\N
159	ALP002	Alpro Pije Soje Pa Sheqer 8/1L	2.02	5411188543398                                     	\N
160	ALP003	Alpro Pije Soje me Çokollatë 8/1L	2.31	5411188300328                                     	\N
161	ALP004	Alpro Pije Soje me Vanille 8/1L	2.31	5411188081852                                     	\N
162	ALP005	Alpro pije Soje me Cokollate 250ml/P27	0.57	5411188082637                                     	\N
163	ALP006	Alpro pije Soje me Vanille 250ml/P27	0.57	5411188082620                                     	\N
164	ALP007	Alpro Pije Bademi me Sheqer 8/1L	2.32	5411188110835                                     	\N
165	ALP008	Alpro Pije Kokosi me Oriz  8/1L	2.31	5411188116592                                     	\N
167	ALP010	Alpro pije Tërshëre Original 1l/P8	2.00	5411188115366                                     	\N
168	ALP011	Alpro Desert Soje me Vanille 6/4x125g	2.07	54051140                                          	\N
169	ALP012	Alpro Desert Soje me Çokollatë 6/4x125g	2.07	54051157                                          	\N
170	ALP013	Alpro Desert Soje me Çoko.Zezë 6/4x125g	2.07	5411188094159                                     	\N
171	ALP014	Alpro pije me Cokollate dhe Kokos 1l /P8	2.31	5411188119074                                     	\N
172	ALP015	Alpro Pije Bademi pa Sheqer 8/1L	2.31	5411188112709                                     	\N
173	ALP016	Alpro Pije Bademi dhe Kokosi 8/1L	2.31	5411188118732                                     	\N
174	ALP017	Alpro pije me Lajthi 1l/P8	2.20	5411188110842                                     	\N
175	ALP018	Pije kokosi pa sheqer Alpro 1l/P8	2.00	5411188128311                                     	\N
238	ALT060	Altanlar-Tenxhere Set 1/7/P1	27.38	3214563214568                                     	\N
239	ALT061	Altanlar-Tenxhere Set Solingen 1/9/P1	45.71	8693412081563                                     	\N
240	ALT062	Altanlar-Tenxhere Expreks 3.5LT 4/1/P4	16.43	8697414823794                                     	\N
242	ALT064	Altanlar- Perfect Tava 12x5/Pako 12	6.74	8697414829482                                     	\N
243	ALT065	Altanlar-Perfect Tenxhere 14x8/Pako 8	9.16	8697414829499                                     	\N
244	ALT066	Altanlar-Fërtere Erez 16cm/Pako 12	4.32	8697414826870                                     	\N
245	ALT067	Altanlar-Gjygyma qaji  te vegjel d.plast	12.32	8699349300289                                     	\N
246	ALT068	Altanlar-Gjygyma qaji te mesem d.plast 8	13.69	8699349300272                                     	\N
247	ALT069	Altanlar-Gjygyma qaji te medhenj d.plast	14.64	8699349300265                                     	\N
248	ALT070	Altanlar-Gjygyma qaji te vegjel d.metali	13.69	8693999999992                                     	\N
249	ALT071	Altanlar-Gjygyma qaji te mesem d.metalik	14.64	8693988888887                                     	\N
250	ALT072	Altanlar-Gjygyma qaji  te medhenj d.meta	15.69	8693977777772                                     	\N
251	ALT073	30011-Gota Qaji 90cc 6/1/P12	1.20	8692952002922                                     	\N
252	ALT074	30012-Gota Qaji90cc 12/1/P6	2.27	8692952015793                                     	\N
253	ALT075	30030 OPT-Gota Qaji95cc 6/1/P12	1.52	8692952000171                                     	\N
254	ALT076	SED312- Gota Qaji82cc 6/1/P12	1.75	8692952001406                                     	\N
255	ALT077	30020 OPT-Gota Qaji115cc 6/1/P12	1.52	8692952000263                                     	\N
256	ALT078	ASN314-Gota Qaji/125cc 6/1/P12	2.72	8692952058875                                     	\N
257	ALT079	DIV317-Gota Qaji 140cc 6/1/P8	3.50	8692952053801                                     	\N
258	ALT080	ZEN313-Gota Qaji155cc 6/1/P8	2.84	8692952057090                                     	\N
259	ALT081	20020-Tablla Qaji 6/1/P12	1.52	8692952059964                                     	\N
518	ANM046	SPONTEX Litar rrobash 20m 0105 10/1	1.23	\N	\N
201	ALT023	ELT05-Gota Uji 315cc/Pako 48	0.48	8692952001291                                     	\N
202	ALT024	ELT15-Gota Whisky 320cc 6/1/P8	2.91	8692952001307                                     	\N
203	ALT025	FST593-Gota Koktelli 320ccn 6/1/P4	5.53	8692952044120                                     	\N
204	ALT026	GLO325-Gota Soft Drink 300cc 6/1/P8	2.78	8692952061394                                     	\N
205	ALT027	KAR70-Shpuzore e vogel  Atlantar 2/1/P24	0.75	8692952003950                                     	\N
206	ALT028	KAR72-Shpuzore e madhe Ashtary 2/1/P24	1.09	8692952003226                                     	\N
207	ALT029	LAL354-Gota Uji 240cc 6/1/P24	2.97	8692952065231                                     	\N
208	ALT030	LAL358-Gota Soft drink 290cc/Pako 48	0.63	8692952060526                                     	\N
209	ALT031	LAL569-Gota Wine&Uji 330cc 6/1/P4	4.93	8692952052118                                     	\N
211	ALT033	MAR326-Gota elastike80cc 6/1/P12	1.90	8692952063879                                     	\N
212	ALT034	MAR336-Gota Uji190cc 6/1/P8	2.91	8692952062926                                     	\N
213	ALT035	MAR350-Gota Whisky305cc 6/1/P8	3.22	8692952062797                                     	\N
214	ALT036	NAR381-Filxhan Ice Cream285cc 6/1/P6	4.36	8692952065040                                     	\N
215	ALT037	NEC346-Gota Soft Drink215cc 6/1/P8	3.04	8692952043246                                     	\N
216	ALT038	POM566-Gota Wine285cc 6/1/P4	5.31	8692952065354                                     	\N
217	ALT039	POM575-Gota Uji-Ven370cc 6/1/P4	6.07	8692952065378                                     	\N
218	ALT040	PRG332-Gota Soft Drink 155cc 6/1/P24	3.22	8692952071881                                     	\N
219	ALT041	RST556-Gota Wine245cc 6/1/P4	4.74	8692952056543                                     	\N
220	ALT042	SUD15-Gota Whisky315cc 6/1/P8	2.65	8692952073731                                     	\N
221	ALT043	TAL333OPT-Gota Soft Drink200cc 6/1/P48	0.56	8692952013935                                     	\N
222	ALT044	TEO347-Gota Soft Drink210cc 6/1/P8	3.04	8692952048296                                     	\N
223	ALT045	TRU248-Ene te vogla 105mm 6/1/P8	3.04	8692952014758                                     	\N
224	ALT046	TRU264-Ene te vogla 120mm 6/1/P8	3.22	8692952014765                                     	\N
225	ALT047	TRU338-Gota Whisky280cc 6/1/P8	3.35	8692952073984                                     	\N
226	ALT048	TUA05-Gota Uji 200cc 6/1/P8	3.04	8692952001260                                     	\N
227	ALT049	TUA15-Gota Whisky320cc 6/1/P8	3.22	8692952001277                                     	\N
228	ALT050	VEN553-Gota Wine245cc 6/1/P4	4.34	8692952056642                                     	\N
229	ALT051	VIR245-Ene per kikirika 220cc 6/1/P8	2.91	8692952078736                                     	\N
230	ALT052	VIR261-Ene per kikirika 310cc 6/1/P8	3.22	8692952064043                                     	\N
231	ALT053	Altanlar-Torba Tregu 3 colors/Pako 6	9.69	8699349540050                                     	\N
232	ALT054	Altanlar Tavilona per Hekurosje/Pako 2	17.38	\N	\N
233	ALT055	Altanlar Tenxhere 18x10 3lloj 4/1 /Pako4	7.36	8697004821896                                     	\N
234	ALT056	Altanlar Tenxhere 26x16 4/1 /Pako4	15.27	8697004821889                                     	\N
235	ALT057	Altanlar-Tenxhere 34x23 2/1 /Pako 2	32.85	8697004821940                                     	\N
236	ALT058	Altanlar-Tenxhere 38x25 2/1/Pako2	39.29	8697004821964                                     	\N
297	ALT119	NEV533-Gota Leon 200cc 6/1/P4	4.80	8692952005596                                     	\N
298	ALT120	Gota Qaji 6/1+Tablla qaji 6/1/Pako1	3.05	3908920730908                                     	\N
299	ALT121	STR01MG00-Filxhana te medhenj 12/1/P1	18.48	8691850409864                                     	\N
300	ALT122	XT21DU00-Pjata sallate te vogla 12/1/P1	18.17	8691850420951                                     	\N
301	ALT123	XT27DU00-Pjata sallate pocelan 12/1/P1	27.36	8691850421071                                     	\N
302	ALT124	LIZ01TZ00-Krypore Porcelan24/1/P1	42.23	8691850422283                                     	\N
303	ALT125	STR15KK00-Ene per supe porcelan 12/1/P1	1.58	3908920730618                                     	\N
304	ALT126	MRS011DM00-Qajnik i vogel porcelan 6/1/P	48.22	3908920730625                                     	\N
305	ALT127	XT22CK00-Pjata ushqimi 12/1/P1	18.79	8691850421057                                     	\N
306	ALT128	ELS01TZ00-Krypore Porcelan 24/1/P1	42.23	160514                                            	\N
307	ALT129	LIZ07PC00-Mbajtese palloma 12/1	30.97	150427                                            	\N
309	ALT131	GR07PC00-Mbajtese pallomave 12/1/P12	2.40	3908920730571                                     	\N
310	ALT132	FLZ215-Gota Uji 6/1/P8	1.75	8692952050503                                     	\N
311	ALT133	FR0378-Gota per akullore 6/1/P4	4.81	8692952049651                                     	\N
312	ALT134	KLB221-Gota Uji 6/1/P8	1.75	8692952079368                                     	\N
313	ALT135	MEV220-Gota Uji 6/1/P8	1.75	8692952065293                                     	\N
314	ALT136	XT17DU00-Pjata sallate te vogla 12/1/P1	15.80	8691850421477                                     	\N
315	ALT137	ELS01BR00-Krypore 24/1/P1	42.23	150514                                            	\N
316	ALT138	K007PC00-Mbajtese pallomave porcealn 12/	28.81	150522                                            	\N
317	ALT139	LIZ01BR00-Krypore 24/1/P1	42.23	8691850422290                                     	\N
318	ALT140	EOO1SU00-Bokall porcelan i vogel 6/1/P6	4.65	3908920730687                                     	\N
319	ALT143	LNA352-Gota viski 3/1/P16	2.13	8692952118173                                     	\N
320	ALT144	RNG349-Gota Viski 6/1/P8	4.93	8692952101052                                     	\N
321	ALT145	A-126-Tavoline per hekurosje	17.66	1000000000000                                     	\N
261	ALT083	DIV278-Tablla Qaji/1/6/Pako 72	0.37	8692952045684                                     	\N
262	ALT084	ASN274-Tablla  Qaji/1/6/Pako72	1.80	8692952060588                                     	\N
263	ALT085	Tharese per Rroba Altanlar/Pako 5	11.42	8699349540012                                     	\N
264	ALT086	TAL357OPT-Gota Uji 230cc 6/1/P8	3.60	8692952015014                                     	\N
265	ALT087	20023-Tablla qaji 12/1/P6	2.41	8692952090646                                     	\N
266	ALT088	22010-Gota uji 6/1/P8	1.70	8692952000232                                     	\N
267	ALT089	ADA348-Gota viski 3/1/P16	2.62	8692952083099                                     	\N
268	ALT090	ADA382DT-Viski bardak 1/3/P16	2.72	8692952083471                                     	\N
269	ALT091	DIA15-Gota viski 6/1/P8	3.10	8692952000324                                     	\N
270	ALT092	EMP541-Gota viski 6/1/P4	3.99	8692952055430                                     	\N
271	ALT093	EMP568-Gota uji 1/6/P24	0.71	8692952055478                                     	\N
272	ALT094	FAM259-Ene transpa.per sallate 6/1/P8	3.54	8692952092435                                     	\N
273	ALT095	FAM294-Ene te medha per sallat 1/1 /P6	2.98	8692952093081                                     	\N
274	ALT096	HSR274-Tablla qaji 1/6/P72	0.40	8692952090660                                     	\N
275	ALT097	KLB266-Gota uji 6/1/P8-DK0222	3.54	8692952091797                                     	\N
276	ALT098	KYF70-Shpuzore e vogel 2/1/P24	0.75	8692952003844                                     	\N
278	ALT100	LAL592-Gota viski 6/1/P4	5.95	8692952066320                                     	\N
279	ALT101	LIZS1-Filxhana transp.tablla 12/1/P6	6.80	8692952013478                                     	\N
280	ALT102	MIS549-GY031GF-Gota qelqi 6/1/P4	7.21	8692952075407                                     	\N
281	ALT103	MIS549-AY016AF-Gota qelqi 6/1/P4	7.71	8692952014000                                     	\N
282	ALT104	MIS549-GY099GF-Gota qelqi 1/6/P4	1.34	8692952080722                                     	\N
283	ALT105	MIS568-Gots uji 6/1/P4	4.68	8692952055553                                     	\N
284	ALT106	ARY559-Gota uji 6/1/P4	10.72	8692952078477                                     	\N
285	ALT107	NEV576-Gota viski 1/6/P24	0.73	8692952013720                                     	\N
286	ALT108	ARA233-Gota uji 6/1/P8	3.16	8692952013195                                     	\N
287	ALT109	RNG363-Gota uji 6/1/P8	4.74	8692952092497                                     	\N
288	ALT110	RNG395-Gota viski 6/1/P8	4.68	8692952092534                                     	\N
289	ALT111	ROM403-Filxhan i vogel 6/1/P12	2.65	8692952093142                                     	\N
290	ALT112	SDF216-Gota uji 6/1/P8	1.75	8692952065415                                     	\N
291	ALT113	SRG375-Gote birre 6/1/P4	4.46	8692952072703                                     	\N
292	ALT114	TEO351-Gota uji 6/1/P8	3.28	8692952048340                                     	\N
293	ALT115	VEN541-Gota uji 6/1/P4	5.31	8692952056628                                     	\N
294	ALT116	VIR205-Reçelik 6/1/P12	2.35	8692952091513                                     	\N
295	ALT117	VIR281-Ene transp.per sallate 2/1/P6	3.72	8692952091537                                     	\N
296	ALT118	VIR291-Ene transp.per sallate 1/1/P6	2.44	8692952064067                                     	\N
360	ALU030	Ene alumini 940ml, 218x113x54mm 20/1/P8	4.12	9001376110837                                     	\N
362	ALU032	Ene alumini 900ml, 219x158x38mm 20/1/P10	4.98	9001376110851                                     	\N
363	ALU033	Ene alumini 2380ml, 318x214x39mm 20/1/P4	9.41	9001376110868                                     	\N
364	ALU034	FIXBOX Shpuzore/P16	2.24	9001376110127                                     	\N
365	ALU035	FIXBOX shpuzore e rrumbullaket/P30	2.57	9001376110882                                     	\N
366	ALU036	Tabakë per servim 4/1 333x233mm/P25	1.91	9001376088822                                     	\N
367	ALU037	Tabakë per servim 2/1 445x295mm/P25	1.92	9001376088839                                     	\N
369	ALU039	Qese per pjekje 25*55/P20	0.66	9001376106779                                     	\N
370	ALU040	Leter per pjekje 40*60cm 500/1/P1	24.82	9001376097343                                     	\N
371	ALU041	Foli ngjitese Polyfix 30m Alu Fix/P30	0.01	9008438117698                                     	\N
372	ALU042	Leter per pjekje 200m*50cm/P6	21.18	9001376777603                                     	\N
373	AMR001	Grissini Classico 125gr/P18	0.82	\N	\N
374	AMR002	Grissini Rosmarino 125gr/P18	0.82	\N	\N
375	AMR003	Grissini Pizza 125gr/P18	0.82	\N	\N
376	AMR004	Grissini Sesamo 125gr/P18	0.82	\N	\N
377	and001	Oriz Andrea 1kg Vakum/Pako6	0.00	3903515240015                                     	\N
378	and002	Frutto Vishnje 25gr Sadet/Pako20	0.00	3906015320140                                     	\N
379	and003	Frutto Dredhz 25gr Sadet/Pako20	0.00	3906015320164                                     	\N
380	and004	Frutto Malin 25gr Sadet/Pako20	0.00	3906015320157                                     	\N
381	and005	Frutto Orange 25gr Sadet/Pako20	0.00	3906015320133                                     	\N
382	and006	Fresh Smile Spearmint 14gr/Pako24	0.00	8693323373207                                     	\N
383	and007	Fresh Smile Pepermint 14gr/Pako24	0.00	8693323375201                                     	\N
323	ALT147	M-277-Tunca tharese e rrobave	9.80	6423154001480                                     	\N
324	ALT148	Gjygyma qaji te vegjel d.plast.Papatyam	12.32	8699349300258                                     	\N
325	ALT149	Gjygyma qaji te mesme d.plast.Papatyam	13.69	8699349300241                                     	\N
326	ALT150	Gjygyma qaji te medha d.plast.Papatyam	14.64	8699349300234                                     	\N
327	ALT151	Gjygyma qaji te vegjel d.metal.Papatyam	13.69	8699349300470                                     	\N
328	ALT152	Gjygyma qaji te mesme d.metal.Papatyam	14.64	8699349300487                                     	\N
329	ALT153	Gjygyma qaji te medha d.metal.Papatyam	15.69	8699349300494                                     	\N
330	ALT154	LNA352-Gota uji 6/1/P8	0.00	8692952118012                                     	\N
331	ALU001	Folie alumini paketim ekonomik 10m, 30cm	0.71	9001376113197                                     	\N
335	ALU005	Folie ngjitese Polyfix 50m, 30cm	0.99	9008438009252                                     	\N
336	ALU006	Qese per pjekje 25*38cm 8/1/P20	0.66	9001376901008                                     	\N
338	ALU008	Leter per pjekje 40*60cm 500/1/P500	0.05	\N	\N
339	ALU009	Leter per pjekje Polyfix 6m/P30	0.70	9008438009269                                     	\N
340	ALU010	Leter per pjekje per pajisje elektrike 3	2.86	9001376020754                                     	\N
341	ALU011	Leter per pjekje dhe fergim 33*32cm, 100	3.35	9001376021324                                     	\N
342	ALU012	Leter per pjekje 33*42cm, 100 letra	4.05	9001376021331                                     	\N
343	ALU013	Leter per pjekje 33*53cm, 100 letra/P12	4.86	9001376021348                                     	\N
344	ALU014	Ene alumini 110ml 50/1/P10	4.23	9001376110592                                     	\N
345	ALU015	Ene alumini 157ml 50/1/P9	4.24	9001376110615                                     	\N
346	ALU016	Ene per pjekje ne forme rrethu 285mm 20/	4.99	9001376110622                                     	\N
347	ALU017	Ene alumini 540ml, 189x86x50mm 25/1/P8	4.48	9001376110639                                     	\N
348	ALU018	Ene alumini1090ml, 233x108x60mm 25/1/P14	5.06	9001376110646                                     	\N
349	ALU019	Ene alumini 3/4kg 230*100*58mm/P8	5.38	9001376110653                                     	\N
350	ALU020	Ene alumini 1125ml, 225x175x35mm/P12	6.67	9001376110660                                     	\N
351	ALU021	Ene alumi 400+550ml, 227x177x38mm 25/1/P	7.45	9001376110721                                     	\N
352	ALU022	Ene alumi 220+160+380ml, 227x177x30mm 25	7.45	9001376110738                                     	\N
353	ALU023	Ene alumini 2750ml, 273x225x76mm 3/1/P8	1.73	9001376110745                                     	\N
354	ALU024	Ene alumini 3150ml, 368x247x48mm 3/1/P7	3.70	9001376110783                                     	\N
355	ALU025	Ene alumini 5200ml, 527x326x37mm 3/1/P12	4.46	9001376110776                                     	\N
356	ALU026	Ene alumini 3610ml, 323x262x55mm 4/1/P20	2.31	9001376110769                                     	\N
358	ALU028	Ene alumini 470ml, 145x120x40mm 20/1/P12	2.74	9001376110790                                     	\N
359	ALU029	Ene alumini 650ml 224x132x34mm 20/1/P10	3.87	9001376110820                                     	\N
361	ALU031	Ene alumin 1520ml, 250x134x70mm 20/1/P10	6.66	9001376110844                                     	\N
417	ANL003	Choco LEJTHI 220g/P12 LEXUS	2.42	8699462600860                                     	\N
418	ANL004	Choco LAJTHI  500g/P12 LEXUS	3.20	8699462600488                                     	\N
419	ANL005	Choco DREDHEZ 500g/P12 LEXUS	3.20	8699462600969                                     	\N
420	ANL006	Choco KOKOS 500g Lexus/P12	3.20	8699462600990                                     	\N
421	ANL007	Choco KAFE  500g/P12 LEXUS	3.20	8699462601997                                     	\N
422	ANL008	Choco QERSHI  500g/P12 LEXUS	3.20	8699462600976                                     	\N
423	ANL009	Choco PORTOKALL  500g/P12 LEXUS	3.20	8699462600983                                     	\N
439	ANL025	Choco LAJTHI 500g KUTI  /P12 LEXUS	3.20	8699462600884                                     	\N
442	ANL028	Chocolate 18g MY CHICK /P36x10	0.11	8699462601898                                     	\N
426	ANL012	Kinder ve 25g CRAZY FRUIT/P24x6	0.21	8699462604165                                     	\N
427	ANL013	Kinder ve 25g SPACE/P24x6	0.21	8699462604189                                     	\N
428	ANL014	Kinder ve 25gr MY CHICK /P24x6	0.21	8699462604202                                     	\N
429	ANL015	Kinder ve SUPER RACE 25gr P24x6	0.21	8699462604226                                     	\N
432	ANL018	Kinder top CRAZY GIRLS  30gr /P24x6	0.26	8699462606084                                     	\N
436	ANL022	Kinder ve ICE TEAM 60gr /P24x3	0.52	8699462607234                                     	\N
438	ANL024	Kinder ve 60g Magic ALADIN/P24x3	0.52	8699462607210                                     	\N
446	ANL032	Kinder Ve 25g CARS/P24x6	0.21	8699462604790                                     	\N
447	ANL033	Kinder Ve 25g CHOCO STARS/P24x6	0.21	8699462604813                                     	\N
414	ANE001	Thase per dhurata Anea D11	0.70	6923913504318                                     	\N
424	ANL010	Kinder ve HEROS 25gr  /P24x6	0.21	8699462604240                                     	\N
425	ANL011	Kinder ve 25g SAFARI/P24x6	0.21	8699462604141                                     	\N
431	ANL017	Kinder top SUPER TRUTLES 34gr/P24x6	0.26	\N	\N
434	ANL020	Kinder ve 60g DINOS/P24x3	0.52	8699462607173                                     	\N
437	ANL023	Kinder ve SAFARI 60gr /P24x3	0.52	8699462607159                                     	\N
440	ANL026	Kinder ve DINO EGGS  115gr(4x9)/P36	0.99	8699462609009                                     	\N
445	ANL031	Kinder ve  ANIMAL WORLD 25g /P24x6	0.21	8699462604769                                     	\N
385	and009	Muchmallow lajthi 105gr/Pako24	0.00	8600114005391                                     	\N
412	and039	Kupa 900gr Dauti/Pako10	0.00	5319990612878                                     	\N
391	and015	Akullore Vanill 75gr Eskimko/Pako30	0.00	8607100567802                                     	\N
392	and016	Akullore Cokollad 75gr Eskimko/Pako30	0.00	8607100567796                                     	\N
394	and018	Akullore Lajthi 75gr Eskimko/Pako30	0.00	8606015710266                                     	\N
395	and019	Shkum per Rroje Arko 200ml/Pako6	0.00	8690506395926                                     	\N
396	and020	Shkum per Rroje Arko 200ml Cool/Pako6	0.00	8690506090029                                     	\N
397	and021	Meshavina 360gr/Pako12	0.00	8601900603326                                     	\N
398	and022	MEGAMAX Zbutes per Rroba 1L/Pako12	0.00	3838966205682                                     	\N
399	and023	MEGAMAX Zbutes per Rroba 1L Sumer/Pako12	0.00	3838966205675                                     	\N
400	and024	Kofsh Me Kaqik 15Kg/Pako1	0.00	3211233211232                                     	\N
413	and041	Keks Qaji me Qokollad 250gr/Pako15	0.00	8600939841198                                     	\N
433	ANL019	Kinder ve 60g BUNDY/P24x3	0.52	8699462607197                                     	\N
403	and027	Napolitank Vafer 340gr Karolina/Pako14	0.00	5319990226945                                     	\N
404	and028	Ajvar Bash i Djegs 660gr/Pako12	0.00	5319990172334                                     	\N
405	and029	Ajvar Bash Pa Djegs 660gr/Pako12	0.00	5319990172228                                     	\N
406	and030	Keks Me Kryp Tuc 100gr/Pako24	0.00	5410041435702                                     	\N
435	ANL021	Kinder ve 60g BARBELLA/P24x3	0.52	8699462607128                                     	\N
407	and032	Ishler Me Eurokrem 125gr/Pako24	0.00	8600946445006                                     	\N
386	and010	Melange 500gr/Pako16	0.00	4009176222540                                     	\N
441	ANL027	Chokolate 8g DOBBY (12x48) /P576	0.00	8699462601980                                     	\N
387	and011	Best Of 500gr/Pako16	0.00	4009176222588                                     	\N
408	and033	Albeni e gjatë 47gr/Pako18	0.00	\N	\N
443	ANL029	Chocolate 18g/20g RABBIX/P36x10	0.11	\N	\N
409	and034	Shtrudlle prej Vishnje 175gr/Pako22	0.00	3870404001609                                     	\N
401	and025	Micro Pop Corn Djegst 100gr/Pako25	0.00	5997347541912                                     	\N
444	ANL030	Kinder ve 25g BARBELLA/P24x6	0.21	8699462604387                                     	\N
388	and012	Akullore Karamel 75gr Eskimko/Pako15	0.00	8606015710228                                     	\N
402	and026	Petit Biscuits 800gr Emona/Pako6	0.00	3872496000034                                     	\N
389	and013	Akullore Straciatela 75gr Eskimko/Pako30	0.00	8607100567819                                     	\N
390	and014	Akullore Dredhz 75gr Eskimko/Pako30	0.00	8607100568779                                     	\N
415	ANL001	Choco milk Pego  8gr (12x48)/P576	0.08	8699462600761                                     	\N
410	and035	Shtrudlle prej Frutave 175gr/Pako22	0.00	3870404001616                                     	\N
411	and037	Keks Nora 400gr/Pako12	0.00	3905299380123                                     	\N
416	ANL002	Choco milk PegoMax  18gr (12x24)/P288	0.21	8699462600792                                     	\N
473	ANM001	SPONTEX-0027-  Shpuz Qeliku 3/1/ P10	0.72	\N	\N
511	ANM039	SPONTEX Doreza gome Optimal L 0427/P12	0.85	9001378230427...                                  	\N
482	ANM010	Folije-1104-Alumini 10m Alupack /Pako 30	0.73	3856004911104                                     	\N
513	ANM041	SPONTEX Doreza gome Optimal S 0403/P12	0.85	\N	\N
514	ANM042	SPONTEX Doreza gome Optimal M 0410/ P12	0.85	\N	\N
516	ANM044	SPONTEX Doreza elastike Gold 0465 10/1 S	1.08	\N	\N
517	ANM045	SPONTEX Doreza elastike Gold 0489 10/1 L	1.08	\N	\N
477	ANM005	Filter-0023-per Aspirator 50*60 6/1/ P6	3.56	9001378760023                                     	\N
480	ANM008	SPONTEX-0146-Shpuz per auto  AUTO SHOP/P	0.81	\N	\N
504	ANM032	SOKE-0050-Shpuz per enë Griff Max 1/1P24	0.25	9001378700050                                     	\N
483	ANM011	Folije-1203-Alumini 20m Alupack Pako 30	1.33	3856004911203                                     	\N
466	ANL052	Lexus Krem Lajthie 150gr/P12	1.49	8699462609948                                     	\N
467	ANL053	LEXUS LOVE Hazelnut 110g/P24	0.99	8699462609924                                     	\N
484	ANM012	Folije-1302-Alumini 30m Alupack Pako 30	1.80	3856004911302                                     	\N
485	ANM013	Folije-1500-Alumini 50m Alupack Pako 30	3.07	9008438097396                                     	\N
469	ANL055	LEXUS 150gr Peanut/P12	1.49	8699462609962                                     	\N
464	ANL050	Choco Lajthi 250g Lexus/P12	1.47	8699462609580                                     	\N
449	ANL035	Kinder Ve 60g CHOCO STARS/P24x3	0.52	8699462607302                                     	\N
505	ANM033	Shpuze Super Max 3/1	0.68	9001378700098                                     	\N
456	ANL042	Minicco Cornet Lajthi 25gr/P24x4	0.24	8699462609436                                     	\N
512	ANM040	SPON- Shpuze abrazive 0159 3+1gratis/P12	0.68	\N	\N
515	ANM043	SPONTEX Litar qelik rrobash 20m0129 /P10	1.40	9001378240129                                     	\N
506	ANM034	SPONTEX-0227-Shpuz per ene 10/1 P12	0.85	\N	\N
457	ANL043	Minicco Korrnet Lajthi 25gr/P96	0.00	\N	\N
507	ANM035	SPONTEX-0265-Shpuz per enë Mega Max 5/1	1.10	\N	\N
486	ANM014	Folije-1517-Alumini 30cm*300m Gastro/P4	16.91	3856004911517                                     	\N
458	ANL044	Minicco Cornet Kikirik 25gr/P24x4	0.24	8699462609450                                     	\N
451	ANL037	Choco FIGUR 55g LADY BIRD/P12x6	0.55	8699462608279                                     	\N
459	ANL045	Choco 15g Rabbix/P36x10	0.08	8699462601874                                     	\N
468	ANL054	LEXUS 150gr Coffee/P12	1.49	8699462608392                                     	\N
450	ANL036	Chocolate with PEANUT 500g(1x12) safari	3.20	8699462600310                                     	\N
462	ANL048	Choco 15g Lady Bird/P36x10	0.08	8699462606190                                     	\N
463	ANL049	Chocho Ball 15g/P36x10	0.08	8699462606176                                     	\N
475	ANM003	SPONTEX-0232-Inox Jumbo 1/1 Pako 16	0.85	\N	\N
490	ANM018	Thas-2354-Per mbeturina35/10 Alupack/P30	1.60	\N	\N
491	ANM019	Thas-2606-per mbeturina 60/10 Alupack Pa	2.13	\N	\N
492	ANM020	Thase2118-per Mbeturina 110l/ Pako 20	3.46	\N	\N
493	ANM021	Thase-3122-per mbeturina 120L/10 me lidh	5.05	\N	\N
494	ANM022	Thase3702-per mbeturina 70L/15 me lidhse	3.46	\N	\N
487	ANM015	Folije-7304-Celofan 30m Alupack Pako 42	0.70	3856004917304                                     	\N
488	ANM016	Folije-7601-Celofan 60m Alupack Pako 30	1.27	3856004917601                                     	\N
489	ANM017	Folije-7649-Celofan 30/300 Gastro/P4	5.41	3856004917649                                     	\N
498	ANM026	Kese-5010-per akull 240 Alupack/Pako 30	0.83	3856004915010                                     	\N
499	ANM027	Kese-5027-per pjekje 12/1 25*38cm/P24	1.91	3856004915027                                     	\N
500	ANM028	Kese-5065-per pjekje 8/1  35*43cm/P24	1.91	3856004915065                                     	\N
502	ANM030	SPONTEX-0248-Lecke Top Tex  5/1 Pako 20	1.12	\N	\N
495	ANM023	Thase-3405-per mbeturina 40L/15 me lidhs	2.97	3856004913405                                     	\N
496	ANM024	Thase-6307-per mbeturina 30L/50 Pako 40	2.13	\N	\N
501	ANM029	SPONTEX-1559-Lecke Antibak  5/1/P14	0.00	\N	\N
503	ANM031	Spon- LeckeTopTex 3/1 (0255) (0231)/P24	0.76	\N	\N
508	ANM036	SOKE-0302-Shpuz per enë Big Max 1/1	0.66	\N	\N
509	ANM037	SPON-0081-Shpuz Abrazive Pfannen Max 7/1	1.00	\N	\N
472	ANL058	Kinder Ve Peanut&Hazelnut 25gr Princ	0.20	8699462605148                                     	\N
474	ANM002	SPONTEX-0201-Shpuz Inox Wickle Max 2/1	0.73	\N	\N
476	ANM004	SPONTEX-0094-Leck per gjithadestinim 5/1	1.25	\N	\N
478	ANM006	SPONTEX-0154-Leck per te gjithadesti 3/1	1.03	9001378440154                                     	\N
470	ANL056	Kinder top 30g SUPER TURTLES/P24x6	0.24	8699462606022                                     	\N
471	ANL057	Kinder Ve Peanut&Hazelnut 25gr Safar	0.20	8699462605117                                     	\N
452	ANL038	Choco PEANUT 2Kg/P6 DELUXE	10.07	8699462609221                                     	\N
453	ANL039	Choco PEANUT CREAM 500G/P12 LEXUS	3.20	8699462609061                                     	\N
481	ANM009	SPONTEX-0119-Shpuz qeliku me detergjent	0.00	\N	\N
454	ANL040	Choco PEANUT CREAM 500G/P12 DELUXE	3.20	8699462600396                                     	\N
455	ANL041	Choco LAJTHI 500g/P12 DELUXE	3.20	8699462600303                                     	\N
510	ANM038	SPONTEX Doreza elastike Gold 0472 M/P100	1.08	\N	\N
460	ANL046	Choco 15g Lio/P36x10	0.08	8699462602307                                     	\N
461	ANL047	Choco 15g Rex/P36x10	0.08	8699462602284                                     	\N
479	ANM007	SPONTEX-0347-Leck per pastrim MEGA TEX/	1.32	\N	\N
532	ANM060	SPON- Furça për dysh.me fije natyr(0643)	6.35	9001378670643                                     	\N
548	ANM077	Spontex Lecke Flexi 3/1(1436)/Pako22	0.86	9001378421603                                     	\N
564	ANM093	SPON-Pastrues per dysheme Quick Max 1282	14.47	\N	\N
556	ANM085	Spontex Leck Combi-0117/Pako 20	1.86	\N	\N
565	ANM094	SPON- Pastrues dysheme Cotton Wipe 1473	10.53	\N	\N
559	ANM088	SPONTEX Palloma te lengeta Antibakterial	1.21	\N	\N
569	ANM098	Spontex Furqë per WC e rrumbullaket(5128	2.15	\N	\N
566	ANM095	SPONTEX Pastrues rezerve Quick Mop 1299	4.15	9001378501299                                     	\N
567	ANM096	SPON-Pastrues per dysheme Microwiper Ext	10.53	9001378051480                                     	\N
538	ANM066	Spontex Pastrues Dritares (0758)0734/P24	4.47	\N	\N
547	ANM076	Spontex Pastues per Dysheme Poder Azul(1	2.87	9001378501688                                     	\N
571	ANM100	SPONTEX Kese per mbeturina 2+1Gratis(611	0.00	\N	\N
575	ANM104	SPONTEX Lecke 5/1+Inox Jumbo1/1 grat/P60	0.00	\N	\N
554	ANM083	Spontex  Furçë (06659)për pastrimin e dy	0.00	\N	\N
570	ANM099	SPONTEX Pastrues per dysheme Fashion Mop	2.95	\N	\N
549	ANM078	Spontex Lecke Classic (0512)/Pako12	0.00	\N	\N
568	ANM097	SPONTEX Past.per dysheme Microwiper 1534	10.53	\N	\N
574	ANM103	SPONTEX Leter per pjekje+Folije celofani	0.00	\N	\N
576	ANM105	SPONTEX 0482 Lecke antibak.2/1/ Pako 20	0.00	\N	\N
585	ANM116	SPONTEX-(2584)Doreza Gome Feeling 12/1 L	1.33	\N	\N
586	ANM117	SPONTEX (1428)- Pjese per dysheme rezerv	4.68	9001378501428                                     	\N
589	ANM120	SPONTEX-(2560)Doreza Gome Feeling 12/1 S	1.33	\N	\N
534	ANM062	SPONTEX Furça për WC Uglata (0164)/P12	0.30	\N	\N
555	ANM084	Spontex Furçe per WC LUXUS 0126 /Pako 12	3.03	\N	\N
552	ANM081	Kese per Friz 1/50 Alupack(6017)Pako 30	1.17	3856004916017                                     	\N
590	ANM121	Spontex-(2577)Doreza Gome Feeling 12/1 M	1.33	\N	\N
578	ANM107	SPONTEX Foli alumini 30m+Kese per mbetur	0.00	\N	\N
572	ANM101	Folije alumini20m+Shpuze per larje 10/1	0.00	\N	\N
593	ANM124	Folije Alumini 50m + Shpuze per larje GR	3.07	\N	\N
540	ANM068	Spontex Doreza GomeComfort 6/S(0304) P12	0.91	9001378230304                                     	\N
557	ANM086	Spontex Past.per dysh.Microfaser-1893/Pa	0.00	\N	\N
543	ANM071	Spontex Shpuze per ene Flash Max 1/1(206	1.37	\N	\N
550	ANM079	SPON- (00104)Shpuz per ene Griff Max 2/1	0.43	\N	\N
583	ANM113	Lecke per pastrim Flexi Mikrofibre  3/1	1.44	\N	\N
573	ANM102	SPONTEX Folije alumini50m+Shpuze per lar	0.00	\N	\N
580	ANM109	SPONTEX Lecka3/1+Shpuze per larje 3/1 GR	0.76	\N	\N
579	ANM108	SPONTEX Foli alumini 20m+Leter per pjekj	0.00	\N	\N
591	ANM122	SPONTEX-(16024) Kese per Friz 2/50 Alup	2.66	\N	\N
581	ANM110	SPONTEX Celofan 60m Alupack+Shpuza Grif	1.25	\N	\N
553	ANM082	Kese per Friz 3/50Alupack (6031)/Pako30	1.55	3856004916031                                     	\N
521	ANM049	SPONTEX Rremojsa higjienike 25/1 0104	0.36	\N	\N
558	ANM087	SPONTEX Shpuze per trupe Calypso (0628)	1.21	\N	\N
535	ANM063	SPONTE Rrëmojsa higjienik 100/1(0142)/50	0.27	\N	\N
545	ANM073	SPONTEX-(0166)Shpuz per ene 3+1 gratis	0.68	\N	\N
560	ANM089	SPONTEX Palloma te lengeta Universal(052	1.21	\N	\N
544	ANM072	Spontex Shpuze per ene Marathon 2/1(2023	1.49	\N	\N
551	ANM080	Spontex Shpuz plastikes per ene 3/1(0010	0.60	\N	\N
562	ANM091	SPONTEX Shpuze per pastrim te sip te met	1.12	9001378700357                                     	\N
582	ANM112	SPONTEX 1580 Lecke Natura 3/1/Pako 22	1.17	\N	\N
584	ANM114	THase per mbeturina  150L/10 Alupack/P20	5.31	\N	\N
588	ANM119	SPONTEX -Lecke Tpo Tex 3/1 Shpuz per lar	0.00	\N	\N
530	ANM058	SPONTEX Micro Clapp Leckë Rezerv (1329)	3.99	9001378501329                                     	\N
541	ANM069	Spontex Doreza Gome Comfort(0311)  7/M/	0.91	9001378230311                                     	\N
595	ANM127	SPONTEX-0072-Shpuz Qeliku 6/1/Pako 6	2.90	\N	\N
592	ANM123	Kese-5010-per akull 240 Alupack/Pako 30	4.68	3856004916062                                     	\N
596	ANM128	Spontex-Leck 5/1(0209)/Pako 25	1.17	9001378430209                                     	\N
597	ANM129	Spon-Shkopinjë Grill 25cm(0746) 50/1/P20	0.59	\N	\N
542	ANM070	Spontex Doreza Gome Comfort(0328) 8/ L/	0.91	\N	\N
522	ANM050	Thase per mbeturina 20L/50 6208 40/1	1.65	\N	\N
524	ANM052	SPONTEX Kapëse për rroba 20/1(1003) /P24	0.66	\N	\N
523	ANM051	SPONTEX Pastrues per dysheme 0766 96/1	1.09	\N	\N
525	ANM053	SPONTEX Sungjer për pastrim Florida (004	0.66	9001378700098                                     	\N
587	ANM118	SPONTEX- Lecke Top Tex 5/1+ Inox Jumbo	0.00	\N	\N
594	ANM126	Thase-6116-per mbeturina 110l(50x110)Pak	3.46	\N	\N
526	ANM054	SPON-Furça druri per pastri dyshe(0316)	1.26	\N	\N
527	ANM055	SPONTEX Lopata per mbeturina(0168) /P24	1.05	\N	\N
520	ANM048	SPONTEX Lecke pastrimi 0019 24/1	0.00	9001378420019                                     	\N
529	ANM057	SPONTEX  Micro Clapp pèr dysheme /(1305)	9.85	\N	\N
546	ANM074	Spontex- Lecke per pastrim 10/1(1702)/P8	2.08	\N	\N
528	ANM056	SPONTEX Lopat mbeturi me furç(0199)/P24	2.18	\N	\N
533	ANM061	SPONTEX Furça për wc PICCOLO (0102)/P12	1.82	\N	\N
531	ANM059	SPONTEX  Furça për dysheme Gondola  ( 01	0.00	\N	\N
561	ANM090	SPONTEX-0216 Lecke pastrimi  10/1 /P25	1.21	\N	\N
536	ANM064	SPONTEX 2085 Sungjer për enë Brio 2/1 /P	0.00	9001378702085                                     	\N
537	ANM065	SPONTEX  Leckë antibak.3/1 (1535) P25	0.96	\N	\N
563	ANM092	SPON-Pastrues dysheme Prof.Cotton 1503	10.85	9001378501503                                     	\N
654	APC008	Ajax Powder Fdf Flowers of Spring /P.18	0.99	5900273411624                                     	\N
637	ANM169	Doreza praktike L(2023) Alu Pack/P12	0.81	3856004942023                                     	\N
646	ANM178	Tel per pastrim 2/1(2504) Alu Pack/P24	0.42	3856004942504                                     	\N
605	ANM137	SPONTEX Doreza elastike Gold 0472 M/P100	0.00	\N	\N
613	ANM145	Spon-Fshesë plastike pa dorez Duo Star/6	4.20	\N	\N
612	ANM144	Spontex-Shpuzë pastrimi Colormax 2+1/P18	0.63	\N	\N
649	ANM181	Furçë e ashpër me dorezë(95011)	2.43	3856004950110                                     	\N
659	APK013	Ajax Profesional Degreaser ULTRA 750ml/P	0.00	\N	\N
638	ANM170	Doreza praktike S(2009) Alu Pack/P12	0.81	3856004942009                                     	\N
647	ANM179	Shpuze active shine 1/1 (0012) Alu P/P24	0.16	3856004940012                                     	\N
661	APK016	Ajax FdF Lagoon Flower 1000ml/Pako 12	1.83	5900273474902                                     	\N
662	APK023	Ajax FdF Wild Flowers 1000ml/P.12	1.83	5900273474988                                     	\N
663	APK024	Ajax FdF Green 1000ml/Pako 12	1.83	\N	\N
615	ANM147	Spontex-Pjese rezerve 1480 coton wiper	0.00	9001378501480                                     	\N
652	APC003	Ajax FdF Cream Scourer Pink  500/Pako 12	0.00	5900273412126                                     	\N
664	APK025	Ajax Fdf Wild Flowers 1000@1250ml/Pako 1	0.00	\N	\N
617	anm149	Folie alumini 50m+Folie 10m gratis/P30	3.07	3908920730335                                     	\N
627	ANM159	Leckë per pastrim Hydra 3/1(0500)Alu Pac	1.93	3856004940500                                     	\N
628	ANM160	Doreza plastike S 10/1(2184) Alu Pac/P14	0.93	3856004942184                                     	\N
629	ANM161	Shpuzë active shine 3/1(0036) Alu Pac/P8	0.41	3856004940036                                     	\N
618	ANM150	Folie alumini 50m+shpuze 5/1 gratis/P30	3.07	\N	\N
619	ANM151	Folie alumini 20m+shpuze 1/1 gratis/P30	1.33	D3856004911203                                    	\N
636	ANM168	Fshesë me fije plastike(0035) Alu Pa/P10	2.64	3856004950035                                     	\N
655	APK001	Ajax Clean Water Lemon 1000ml/P 12	1.83	5900273477279                                     	\N
639	ANM171	Fshesë me fije plastike(0011) Alu Pa/P12	3.15	3856004950011                                     	\N
640	ANM172	Fshesë me fije plastike(0042) Alu Pa/P12	3.20	3856004950042                                     	\N
642	ANM174	Fshesë me fije plastike(0127) Alu Pa/P12	2.50	3856004950127                                     	\N
650	ANM182	Folie alumini Alu Fix 10m + Shpuze Sanif	0.71	3908920740778                                     	\N
601	ANM133	SPONTEX-0027-  Shpuz Qeliku 3/1/ P10 Gra	0.00	\N	\N
608	ANM140	SPONTEX Rremojsa higjienike 25/1 0104	0.00	\N	\N
641	ANM173	Furçe per pastrim (1513) Alu Pack/P24	1.24	3856004951513                                     	\N
631	ANM163	Shpuzë per pastrim 10/1(0050) Alu Pa/P12	0.54	3856004940050                                     	\N
651	AP9657013	Enmotion Roll Towel Aparate	0.00	AP9657013                                         	\N
648	ANM180	Brushe per toalet (1315) Alu Pack	1.51	3856004951315                                     	\N
630	ANM162	Shpuzë active shine 2/1(0029) Alu Pack/P	0.28	3856004940029                                     	\N
602	ANM134	SPON- Shpuze abrazive 0159 3+1gratis/P12	0.00	\N	\N
609	ANM141	Spontex-Lecke pastrimi Microfibre/P12	1.28	\N	\N
632	ANM164	Doreza plastike L (2207) Alu Pack/P14	0.93	3856004942207                                     	\N
633	ANM165	Tel per pastrim 12/1(2528) Alu Pack/P20	1.21	3856004942528                                     	\N
614	ANM146	Spontex-Lecke microfibre per pastrim 097	1.28	\N	\N
634	ANM166	Doreza praktike M (2016) Alu Pack/P12	0.81	3856004942016                                     	\N
624	ANM156	Leckë super e butë per dysheme(1002) Alu	0.81	3856004941002                                     	\N
658	APK004	Ajax Baking Citrus Grapefruit (Mandarin)	1.83	8718951188174                                     	\N
660	APK014	Ajax Profesional Duble Power 750ml/Pako	0.00	8714789259475                                     	\N
600	ANM132	SPONTEX-1634-Leck per pastrim Top 3/1/25	0.76	\N	\N
603	ANM135	Folije-1203-Alumini 20m Alupack GratP/30	0.00	\N	\N
645	ANM177	Doreza plastike M (2191) Alu Pack/P14	0.93	3856004942191                                     	\N
616	ANM148	Spontex-Leckë pastrimi 10/1(1108) /P10	2.08	9001378421108                                     	\N
635	ANM167	Leckë per pastrim comfort 50x70cm(1019)	1.60	3856004941019                                     	\N
643	ANM175	Kaci me furçë (0066) Alu Pack/P24	1.71	3856004950066                                     	\N
604	ANM136	Folije-1517-Alumini 30cm*300m Gastro/P4	0.00	\N	\N
610	ANM142	Spon-Lecka të lag.pastrim uni. limon/P22	1.32	\N	\N
611	ANM143	Spon-Lecka të lag.pastrim Fresh Ocean/22	1.32	\N	\N
606	ANM138	Spontex Doreza Gome Comfort(0311)  7/M/	0.00	\N	\N
607	ANM139	Leter-4082-per pjekje 39*8 Alupack/P30	0.00	\N	\N
656	APK002	Ajax Clean Water Fresh 1000ml/P 12	1.83	5900273477262                                     	\N
620	ANM152	SPON-0101-Leckë per pastrim 10/1 Top/P10	2.08	9001378420101                                     	\N
653	APC007	Ajax Powder Lemon 500g /Pako 18	0.99	5900273411327                                     	\N
621	ANM153	SPONTEX-1634-Leck per pastrim Top 3/1/25	0.76	\N	\N
623	ANM155	Leckë per pastrim 3/1(1026) Alu Pack/P20	0.61	3856004941026                                     	\N
625	ANM157	Leckë per pastrim Hydra 3/1(0524) Alu Pa	0.60	3856004940524                                     	\N
626	ANM158	Leckë per pastrim Hydra 5/1(0517) Alu Pa	0.94	3856004940517                                     	\N
644	ANM176	Kaci (0073) Alu Pack/P24	0.89	3856004950073                                     	\N
684	APK049	Ajax Multi-Action 750ml Trigger/P12	2.62	8714789562575                                     	\N
690	APK055	Ajax APC Fdf Lotus 1l/P12	1.83	8714789685939                                     	\N
722	APK087	Ajax Boost Baking Soda+Grapefruit 1000ml	1.83	8718951242340                                     	\N
726	APK091	Ajax Sc Antibacterial 500ml/P12	2.92	8718951277755                                     	\N
667	APK030	Ajax Professional BDC Extra Power 1000ml	2.19	8714789309941                                     	\N
691	APK056	Ajax Apc FDF Red Flowers 12/1l	2.40	8718951278394                                     	\N
668	APK033	Ajax FdF Lilac Breeze  1000ml/Pako 12	1.83	\N	\N
692	APK057	Ajax Apc FDF Lagoon Flowers 12/1l	2.40	8718951278486                                     	\N
672	APK037	Ajax Fdf Lilac Breeze 1000@1250ml /Pako	0.00	\N	\N
693	APK058	Ajax Apc Morning Rose Pink 1l/12	1.83	8718951278455                                     	\N
695	APK060	Ajax Apc Spring Flowers (Green) 12/1l	2.40	8718951278424                                     	\N
696	APK061	Ajax Apc Authentic Almond Oil 12/1l	2.40	8714789866444                                     	\N
701	APK066	Ajax APC Mediterranean Lemon 750ml/P12	1.34	8714789915258                                     	\N
730	APK095	Ajax Professional Bathroom Trigger 12/75	2.97	8718951293052                                     	\N
674	APK039	Ajax  Bathroom Spray 750ml  /P12	2.62	8714789396101                                     	\N
676	APK041	Ajax Bak.Soda Orange 1000ml+250ml Gratis	0.00	\N	\N
702	APK067	Ajax APC Mediterranean Pine 750ml/P12	1.36	8714789915289                                     	\N
677	APK042	Ajax Bak.Soda Grapefruit  1000ml+250ml G	0.00	5900273479044                                     	\N
671	APK036	Ajax Wood Classic 1000 ML /Pako 12	2.25	5900273471246                                     	\N
703	APK068	Ajax Kitchen Degreaser 600ml spray/P10	2.46	8714789939551                                     	\N
705	APK070	Ajax multi-action 600ml trigger/P10	2.46	8714789945330                                     	\N
708	APK073	Ajax Glass Crystal Clean Trigger 12/500m	1.99	8714789574448                                     	\N
710	APK075	Ajax red flower+Ajax charcoal 1L GRATIS	1.83	3908920740396                                     	\N
678	APK043	Ajax Apc Fdf Cherry Bl. 1000ml/Pako12	0.00	\N	\N
679	APK044	Ajax Apc Fdf Bambo 1000ml/Pako12	0.00	\N	\N
683	APK048	Ajax Disinfecting with Bleach 750ml/P.12	2.62	8714789562605                                     	\N
686	APK051	Ajax Anti bakterial sprey 750ml/P12	2.62	8714789746227                                     	\N
711	APK076	Ajax Lilac 1l + Ajax Optimal 1l	1.83	3908920740433                                     	\N
687	APK052	Ajax Anti-Bakterial BDC 1L/Pako 12	1.82	8714789754529                                     	\N
688	APK053	Ajax Bleach Pine 1L/Pako 12	1.83	\N	\N
713	APK078	Ajax Anticalcare 500ml/P12	2.58	8718951147010                                     	\N
717	APK082	Ajax APC FDF Green 1,5l/P8	2.19	8714789842394                                     	\N
721	APK086	Ajax Apc Fdf Tulip&Lychee 1000ml/P12	1.83	8714789879628                                     	\N
689	APK054	Ajax Bleach Pine 1L/Pako 12	1.82	8714789116297                                     	\N
694	APK059	Ajax Apc FDF Lilac Breeze 12/1l	2.40	8718951278516                                     	\N
697	APK062	Ajax BDC Anti-bakterial Blue 1l/P12	1.82	8714789664156                                     	\N
723	APK088	Ajax Apc Pure Home Apple 12/1l	2.28	8718951336834                                     	\N
698	APK063	Ajax anti-bacterial 750ml trigger/P12	2.62	8714789658148                                     	\N
724	APK089	Ajax Sc Pure Home Ede 1000ml/P12	2.28	8718951336865                                     	\N
675	APK040	Ajax Kitchen Spray 750ml /Pako 12	2.62	8714789396088                                     	\N
699	APK064	Ajax Professional Disinfectant w/o Bleac	2.92	8718951384606                                     	\N
725	APK090	Ajax Sc Wc Power 500ml/P12	2.92	8718951248847                                     	\N
704	APK069	Ajax Bathroom 600ml trigger/P10	2.46	\N	\N
706	APK071	Ajax Anti-bakterial 600ml trigger/P10	2.46	8714789939612                                     	\N
728	APK093	Ajax Professional Kitchen Trigger 12/750	2.97	8718951277380                                     	\N
709	APK074	Ajax BDC Pine 1000ml/12	0.01	8714789912585                                     	\N
729	APK094	Ajax apc spring flowers green 1000ml/P12	0.00	\N	\N
669	APK034	Ajax Fdf Fresh 1000ml+1250mlGR/P9	0.00	\N	\N
670	APK035	Ajax Fdf Lemon 1000@1250ml/Pako 12	0.00	\N	\N
712	APK077	Ajax pllaka red 1l + Fabuloso Blue 1l gr	1.83	3908920740860                                     	\N
680	APK045	Ajax FDF Oriental Freshness Pink/P.12	1.83	\N	\N
685	APK050	Ajax FDF Lotus 1000ml /Pako 12	1.83	8714789688275                                     	\N
727	APK092	Ajax Shower Power 600ml trigger/10	0.00	\N	\N
714	APK079	Ajax APC orange blossom 1l/P12	1.83	8718951278936                                     	\N
707	APK072	Ajax per xhama 750ml +Ajax per pllaka 1L	1.87	3908920730274                                     	\N
715	APK080	Ajax Apc Boost Lavender 12/1l	2.40	8718951278547                                     	\N
716	APK081	Ajax Apc Boost Lemon 12/1l	2.40	8718951278905                                     	\N
718	APK083	Ajax Apc Fdf Lilac Breeze 1.5l/P8	2.19	8718951115934                                     	\N
997	ARI158	Pantene Smoth&Silky 200ml/Pako 6	0.00	\N	\N
673	APK038	Ajax Professional Limescale&Grease 750ml	0.00	\N	\N
719	APK084	AJAX APC BST BS LEM 1x12x1000ML Kosovo/P	1.83	8718951190160                                     	\N
720	APK085	AJAX APC BST VG LAV 1x12x1000ML Kosovo/P	1.83	\N	\N
681	APK046	Ajax APC LTD Magic illusion 1000ml/Pako1	0.00	\N	\N
682	APK047	Ajax APC LTD Precious Dream 1000ml/Pako1	0.00	\N	\N
785	ARC016	G1416- Versailles Stemmed 6/1 Glass/P4	12.57	8833141636291                                     	\N
760	AQU008	Bombona Kavabon  Cappucino 70g/Pako 30	0.42	3859891935444                                     	\N
786	ARC017	G1483- Versailles Stemmed 6/1 Glass/P4	10.59	883314163735                                      	\N
769	ARB56	SWET MIX	0.00	\N	\N
761	AQU009	Bombona Helf Original  40g 8/14/Pako 112	0.33	3859891013005                                     	\N
762	AQU010	Bombona Helf Original 75g/Pako 30	0.44	3859891013463                                     	\N
763	AQU011	Bombona Helf Limeta-cola 75g/Pako 30	0.44	3859891935635                                     	\N
737	APK102	Ajax Apc FDF Dual Fragrance 12/1l	2.40	8718951423497                                     	\N
764	AQU012	Bombona Helf Karamela Qumshti 100g/P30	0.49	3859891935185                                     	\N
736	APK101	Ajax Apc Disinfection 12/1l	2.66	8718951401266                                     	\N
765	AQU013	Bombona Helf Karamela Lajthi 100g/Pako30	0.51	3859891935178                                     	\N
766	AQU014	Bombona Helf Karamela Dredhëze 100g/P30	0.49	3859891935192                                     	\N
787	ARC018	G1484- Versailles 6/1 Flute/P4	10.59	883314163711                                      	\N
767	AQU015	Bombona Helf Pepermint Qokollate100g/P30	0.46	3859891935222                                     	\N
768	AQU016	Bombona Helf Mentol Alpine 100g/Pako 30	0.34	3859891935215                                     	\N
732	APK097	Ajax Apc FDF Hibiscus 12/1l	2.40	8718951336681                                     	\N
733	APK098	Ajax Apc FDF Jasmine 12/1l	2.40	8718951622746                                     	\N
734	APK099	Ajax Boost Charcoal 1000ml/P12	1.83	8718951332225                                     	\N
735	APK100	Ajax Pure Elderflower 500ml spray/P12	2.92	8718951338395                                     	\N
745	APK110	Ajax Power Mousse Bathroom 12/500ml	2.97	8718951643789                                     	\N
740	APK105	Ajax Apc Ultra Classic 12/1l	2.35	8718951692015                                     	\N
742	APK107	Ajax Apc FDF Dual Fragrance Vanilla 12/1	2.40	8718951622777                                     	\N
743	APK108	Ajax Apc Strong&Safe 12/1l	2.40	8718951567917                                     	\N
746	APK111	Ajax APC FdF Lavender  12/1l	2.40	8718951680074                                     	\N
747	APK112	AJAX PLAKAVE PEACH 12/1L	2.40	8718951710276                                     	\N
748	APK113	Ajax APC FDF Ultra Lemon 1l  1/12	2.40	8718951730045                                     	\N
750	APK121	AJAX PLAKAVE PEACH 12/1l	0.00	\N	\N
752	AQTM889	Sistem konvencional i raftimit te paleta	0.00	ATM889                                            	\N
770	ARC001	G0567-Tem.Everyday Dinner 19 pc set/P1	19.04	0883314151749                                     	\N
772	ARC003	G4149-Temp. Athenes Dinner 19 pc set/P1	31.00	0883314195859                                     	\N
773	ARC004	G2280-Temp.Cotton Flower 19 pc set/P1	40.41	0883314171693                                     	\N
774	ARC005	G7051- Temp. Little Flowers 19 pc set/P1	40.41	8833142319911                                     	\N
788	ARC019	E9596- Tepme. Cadix  Dinner Plate/P12	1.93	2610237792231                                     	\N
789	ARC020	E9658- Tempe. Cadix  Soup Plate/P12	1.93	0026102377918                                     	\N
790	ARC021	E9675- Tepme. Cadix Dessert Plate/P12	10.44	2610237790122                                     	\N
784	ARC015	G1647- Versailles Stemmed 6/1 Glass/P4	14.51	883314163605                                      	\N
759	AQU007	Bombona Helf Mentol-Eukaliptus 75g kese/	0.44	3859891935598                                     	\N
751	APK122	ajax plakave hibiskuks 1300 ml /12	2.40	8718951358768                                     	\N
749	APK120	Ajax pllakave ultra lavander 12/1l	2.40	8718951691988                                     	\N
771	ARC002	G4135- Temp. Sirocco Brown 19pc set/P1	31.00	0883314195736                                     	\N
775	ARC006	G0318- Gota Crico 6/1Tumbler /P1	3.11	0883314148794                                     	\N
776	ARC007	G0319- Gota Crico 12/1 Tumbler/P1	5.72	883314148800                                      	\N
741	APK106	Ajax Professional Strong&Safe 12/500ml	2.97	8718951567825                                     	\N
739	APK104	Ajax Pure Home Apple 500ml/P12	2.66	8718951338364                                     	\N
753	AQU001	Bombona Kavabon original 40g 8/14/P.112	0.33	3859889214193                                     	\N
754	AQU002	Bombona Kavabon Cappucinno 40g 8/14/P112	0.33	3859891935413                                     	\N
755	AQU003	Bombona Helf Mentol-Eukaliptus 40g 8/14/	0.33	3859891935611                                     	\N
756	AQU004	Bombona Helf Herba 40g 8/14/Pako 112	0.33	3859891935604                                     	\N
757	AQU005	Bombona Helf Portokall-Guarana 75g/P30	0.44	3859891935628                                     	\N
781	ARC012	G9500- Bime Clear Transp. Bulle Tum/P24	0.95	0883314198027                                     	\N
782	ARC013	G9678- Bime Violine Blue Tumbler/P24	0.93	0883314265651                                     	\N
783	ARC014	G9677- Violine Bime Tumbler/P24	0.95	0883314265644                                     	\N
791	ARC022	37789- Tempe. Cadix Bowl/P6	1.86	026102377895                                      	\N
777	ARC008	E5062- Ballon Surf 12/1 Stemmed Glass/P1	8.14	0026102088470                                     	\N
778	ARC009	G9499- Bime Blue Tumbler/P24	0.93	0883314198089                                     	\N
779	ARC010	G9503- Bime BlueTumbler/P24	0.95	0883314198126                                     	\N
758	AQU006	Bombona Helf Herba 75g/Pako 30	0.44	3859891935581                                     	\N
738	APK103	Ajax Apc Lemon 2l/P6	2.58	8718951472068                                     	\N
818	ARC049	D2373- Tempe. Carine Noir Dinner/P12	1.83	0026102895191                                     	\N
821	ARC052	D2374- Tempe Carine Noir Soup Plate/P12	1.83	0026102895207                                     	\N
793	ARC024	D7368- Tempe. Cadix Bowl/P6	7.34	0026102377888                                     	\N
794	ARC025	D7368 Es  - Temp.Cadix  Bowl/P6	3.83	0126102377888                                     	\N
798	ARC029	E5093- Islande H/b 3/1Tumble/P6	3.28	0026102284797                                     	\N
840	ARC072	H2776- Tempered Cotton flower dinne/P24	3.04	0883314297505                                     	\N
845	ARC077	D6413- Tepme. quadrato rect. dish/P12	8.16	0026102253144                                     	\N
847	ARC079	36358- ARC Jug 1L 6/1/P6	2.72	0026102363584                                     	\N
848	ARC080	36341- Arc Jug 0.5L/P12	1.82	0026102363416                                     	\N
849	ARC081	10291- Carafe 1L/P6	1.98	0026102396094                                     	\N
809	ARC040	G0199- The Must Stemmed 6/1Glass/P6	7.02	00883314147568                                    	\N
810	ARC041	G0330- The Must Stemmed 6/1 Glass/P6	3.51	0883314148930                                     	\N
811	ARC042	G1509- Versailles 6/1 Stemmed Glass/P4	10.59	0883314163759                                     	\N
812	ARC043	G1483- Versailers Stemmed Glass 1/6 Pako	0.00	\N	\N
799	ARC030	G2766- Icy H/B 3/1Tumbler/P6	4.31	0883314178593                                     	\N
820	ARC051	D2370- Tepme. Carine Bowl/P6	7.71	0026102895160                                     	\N
822	ARC053	D2375- Tempe. Carine Noir Bowl/P12	1.96	0002610289521                                     	\N
823	ARC054	D2376- Tempe. Carine Bowl/P6	8.07	0026102895221                                     	\N
827	ARC058	G2287 Tempe. Lily Flower Bowl/P6	5.96	0883314171839                                     	\N
836	ARC067	G6911 Tempe. Little Flowers Bowl/P6	6.01	0883314230598                                     	\N
800	ARC031	G2764- Icy H/B 3/1Tumbler/P6	4.31	0883314178586                                     	\N
801	ARC032	08149- Sterling O/F Tumbler 1/18	0.00	\N	\N
838	ARC069	E5094 Islande 3/1 Tumbler/P6	2.90	0026102413814                                     	\N
813	ARC044	G1416- Versailles Steemed 6/1Glass/P4	12.57	0883314161335                                     	\N
802	ARC033	08106- Sterling H/B 3/1Tumbler/P6	4.88	0026102721193                                     	\N
816	ARC047	G2284- Temp. Lily Flower Dessert 1/12	0.00	\N	\N
824	ARC055	G2282  Tempe. Lily Flower Dinner/P12	2.11	0883314171751                                     	\N
803	ARC034	G4664- Bola Grey 3/1Tumbler/P6	4.09	0883314202359                                     	\N
825	ARC056	G2283 Tempe. Lily Flower Soup Plate/P12	2.11	0883314171761                                     	\N
826	ARC057	G2286 Tempe. Lily Flower M- 1/12	0.00	\N	\N
839	ARC070	08319 Islande tubi 3/1Tumbler/P6	2.46	\N	\N
841	ARC073	G5350- Temp. Volare bone 19pc set/P1	37.81	0883314211382                                     	\N
844	ARC076	E8865- Tempe. quadrato blanc cup/P4	16.17	0026102970188                                     	\N
828	ARC059	G6919 Tempe. Dahlia Twist Soup Plate/P12	2.82	0883314230663                                     	\N
846	ARC078	07784- Quadranto bwl 24cm/P6	7.11	0026102077849                                     	\N
850	ARC082	E9218- Tepme. Stackable bowl/P6	1.28	0026102142356                                     	\N
851	ARC083	73113-Tempe. Stackable bowl/P6	2.48	0026102503591                                     	\N
852	ARC084	14268- Tempe. Stackable-Pjata/P6	3.35	0026102142684                                     	\N
853	ARC085	17540- Poeme anis 3/1tumbler/P6	3.51	0026102175408                                     	\N
854	ARC086	69915- Pueblo Corail 3/1Tumbler/P6	3.51	0026102699157                                     	\N
855	ARC087	72311-Tempe. Pueblo Corail 19pc dinner	36.85	0026102723111                                     	\N
795	ARC026	D2367- Carine Wht Dnr Plt  1/12	0.00	\N	\N
829	ARC060	G6921 Temper. Dahlia Twist Soup/P12	2.82	\N	\N
796	ARC027	D2368- Carine wht Soup plt 1/12	0.00	\N	\N
830	ARC061	G6920 Temp. Dahlia Twist Desser/P12	2.62	0883314230673                                     	\N
831	ARC062	G6922 Tempe Dahlia Twist Purepose 1/12	0.00	\N	\N
804	ARC035	H0003- Bola Violone 3/1Tumbler/P6	4.09	0883314267167                                     	\N
832	ARC063	G6924 Tempe. Dahlia Twist/P6	1.01	0883314230710                                     	\N
797	ARC028	D2366- Temp. Carine Dessert Plate 1/12	0.00	\N	\N
833	ARC064	G6906 Tempe. Little Flowers Dinner/P12	2.82	0883314230369                                     	\N
805	ARC036	H0004- Bola Violine 3/1Tumbler/P6	4.09	0883314267181                                     	\N
834	ARC065	G6907 Tempe. Little Flowers Soup 1/12	0.00	\N	\N
806	ARC037	G0245- Circo 6/1Tumbler/P6	4.92	0883314148091                                     	\N
817	ARC048	08094- Sterling 3/1Tumbler/P6	4.88	0026102721186                                     	\N
819	ARC050	D2369- Tempe. Carine Bowl  1/12	0.00	\N	\N
835	ARC066	G6908 Tempe. Little Flowers Dessert 1/12	0.00	\N	\N
837	ARC068	G6910 Tempe. Little Flowers 1/12	0.00	\N	\N
842	ARC074	D7199- Tempe. White quadrato/P12	4.32	\N	\N
856	ARC088	E9332- Lineal Whisky world 4/1spiri/P4	6.85	0883314138733                                     	\N
857	ARC089	E9337- World Spirit 4/1Degustation/P4	8.34	0883314138788                                     	\N
808	ARC039	E5061- Elegance Stemmed 3/1 Glass/P6	6.16	0026102399224                                     	\N
814	ARC045	E5053- Elegance Stemmed 3/1 Glass/P6	7.07	0026102399149                                     	\N
815	ARC046	G6912-Temp.Little  Flowers 4/1 Cup/P4	20.60	0008331423063                                     	\N
906	ARC139	H5119-Temperes little flowe d.plate/P24	2.28	883314230369                                      	\N
907	ARC140	J0592-Tempered quadrato dinner plate/P24	4.06	0026102076514                                     	\N
890	ARC122	H3660-Tempered Set per Desert/P24	1.68	0026102895122                                     	\N
891	ARC123	H4264-Tempered Lily flower d.plate/P24	2.23	0883314171754                                     	\N
913	ARC146	Luminarc pjate e mesme volare/P1	1.99	883314140804                                      	\N
861	ARC093	H2284- Keep Box rect 2+1 free/P4	8.83	0883314292671                                     	\N
892	ARC124	H5172-Tempered Set per ene Dahlia/P24	2.23	0883314230666                                     	\N
893	ARC125	H5173-Tempered Set per Supe Dahlia/P24	2.23	0883314230680                                     	\N
862	ARC094	H2283- Tempe. keep salad bowl 2+1 free	13.45	883314292664                                      	\N
894	ARC126	H5174-Tempered Set per ene/P24	12.71	0883314230697                                     	\N
867	ARC099	E4438- Joyau 4/1 Tumbler /P4	5.62	0883314073836                                     	\N
868	ARC100	E8673- Salto 4/1Tumbler /P4	5.24	0026102919286                                     	\N
895	ARC127	H5122-Tempered Set Supe 21/P24	2.28	0883314230376                                     	\N
870	ARC102	E5106- Vigne 3/1 Tumbler/P6	3.48	0026102677506                                     	\N
873	ARC105	G4919- Delta 3/1Tumbler/P8	4.66	0883314205763                                     	\N
908	ARC141	J1348-Tempered soleil dinner plate/P24	2.52	0883314140866                                     	\N
896	ARC128	H5117-Tempered Set per Desert/P24	2.12	883314140798                                      	\N
915	ARF001	Saponia Arf Cream Citro 400ml/P12	1.35	3850105181596                                     	\N
877	ARC109	07740- Quadrato bwl 14cm/P12	4.32	0026102077402                                     	\N
883	ARC115	G8445-Gota Color 3/1tumbler/P6	4.21	0883314265743                                     	\N
887	ARC119	H4998-Tempered Carine Bowl/P24	3.10	0026102895214                                     	\N
910	ARC143	08319-Islande tubo 3/1H/B tumbler/P6	2.26	0026102703502                                     	\N
902	ARC134	G6912-Tempered Little Flowers cup /P1	22.12	883314230635                                      	\N
916	ARF002	Saponia Arf Cream Original 12/400ml	1.35	3850105181626                                     	\N
917	ARF003	Saponia Arf Cream Natyral 12/400ml	1.35	3850105181657                                     	\N
918	ARF004	Saponia Arf Xhamash 12/650ml	1.59	3850105181015                                     	\N
903	ARC136	H3666-Tempered noir dinner plate/P24	1.47	0026102895191                                     	\N
912	ARC145	H6057-Tempered salad bowl 2+1free/P6	13.82	0883314292664                                     	\N
859	ARC091	E9344- World Wine Decanter/P2	12.61	0883314138856                                     	\N
860	ARC092	H2242- Glossy Party 12pc drink set	27.46	0883314292268                                     	\N
876	ARC108	H4129- Tempe Cadix Dessert Plate/P24	0.86	0026102377901                                     	\N
878	ARC110	H4132- Tempe. Cadix Diner Plate/P24	0.95	0026102377925                                     	\N
884	ARC116	G9534-Gota 3/1circolo/P8	4.21	0883314265705                                     	\N
885	ARC117	H0378-Gota 3/1 Costa/P8	5.16	0883314271287                                     	\N
886	ARC118	H1315-Gota Concepto 3/1 Stripy/P6	1.94	0883314289022                                     	\N
898	ARC130	H3668-Tempered Ene 14cm/P24	4.50	026102077405                                      	\N
998	ARI159	Pantene Perfect Curls 200ml/Pako 6	0.00	\N	\N
901	ARC133	H1376 - Gota 3/1Stripy/P6	1.88	\N	\N
911	ARC144	H0378-Gota costa 3/1 orange/P8	6.43	0883314271287                                     	\N
881	ARC113	H3058-Gota 3/1 Saphir/P6	3.70	0883314300048                                     	\N
899	ARC131	H1961-Gota Concepto 6/1 Stripy/P1	2.68	0883314289008                                     	\N
900	ARC132	H1962-Gota Concepto 6/1Stripy/P1	2.68	0883314288964                                     	\N
863	ARC095	H2521- Displayer Vinery Stemmed/P1	30.12	0026102934630                                     	\N
864	ARC096	20580- Tempe. Poeme Anis 1/1	48.23	0026102205808                                     	\N
866	ARC098	G2371- Enjoy Eat fiest 6/1preservin/P4	5.62	0883314173062                                     	\N
869	ARC101	E9667- Tempe. Trianon oval /P6	6.40	0026102519172                                     	\N
871	ARC103	H4126- Tempe. Trianon Dish/P24	2.72	0026102631188                                     	\N
872	ARC104	34691- Aspen Jug 1.3L/P6	4.20	0026102346914                                     	\N
904	ARC137	H3661-Tempered noir soup plate/P24	1.47	0026102895207                                     	\N
882	ARC114	H3052-Gota Vere 3/1Saphir/P6	7.98	0883314299960                                     	\N
905	ARC138	H4265-Temperd lily flower soup plat/P24	2.28	0883314171761                                     	\N
888	ARC120	H4266-Tempered  Ene Lily Flower/P24	3.17	0883314171792                                     	\N
874	ARC106	E8323- Tempe. Solieil Dinner Plate/P12	2.51	\N	\N
875	ARC107	E9473- Tempe. Soleil Dessert Plate/P12	2.12	0883314140842                                     	\N
879	ARC111	D7206- Tempe. White Quadrato Soup/P12	4.32	0026102838754                                     	\N
880	ARC112	H1376-Gota 3/1Stripy /P6	1.94	0883314288988                                     	\N
889	ARC121	H3667-Tempered Set per supe/P24	1.84	0026102895146                                     	\N
958	ARI085	Fairy Apple 500ml/Pako 21	0.00	5413149137233                                     	\N
960	ARI087	Fairy Lemon 1L /pako 10	0.00	5413149137134                                     	\N
920	ARF006	Saponia Arf Për Banjo Pomp 12/650ml	2.29	3850105181190                                     	\N
921	ARF007	Arf per Banjo Lavanda 650ml/P12	0.00	\N	\N
961	ARI088	Fairy Pine 1L/ pako 10	0.00	\N	\N
924	ARF010	Saponia Arf Deobad 12/750ml	1.59	3850105185723                                     	\N
943	ARI03	FA SET SPICY BLACK DEO+A.SH+SH	0.00	\N	\N
981	ari137	Raid Le ADV BS 21ml/Pako12	0.00	5000204663341                                     	\N
991	ARI15	FA DEO STICK 50ML SPICY BLACK	0.00	\N	\N
934	ari008	W&Go 2IN1 Kids Girls 400ml/Pako6	0.00	4015600962319                                     	\N
955	ARI08	FA DEO STICK 50ML BALSAM	0.00	\N	\N
976	ARI13	FA DEO STICK 50ML SPEEDSTER	0.00	\N	\N
992	ARI150	H&Sh classic Cleane + Condituner 400ml /	0.00	5410076637362                                     	\N
996	ARI155	Pantene Clarifying 200ml/Pako 6	0.00	\N	\N
964	ARI095	Always Super 8 /Pako20	0.00	\N	\N
985	ARI14	FA DEO STICK 50ML SPORT	0.00	\N	\N
986	ARI140	H&Shoulders  Citrus 200ml	0.00	5011321345119                                     	\N
993	ARI151	H&Shoulders Sensitiv 200 ml/Pako6	0.00	\N	\N
994	ARI152	H&Shoulders Menthol 200ml	0.00	5011321345416                                     	\N
995	ARI153	H&Shoulders Volume new 750ml/pako 6	0.00	5011321368804                                     	\N
983	ari1392	Lenor Innocente 1.45l/Pako8	0.00	4084500486713                                     	\N
935	ARI01	FA SET PRECIUS SOURCE	0.00	\N	\N
922	ARF008	Saponia Arf Xhamash Citro 12/650ml	1.59	3850105181077                                     	\N
927	ari001	H&SH Ocean 2in1 400ml/Pako6	0.00	4084500265226                                     	\N
928	ari002	H&SH Mentol 600ml/Pako6	0.00	4015600767570                                     	\N
929	ari003	H&SH Ocean 600ml/Pako6	0.00	4015600767495                                     	\N
947	ARI060	Lenor Natyral Extrat 1L/Pako12	0.00	\N	\N
948	ARI065	Lenor Spring 1l/Pako 12	0.00	5413149587090                                     	\N
980	ari134	H&Sh Total Care 750ml/Pako6	0.00	4015600509538                                     	\N
959	ARI086	Fairy Woodberry 500ml/Pako 21	0.00	\N	\N
941	ARI02	FA SET STAY COOL!	0.00	\N	\N
988	ARI149	H&Sh Menthol 400ml/pako 6	0.00	5011321331594                                     	\N
965	ARI096	Always Ultra Night 7/Pako 24	0.00	4015400501008                                     	\N
971	ARI117	Pampers New baby (2*43)/Pako 4	0.00	\N	\N
923	ARF009	Saponia Arf Grill Promo 12/650ml+100ml G	2.49	3850105185785                                     	\N
984	ari1393	Lenor Mysterieuse 1.5l/Pako8	0.00	4084500486836                                     	\N
989	ari1493	Alw Ult Super 20x8/Pako20	0.00	4015400403845                                     	\N
967	ARI098	Always Ultra Normal PI 10/Pako 16	0.00	4015400041641                                     	\N
925	ARF011	Saponia Arf Xhamash 650ml + 100ml Gratis	1.59	3850105185754                                     	\N
982	ari1391	Lenor Exotic Twist 1.45ml/Pako6	0.00	4084500522992                                     	\N
966	ARI097	Always Ultra Light 10/Pako 16	0.00	4015400041665                                     	\N
956	ARI083	Fairy Lemon 500ml/Pako 21	0.00	5413149137219                                     	\N
963	ARI09	FA DEO STICK 50ML RICE DRY	0.00	\N	\N
968	ARI10	FA DEO STICK 50ML ALOE VERA	0.00	\N	\N
957	ARI084	Fairy Pine Citrus 500ml/Pako 21	0.00	\N	\N
975	ARI127	Pampers JP Mini 3-6 kg 94/Pako2	0.00	4015400264613                                     	\N
977	ARI130	Pampers JP Extra Large (2x54)/Pako2	0.00	4015400244875                                     	\N
973	ARI120	Pampers Active baby Maxi 7-18kg/Pako 2	0.00	\N	\N
926	ARF012	Saponia Arf Cream profesional	0.00	3850105181688                                     	\N
932	ARI006	Ariel Mountain Spring 3kg/Pako 6	0.00	5413149836242                                     	\N
931	ARI005	Ariel White flowers Regular 3kg/Pako6	0.00	5413149562806                                     	\N
950	ARI073	Lenor Fresh Aromatherapy1L/Pako 12	0.00	5413149586550                                     	\N
969	ARI11	FA DEO STICK 50ML ActPearls.A	0.00	\N	\N
936	ARI010	Ariel Mountain Spring 4.5kg/Pako 4	0.00	\N	\N
972	ARI12	FA DEO STICK 50ML VANILIAHONY	0.00	\N	\N
974	ARI124	Pampers Active baby Midi 64 4-9kg	0.00	\N	\N
954	ARI079	Lenor Fresh Aromatherapy 2l /Pako 8	0.00	\N	\N
944	ARI04	FA SET SPORT DEO+A.SH+SH.G	0.00	\N	\N
970	ARI110	W&GO Citrus Fresh 400ml/Pako6	0.00	\N	\N
978	ari132	H&Sh Sport Fresh 750ml/Pako6	0.00	5410076686803                                     	\N
937	ARI011	Ariel Regular 6kg/ pako 3	0.00	\N	\N
938	ARI012	Ariel Mountain Spring 6kg/Pako3	0.00	5413149836433                                     	\N
939	ARI013	Aril Regular 9kg/Pako 2	0.00	\N	\N
940	ARI014	Ariel Mountain Spring 9kg/Pako 2	0.00	5413149836457                                     	\N
942	ARI021	Ariel 6 Kg Tol.pur Oxy + Kanta	0.00	\N	\N
953	ARI078	Lenor Relaxed 2l/pako6	0.00	4084500523708                                     	\N
933	ARI007	Ariel Color 3kg/Pako 6	0.00	5413149836617                                     	\N
951	ARI074	Lenor Spring 2l/Pako6	0.00	4084500523623                                     	\N
979	ARI133	Pampers Active Baby Maxi 50 plus 9-20kg/	0.00	\N	\N
987	ARI144	H&Shoulders Extra Volume 200ml	0.00	5011321345348                                     	\N
1000	ARI160	Pantene Color&Protect 200ml/Pako 6	0.00	\N	\N
1002	ari162	Pantene Moisture Re 400ml/Pako6	0.00	4084500840263                                     	\N
1042	ARI21	FA DEO ROLL-ON 50ML SPYCIBLACK	0.00	\N	\N
1044	ARI213	Pantene Anti-Breakage 400ml/6	0.00	5000174943320                                     	\N
1076	ARI255	Paantene Full Shine 400ml/Pako 6	0.00	\N	\N
1028	ari1971	Alw.Ult. Sens. Night /Pako16	0.00	4015400552154                                     	\N
1031	ari1975	Alw Ult Sens. Night/Pako24	0.00	4015400552109                                     	\N
1034	ari1978	Alw Duo Norm 18+4/Pako8	0.00	\N	\N
1035	ari1979	Alw Ult. Norm. Duo. 10 /Pako10	0.00	4015400700319                                     	\N
1033	ari1977	Alw Ult Sens. Night/Pako16	0.00	\N	\N
1022	ARI19	FA DEO ROL-ON 50ML ENERGYZONE	0.00	\N	\N
1054	ARI23	FA DEO ROLL-ON 50ML FREESTYLE	0.00	\N	\N
1045	ARI214	Pantene Sheer Volume 200ml/Pako 6	0.00	\N	\N
1063	ARI238	Dove Shower Gell Crem Oily 250ml/Pako 6	0.00	\N	\N
1048	ari223	Fasule Agro-Kor 500gr	0.00	3901843660093                                     	\N
1011	ARI177	W&GO Jasmine  200ml/Pako 6	0.00	5011321352285                                     	\N
1019	ARI182	W&Go Aloe New 200ml/6	0.00	\N	\N
1003	ari163	H&Sh 2in1 Instant Reli 400ml/Pako6	0.00	4084500264328                                     	\N
1050	ARI225	Always Ul.Normal fresh 9/Pako 24	0.00	4015400508267                                     	\N
1008	ARI168	Pantene Extra Volume 400ml/Pako 6	0.00	\N	\N
1057	ARI232	Panten Cream Baby 100ml	0.00	ARI232                                            	\N
1009	ARI169	Pantene Extra Volume 2in1 200ml/Pako 6	0.00	\N	\N
1046	ARI218	Ariel 6kg Tol.Nat.Extract +Kanta	0.00	\N	\N
1070	ARI246	H&SH Anti Breakage 400ml/*6	0.00	5011321536623                                     	\N
1006	ari166	MR Muscolo Idraulic1L/Pako12	0.00	5000204670844                                     	\N
1007	ari167	Raid Elec Liquid 30ml/Pako12	0.00	5000204663341                                     	\N
1010	ARI17	FA DEO STICK 50ML ACTPEARLS.R	0.00	\N	\N
1043	ARI210	Pantene Preserve 200ml/Pako 6	0.00	\N	\N
1049	ari224	Fasule Agro-Kor 800gr	0.00	3901843660109                                     	\N
1013	ari1780	Alw Ult. Norm. Duo. 1/Pako10	0.00	4015400713012                                     	\N
1064	ARI24	FA DEO ROLL-ON 50ML NAT.ROSE	0.00	\N	\N
1014	ari1781	ALW ULT Night Duo16/Pako16	0.00	4015400726715                                     	\N
1058	ARI233	Nivea Sapun Milk Vitamin 100g/Pako 6	0.00	\N	\N
1061	ARI236	Gillette Deo Coolwave 150ml/Pako 6	0.00	\N	\N
1037	ARI200	w&G 2in1 Aloe 750 ml / pako 6	0.00	5011321352704                                     	\N
1047	ARI22	FA DEO ROLL-ON 50ML Y.ALOEVERA	0.00	\N	\N
1060	ARI235	W&G Anti Rupture 750ml/Pako6	0.00	\N	\N
1004	ari164	H&Sh Instant Clean 400ml/Pako6	0.00	4084500264977                                     	\N
1040	ARI203	Ariel 3kg + Lenor Spring /pako 6	0.00	\N	\N
1041	ARI206	Ariel 3kg Tol Pure Oxy/ pako 6	0.00	5413149567078                                     	\N
1069	ARI245	H&SH  Color 200ml/Pako 6	0.00	\N	\N
1036	ARI20	FA DEO ROLL-ON 50ML SPEEDSTER	0.00	\N	\N
1021	ari188	Pantene Thick&Stro 400gr/Pako6	0.00	5410076562169                                     	\N
1016	ARI18	FA DEO STICK 50ML FREESTYLE 3D	0.00	\N	\N
1062	ARI237	Gillette Deo Pacific 150ml/Pako 6	0.00	\N	\N
1012	ARI178	W&G 200ml Molle/Pako 6	0.00	5011321352438                                     	\N
1032	ari1976	Alw Ult Sens. Norm/Pako12	0.00	4015400213932                                     	\N
1052	ARI227	Lenor Romantic 2l/Pako 8	0.00	5413149593954                                     	\N
1053	ARI229	W&G 2in1 Aloe 200ml/Pako 6	0.00	5011321352643                                     	\N
1015	ARI179	W&G Anti Rupture 200ml/Pako 6	0.00	5011321423879                                     	\N
1074	ARI25	FA DEO ROLL-ON 50ML WHITE TEA	0.00	\N	\N
1065	ARI240	Pantene 21 Frull-Thik 200ml/Pako 6	0.00	\N	\N
1030	ari1974	Alw Ult Sens. Norml/Pako24	0.00	4015400213857                                     	\N
1055	ARI230	W&GO Color Care 400ml/Pako 6	0.00	5011321352520                                     	\N
1024	ari192	Pantene Aqua Light 400gr/Pako6	0.00	5410076565764                                     	\N
1025	ari1921	AWL ULT Night 24x7/PAko24	0.00	4015400012306                                     	\N
1038	ARI201	W&G Andidandruf 750 ml / pako 6	0.00	5011321352612                                     	\N
1059	ARI234	W&G  Anti Rupture 400ml/Pako 6	0.00	\N	\N
1051	ARI226	Always Duo Normal 2x9-/18 /Pako16	0.00	4015400523017                                     	\N
1017	ARI180	W&G Fruity Power 200ml/Pako 6	0.00	\N	\N
1073	ARI249	Lenor Romantic1L/Pako 12	0.00	\N	\N
1020	ARI185	W&G 1in1 AD 200ml/Pako 6	0.00	5011321352254                                     	\N
1071	ARI247	Always Quatro p,12x40	0.00	\N	\N
1018	ARI181	W&G Herbal coctail 200ml/Pako 6	0.00	5011321352162                                     	\N
1068	ARI243	Pantene Color Protect 400ml/Pako 6	0.00	\N	\N
1056	ARI231	W&G Jojoba 200ml Color/Pako 6	0.00	\N	\N
1027	ari197	Pantene Thick&Stro 250gr/Pako6	0.00	5410076562138                                     	\N
1023	ari191	Pantene Anti Hairf Al/Pako6	0.00	4084500146754                                     	\N
1066	ARI241	Pantene Full-Thick 400ml/Pako 6	0.00	\N	\N
1075	ARI254	Pantene Full&Shine 200ml/Pako 6	0.00	\N	\N
1072	ARI248	Lenor Summer 2L/Pako8	0.00	5413149584464                                     	\N
1039	ARI202	W&G Herbal Coctail 750ml/ pako 6	0.00	5011321352551                                     	\N
1005	ari165	Gillete Blue 3+1CRT/PAko12	0.00	7702018361410                                     	\N
1077	ARI256	Lenor Summer 1L/Pako12	0.00	5413149584402                                     	\N
1119	ARI312	Ariel regular 600gr *18	0.00	\N	\N
1120	ARI313	Tide lemon 600gr *18	0.00	\N	\N
1144	ARI335	Nat. ditore reg 20*18	0.00	\N	\N
1085	ari278	Combo Blue DIS 6+/Pako12	0.00	7702018258086                                     	\N
1099	ARI294	H&SH Anti Breakage 200ml/Pako 6	0.00	5011321536593                                     	\N
1082	ARI273	Diskret Deo Ocean 15	0.00	\N	\N
1151	ARI341	Nat ultra maxi 8*24	0.00	\N	\N
1128	ARI320	Bonux lemon 600gr *18	0.00	\N	\N
1129	ARI321	Bonux lemon 9kg	0.00	\N	\N
1130	ARI322	Bonux act.fr 9kg	0.00	\N	\N
1165	ari3515	Fariy Pomgrent&Red 2l/Pako9	0.00	4084500981171                                     	\N
1133	ARI325	Bonux 2in1 6kg *3	0.00	\N	\N
1112	ARI306	Ariel regular 9kg/Pako2	0.00	\N	\N
1092	ARI287	W&G Fruity 400ml/Pako 6	0.00	5011321352407                                     	\N
1131	ARI323	Bonux 2in1 600gr *18	0.00	\N	\N
1142	ARI333	Discreet duo mf 4*15	0.00	\N	\N
1134	ARI326	Bonux lemon 3kg *6	0.00	5413149838963                                     	\N
1132	ARI324	Bonux 2in1 Nat.Relax 3kg/Pako6	0.00	\N	\N
1159	ARI349	Always ultra ltrw 10*16	0.00	\N	\N
1083	ARI276	Pampers Regular  4-9kg/22	0.00	\N	\N
1124	ARI317	Bonux magn. 600gr *18	0.00	5413149613058                                     	\N
1125	ARI318	Bonux aqua 6gr *3	0.00	\N	\N
1139	ARI330	Bonux color (fairy) 3kg *6	0.00	\N	\N
1126	ARI319	Bonux aqua 3kg *6	0.00	5413149101289                                     	\N
1158	ARI348	Always Super 8 /Pako20	0.00	4015400500940                                     	\N
1113	ARI307	Always maxi dry 16*16	0.00	\N	\N
1136	ARI328	Bonux 2in1N.Fantasia 3kg/Pako6	0.00	5413149791299                                     	\N
1156	ARI346	Pampers GIANT Pack Midi (4-9 kg) 96/Pako	0.00	4015400736226                                     	\N
1109	ARI303	Lenor White 1L *12	0.00	\N	\N
1095	ARI290	W&G 2in1 Aloe 400ml/Pako 6	0.00	\N	\N
1148	ARI339	Nat ditore light trip *15	0.00	\N	\N
1111	ARI305	Lenor Tropical fresh 1L/Pako12	0.00	\N	\N
1106	ARI300	W&G Herbal Coctel 400ml/Pako 6	0.00	5011321352193                                     	\N
1108	ARI302	Lenor White flower 2L *6	0.00	541314982875                                      	\N
1116	ARI31	TRICIA ILLUSION 15ML	0.00	\N	\N
1117	ARI310	Lenor Relaxed 1L/Pako 12	0.00	5413149585454                                     	\N
1118	ARI311	Ariel regulas 15kg	0.00	\N	\N
1080	ARI26	FA ROLL-ON 50ML RICE DRY	0.00	\N	\N
1081	ARI27	FA DEO OLL-ON 50ML ACTP.ROSE	0.00	\N	\N
1135	ARI327	Bonux Blue Lagoon 3kg/Pako4	0.00	5413149733060                                     	\N
1122	ARI315	Tide alpine 3kg *6	0.00	\N	\N
1123	ARI316	Tide lemon 3gr *6	0.00	\N	\N
1101	ARI296	H&SH Ocean Energy 400ml/Pako 6	0.00	\N	\N
1102	ARI297	H&SH Extra Volume 400ml/Pako 6	0.00	5011321331563                                     	\N
1104	ARI299	H&SH Color 400ml/Pako 6	0.00	\N	\N
1127	ARI32	TRICIA TRAMP 15ML	0.00	\N	\N
1087	ARI280	Gillete a.shave gell 75ml sort	0.00	\N	\N
1088	ARI282	W&G hithi 200ml *6	0.00	5011321352735                                     	\N
1089	ARI284	W&G Hithi Nettle 750ml /pako 6	0.00	5011321394247                                     	\N
1094	ARI289	W&G Hithi Nettle 400ml /Pako 6	0.00	8008970042268                                     	\N
1097	ARI292	Gillette Shkum 250ml /Pako 6	0.00	3014260227081                                     	\N
1091	ARI286	W&GO 2in1 Jasmine 400ml/Pako 6	0.00	8008970042237                                     	\N
1096	ARI291	W&GO 2in1 Jasmine 750ml/Pako 6	0.00	5011321352582                                     	\N
1154	ARI344	Pampers GIANT Pack (11-25 kg) Junior 68/	0.00	4015400264934                                     	\N
1107	ARI301	Lenor Sensitiv 1L *12	0.00	5413149586833                                     	\N
1138	ARI33	LIP CARE DREDHZ	0.00	\N	\N
1137	ARI329	Bonux n.fresh (fairy) 6kg *3	0.00	\N	\N
1103	ARI298	Ocean Energy 750ml/Pako 6	0.00	\N	\N
1140	ARI331	Discreet normal plus 15*15	0.00	\N	\N
1146	ARI337	Nat ditore light 2*18	0.00	\N	\N
1141	ARI332	Gillette Set Fus.Pow.Mak.vibr.After Shav	0.00	\N	\N
1162	ARI351	Pampers VP New Born (2*74)/Pako2	0.00	\N	\N
1086	ARI28	FA DEO ROLL-ON 50ML RICEDRY SE	0.00	\N	\N
1145	ARI336	Nat.ditore reg duo *15	0.00	\N	\N
1105	ARI30	FITOVAL +SHAMPOO 100ML	0.00	\N	\N
1110	ARI304	Lenor Tropical Fresh 2L/Pako8	0.00	5413149584761                                     	\N
1143	ARI334	W&GO Citrus Fresh 750ml/Pako6	0.00	\N	\N
1149	ARI34	PALETTE DELUXE 400	0.00	\N	\N
1150	ARI340	Nat ultra normal duo *12	0.00	\N	\N
1163	ari3513	Fariy Lemon 450ml/Pako21	0.00	4084500981737                                     	\N
1152	ARI342	Nat ultra maxi duo 12*12	0.00	\N	\N
1121	ARI314	Tide snow flower 3kg *6	0.00	\N	\N
1155	ARI345	Pampers GIANT Pack Extra Large (16+ kg)	0.00	4015400245056                                     	\N
1098	ARI293	H&SH 2in1 Smooth&Silky 200ml/Pako 6	0.00	\N	\N
1100	ARI295	H&SH Ocean Energy 200ml/Pako 6	0.00	5011321345508                                     	\N
1157	ARI347	Always normal duo +di *16	0.00	\N	\N
1161	ARI350	Pampers reg maxi plus 18 *6	0.00	4015600002886                                     	\N
1160	ARI35	PALETTE DELUX 345	0.00	\N	\N
1090	ARI285	W&G Normal +Moll 400ml /Pako 6	0.00	5011321352469                                     	\N
1079	ARI258	Fairy Sensitiv 1L/Pako 10	0.00	5413149349230                                     	\N
1164	ari3514	Lenor Spring 2x2L/Pako3	0.00	4084500993969                                     	\N
1678	AS768	Thika per pasta	99.66	\N	\N
1216	ARI375	Ariel tol nat.extract 6kg /*3	0.00	\N	\N
1219	ARI378	Always UL.Night duo/Pako16	0.00	4015400501039                                     	\N
1226	ARI384	Ariel  MS 600gr/Pako 18	0.00	5413149010093                                     	\N
1170	ARI352	Pantene shine 400ml *6	0.00	\N	\N
1171	ARI353	Pantene Smoth-Silky 200ml *6	0.00	5011321620605                                     	\N
1172	ARI354	Pantene 2in1 ad 200ml *6	0.00	\N	\N
1232	ARI39	PALETTE DELUXE 880	0.00	\N	\N
1234	ARI391	Lenor Elegant 1.45L/Pako 8	0.00	4084500486607                                     	\N
1239	ari3916	Alw Liners Normal /Pako18	0.00	4015400124740                                     	\N
1180	ari3548	H&SH 2in1 Old Spice 400ml/Pako6	0.00	4084500821347                                     	\N
1187	ari3568	Lenor Moonlight 1L/Pako12	0.00	8001090208613                                     	\N
1191	ARI359	Pantene Anti-Breakage 200ml/Pako6	0.00	5011321620483                                     	\N
1185	ARI356	W&G Citrus Fresh 200ml/Pako6	0.00	\N	\N
1224	ARI382	Ariel tol pure oxy 6kg/*3	0.00	5413149567160                                     	\N
1182	ARI355	Pantene condit. smoth-silky 200ml *6	0.00	\N	\N
1183	ari3550	Pantene Oil Therapy 300g/Pako6	0.00	8001090026262                                     	\N
1227	ARI385	Ariel 6kg Mountaing Spring +Kanta	0.00	\N	\N
1204	ARI369	Panten 2in1 color protect *6	0.00	\N	\N
1207	ari3693	Ariel Tol Liq 1.3l/Pako4	0.00	4084500413429                                     	\N
1186	ari3567	Lenor Fresh Meadow 1.421L/Pako12	0.00	8001090208774                                     	\N
1208	ari3694	Ariel MS Liq 1.3l/Pako4	0.00	4084500413269                                     	\N
1202	ari3674	W&Go Balsam Herbs Extract 200ml/Pako6	0.00	5000174936186                                     	\N
1201	ari3673	Ariel 1.5Kg/Pako10	0.00	5413149634015                                     	\N
1210	ARI37	PALETTE DELUX 218	0.00	\N	\N
1192	ARI36	PALETTE DELUX 100	0.00	\N	\N
1205	ari3691	Bonux Mongoli 300gr/Pako20	0.00	4084500939950                                     	\N
1217	ARI376	Bonux Regullar 3Kg/Pako 6	0.00	\N	\N
1218	ARI377	Bonux Rrain Drops 3kg /Pako6	0.00	\N	\N
1196	ARI363	Mach 3 gel 200ml sort *6	0.00	\N	\N
1197	ARI364	Gillette shkum 250ml sort *6	0.00	3014260214678                                     	\N
1220	ARI379	Bonux Regular 3kg/*6	0.00	\N	\N
1199	ARI366	Pampers regular Maxi 20 *6	0.00	4015600002527                                     	\N
1231	ARI389	Ofert.Bl2 Excel  HRDC PC	0.00	\N	\N
1233	ARI390	W&G Hrbal Coctel 750ml+Balsom/*6	0.00	\N	\N
1212	ARI371	Pantene AD 2in1 200ml*6	0.00	\N	\N
1235	ari3912	Lenor Spring Awake 1.42l/PAko12	0.00	8001090208859                                     	\N
1222	ARI380	Lenor  Active Fresh 1L /*12	0.00	\N	\N
1195	ARI362	M3 razor aloe *6 makin	0.00	\N	\N
1198	ARI365	Mach 3 power razor makin *6	0.00	\N	\N
1223	ARI381	Lenor Active Fresh 2L /Pako8	0.00	\N	\N
1228	ARI386	Ariel 6kg  White Flower regular + Kanta	0.00	\N	\N
1221	ARI38	PALETTE DELUX 679	0.00	\N	\N
1167	ari3517	Fairy Chamomil&Vit 450ml/Pako21	0.00	4084500981577                                     	\N
1206	ari3692	Bonux A Fresh 300gr/Pako20	0.00	5413149495135                                     	\N
1168	ari3518	Fairy Orange&Lemon 450ml/Pako21	0.00	4084500981973                                     	\N
1169	ari3519	Fairy Apple 450ml/Pako21	0.00	4084500981812                                     	\N
1173	ari3541	Fariy Lemon 900ml/Pako10	0.00	4084500981331                                     	\N
1174	ari3542	Fariy Apple 900ml/Pako10	0.00	4084500981379                                     	\N
1241	ARI393	H&Sh Sham.Mentholl 750ml/*6	0.00	5011321368828                                     	\N
1179	ari3547	H&SH Nourish Hair&Sc 400ml/Pako6	0.00	4084500822856                                     	\N
1175	ari3543	Fariy Orange&lemon 900ml/Pako10	0.00	4084500981454                                     	\N
1189	ARI357	Pantene condit color 200ml *6	0.00	\N	\N
1225	ARI383	Bonux 2in1 Hapy.3kg/*6	0.00	5413149613089                                     	\N
1236	ari3913	Lenor Spring Awake 1l/PAko12	0.00	8001090208651                                     	\N
1238	ari3915	Alw Liners Normal /Pako14	0.00	4015400124719                                     	\N
1188	ari3569	Lenor Floral Roman 1L/Pako12	0.00	8001090208538                                     	\N
1200	ARI367	Pampers maxi plus 2x66	0.00	\N	\N
1176	ari3544	Fariy SS Tea Tree&mi 900ml/Pako10	0.00	4084500981539                                     	\N
1203	ARI368	Pamp.Wipes refill *12	0.00	\N	\N
1240	ARI392	Lenor Elegant 1L/Pako 12	0.00	5413149585591                                     	\N
1242	ari3935	Pantene Aqua Light 300ml/Pako6	0.00	8001090026224                                     	\N
1209	ari3695	Bonux Lilac 300gr/Pako20	0.00	4084500939912                                     	\N
1214	ARI373	H&SH 2in1 C.clean 400ML.*6	0.00	5011321331532                                     	\N
1178	ari3546	Fariy Pomgrnt&Red 900ml/Pako10	0.00	4084500981416                                     	\N
1215	ARI374	Ariel tol nat.extrac 3kg/*6	0.00	5413149567191                                     	\N
1181	ari3549	Pantene Anti Hair Fal/Pako6	0.00	5000174935295                                     	\N
1229	ARI387	Ofert.ariel 9kg MS	0.00	\N	\N
1237	ari3914	Always Liners Fresh/Pako5	0.00	4015400531371                                     	\N
1193	ARI360	Venus razor makin *6	0.00	\N	\N
1184	ari3551	Pantene Perfect Hy 300g/Pako6	0.00	8001090026309                                     	\N
1211	ARI370	Pantene 2in1 preserve 200ml*6	0.00	\N	\N
1190	ARI358	Pantene condit Anti-Breakage200ml *6	0.00	\N	\N
1230	ARI388	Pantene 2in1 Sheer Vulume 200ml /Pako6	0.00	\N	\N
1194	ARI361	Sensor excel razor makinn*6	0.00	\N	\N
1286	ARI417	W&GO Chamomile 750ml/Pako 6	0.00	5011321958029                                     	\N
1261	ari3976	Lenor Pure Care 1.42ml/Pako6	0.00	4084500489806                                     	\N
1262	ari3977	Lenor Almond Oil 1.42ml/Pako6	0.00	4084500489721                                     	\N
1281	ARI412	Lenor Parf. Magnifiq 750ml/Pako 12	0.00	5413149748699                                     	\N
1289	ARI44	VADEMCEUM 75ML EXT.FRESH WHITE	0.00	\N	\N
1287	ARI42	PALETTE DELUX 575	0.00	\N	\N
1288	ARI43	PALETTE DELUX 678	0.00	\N	\N
1310	ARI511	Lenor  Parf.Magnifiq 1.5/pako 8	0.00	5413149743823                                     	\N
1269	ARI401	Ariel White&Color 8kg/Pako2	0.00	4015400979920                                     	\N
1312	ARI513	Pantene Condi. NatureFusion 200m/Pako 6	0.00	\N	\N
1305	ARI507	Fairy Pomgrnt.&Red 1000ml/Pako 10	0.00	5413149963672                                     	\N
1246	ARI394	H&Sh Hairfall 200ml+Mentoll  400ml/*6	0.00	\N	\N
1317	ARI518	H&SH Menthol 400ml+DEO gratis/Pako 6	0.00	\N	\N
1247	ari3940	Alw Liners Duo Fres /Pako10	0.00	4015400164593                                     	\N
1254	ARI396	W&Go French Lavend 750ml/*6	0.00	4084500379954                                     	\N
1258	ari3973	Lenor Floreal 925ml/Pako12	0.00	4084500504318                                     	\N
1263	ari3978	Lenor Cotton Flower 1.42ml/Pako6	0.00	4084500489905                                     	\N
1248	ari3941	Alw Liners Duo Nor /Pako10	0.00	4015400124771                                     	\N
1249	ari3942	Alw Ult Light 16x10/Pako16	0.00	4015400041665                                     	\N
1291	ARI46	VADEMECUM 75ML ULTRA FRESH 12	0.00	\N	\N
1297	ARI50	TAFT LLAK 250ML ULTRA STRONG	0.00	\N	\N
1267	ARI40	PALETTE DELUX 655	0.00	\N	\N
1268	ARI400	H&Sh Dry Sclap 400ml/*pako 6	0.00	5011321648586                                     	\N
1264	ARI398	W&Go French Lavend 400ml/*6	0.00	8008970042244                                     	\N
1251	ari3945	Fairy Apple 1,350L/Pako9	0.00	4084500981133                                     	\N
1265	ARI399	H&Sh Hydrating 200ml/*pako 6	0.00	5011321648555                                     	\N
1306	ARI508	H&SH Menthol 750ml+200ml gratis/Pako 6	0.00	\N	\N
1307	ARI509	H&SH Ocean Energy 750ml+200ml gratis/Pak	0.00	\N	\N
1256	ari3971	Lenor Relaxed 925ml/Pako12	0.00	4084500492967                                     	\N
1257	ari3972	Lenor Tropical 925ml/Pako12	0.00	4084500504196                                     	\N
1315	ARI516	H&SH Anti Hair Fall 400ml /Pako 6	0.00	\N	\N
1318	ARI519	H&SH Anti Hair Fall MEN 750ml+SHKUM grat	0.00	\N	\N
1278	ARI41	PALETTE DELUX 555	0.00	\N	\N
1252	ari3946	Fairy Lemon 1,350L/Pako9	0.00	4084500981294                                     	\N
1320	ARI520	H&SH Anti Hair Fall MEN 400ml+DEO gratis	0.00	\N	\N
1266	ari3999	Alw Ult Duo Night/Pako10	0.00	4015400032328                                     	\N
1282	ARI413	H&SH Menthol 500ml /Pako 6	0.00	\N	\N
1308	ARI51	SCHAUMA REG.200ML 7 GJETH	0.00	\N	\N
1290	ARI45	VADEMECUM 75ML NATURAL WHITE	0.00	\N	\N
1272	ARI404	Fairy Orange&Lem 500ml/Pako 21	0.00	5413149233805                                     	\N
1273	ARI405	Fairy Chamomile 500ml/Pako 21	0.00	5413149458420                                     	\N
1274	ARI406	Fairy Orange&Lem 1L/Pako 10	0.00	5413149233775                                     	\N
1295	ari4995	Pantene Oil Thereapy 200ml/Pako6	0.00	4015600611774                                     	\N
1300	ARI502	W&GO Camomile 750ml+balsam gratis/Pako 6	0.00	5013965846885                                     	\N
1296	ari4996	H&Sh 2IN1 Citrus 400ml/Pako6	0.00	4015600778392                                     	\N
1313	ARI514	Pantene NatureFusion 400m+200ml Balsam/P	0.00	\N	\N
1292	ARI47	VADEMECUM 75ML ANTI PLAQ PROPO	0.00	\N	\N
1245	ari3938	Fairy Chamomile&Vit 1,350L/Pako9	0.00	4084500981218                                     	\N
1299	ARI501	Pantene Nature Fusion 400ml/Pako 6	0.00	\N	\N
1301	ARI503	Lenor Floral 1L/Pako 12	0.00	5413149962453                                     	\N
1294	ARI49	VADEMCUM 75ML GUM+ALOE VERA	0.00	\N	\N
1309	ARI510	Bonux Lilac 3kg/Pako 6	0.00	5410076897544                                     	\N
1270	ARI402	H&Sh Clasic Clain 2in1 750ml/*pako 6	0.00	5011321741874                                     	\N
1253	ARI395	W&Go Herbal coctel 400ml+Anti Repture 40	0.00	\N	\N
1255	ARI397	W&Go Anti Rupture  400ml+Balsam /*6	0.00	\N	\N
1276	ARI408	W&G Anti Dandruff 750ml+Balsam Gratis/Pa	0.00	5011321735033                                     	\N
1259	ari3974	Lenor Summer 925ml/Pako12	0.00	4084500504233                                     	\N
1260	ari3975	Lenor Tropical 1.42ml/Pako6	0.00	4084500493124                                     	\N
1275	ARI407	Fairy Chamomile 1L/Pako 10	0.00	5413149458451                                     	\N
1304	ARI506	Fairy Pomgrnt.&Red 500ml/Pako 21	0.00	5413149963641                                     	\N
1298	ARI500	Lenor Parf.Subtile 1.5L/Pako 8	0.00	5413149743854                                     	\N
1303	ARI505	Pantene Condit Full Spect 200ml/Pako 6	0.00	\N	\N
1277	ARI409	W&G Hair fall 750ml+Balsam Gratis/Pako6	0.00	\N	\N
1311	ARI512	Air Wick Multi 2/1 /Pako 6	0.00	\N	\N
1280	ARI411	Lenor Parf. Subtiles 750ml/Pako 12	0.00	\N	\N
1279	ARI410	H&Sh Sham.Mentholl 750ml+200ml shamp.Gra	0.00	5410076818655                                     	\N
1314	ARI515	Pantene Aqua Light 200m/Pako6	0.00	5013965695575                                     	\N
1283	ARI414	Pantene Anti-Breakage 400ml+200m Balsam	0.00	\N	\N
1271	ARI403	H&Sh A-Dandrufe Men 750ml/*pako 6	0.00	5011321741904                                     	\N
1284	ARI415	Pantene Extra Volume 400ml+200ml Balsam	0.00	\N	\N
1319	ARI52	SCHAUMA REG.200ML COLOR GLANC	0.00	\N	\N
1293	ARI48	VADEMECUM 8ACTIONS+HERBS 75ML	0.00	\N	\N
1302	ARI504	Lenor Floral 2L/Pako 8	0.00	\N	\N
1332	ARI532	Lenor Intriguente 1.5L/Pako 8	0.00	5410076258567                                     	\N
1333	ARI533	Lenor Mysterieus 1.5L/Pako 8	0.00	5410076258536                                     	\N
1324	ARI524	Ariel Gel Kap. MS 16/Pako 3	0.00	\N	\N
1325	ARI525	Ariel MS Linquid 1.5L/Pako 6	0.00	\N	\N
1326	ARI526	H&SH Citrus 2x200ml/Pako 6	0.00	\N	\N
1365	ARI621	Pamp Steep & Play Junjor 11-25 5/11  Pak	0.00	4015400147749                                     	\N
1360	ARI616	Pamp Steep & Play  Maxi 7-18 4/68 Pako 2	0.00	4015400203551                                     	\N
1327	ARI527	H&SH Menthol 2x200ml /Pako 6	0.00	\N	\N
1350	ARI606	Fairy Aloe Vera&Coco 750ml Pako 16	0.00	5410076198399                                     	\N
1334	ARI534	Always Duo Fresh +Night -15% me lire/Pak	0.00	\N	\N
1386	ARI642	Pantene Extra Volum 250ml/Pako6	0.00	5410076565832                                     	\N
1330	ARI530	Lenor Mysterieus 750ML/Pako 12	0.00	5410076258444                                     	\N
1367	ARI623	Pamp Prem Care CP 3 - 4-9  Pako 4	0.00	4015400274759                                     	\N
1335	ARI535	H&SH Menthol 400ml+200 /Pako 6	0.00	\N	\N
1336	ARI536	H&SH SW Citrus 400ml/Pako 6	0.00	5410076364923                                     	\N
1329	ARI529	H&SH Ocean 200ml+65 /Pako 12	0.00	\N	\N
1353	ARI609	Always Platinum Ult. Night Duo 6 Pako 16	0.00	4015400481379                                     	\N
1339	ARI541	H&SH 2in 1 Ment 400ml/Pako 6	0.00	\N	\N
1340	ARI542	Panten Color+Conditioner 250g Pako/6	0.00	\N	\N
1380	ARI636	Lenor Passion&Jasmi 750ml/Pako 12	0.00	\N	\N
1342	ARI600	H&SH Ocean Energi 400ml/Pako 6	0.00	5011321331686                                     	\N
1337	ARI537	W&GO Menthol Fresh 750ml /Pako 6	0.00	5410076297177                                     	\N
1344	ARI602	Lenor Elegant 500ml /Pako 12	0.00	5413149585744                                     	\N
1352	ARI608	Always Platinum Ult. Super Plus Duo 6 Pa	0.00	4015400481317                                     	\N
1372	ARI628	Pamp Prem Care CP 11-25 5/44 Pako 2	0.00	4015400278870                                     	\N
1331	ARI531	Lenor Intriguante 750ML/Pako 12	0.00	5410076258475                                     	\N
1348	ari6054	Lenor Innocente 1L/Pako8	0.00	5410076976836                                     	\N
1363	ARI619	Pamp Steep & Play Midi 4-9 3/16  Pako 12	0.00	4015400122838                                     	\N
1383	ARI639	Pantene CND Sheer V 200ml/Pako6	0.00	5410076561582                                     	\N
1364	ARI620	Pamp Steep & Play Maxi 7-18 4/14  Pako 1	0.00	4015400166658                                     	\N
1341	ari570	Lenor Almond Oil 2L/Pako8	0.00	4015600817510                                     	\N
1354	ARI610	Always Platinum Ditore Normal 50 cop Pak	0.00	4015400481164                                     	\N
1359	ARI615	Pamp Steep & Play Mini 3-6 2/88 Pako 2	0.00	4015400378952                                     	\N
1362	ARI618	Pamp Steep & Play Mini 3-6 2/18  Pako 12	0.00	4015400122807                                     	\N
1357	ARI613	Gillete Deodorant 150ml   Pako 6	0.00	7702018982431                                     	\N
1338	ARI540	Pantene Nature Fusion 250ml/Pako 6	0.00	\N	\N
1343	ARI601	H&SH Ocean Energi 750ml/Pako 6	0.00	5011321368781                                     	\N
1374	ARI630	H&Sh Citrus Fresh 400+200 ml Pako6	0.00	\N	\N
1349	ari6055	W&Go 2in1 Kids Boys 400ml/Pako6	0.00	4015600962234                                     	\N
1358	ARI614	Pamp Sleep & Play Midi 4-9 3/78 Pako 2	0.00	4015400203520                                     	\N
1370	ARI626	Pamp Prem Care CP 3-6 2/72 Pako 2	0.00	4015400274728                                     	\N
1382	ARI638	Pantene CND Nature F 200ml/Pako6	0.00	\N	\N
1355	ARI611	W&Go Chamomile 750ml +Ballsam 200ml Grat	0.00	\N	\N
1366	ARI622	Pamp Prem Care CP 1 - 2-5/Pako2	0.00	4015400741602                                     	\N
1378	ARI634	Lenor Elegant 12x750/Pako 12	0.00	5410076482184                                     	\N
1385	ARI641	Pantene 2in1 Anti-DanDruff 250ml/Pako6	0.00	5410076566341                                     	\N
1369	ARI625	Pamp Prem Care CP 11-25 5/21 Pako4	0.00	4015400278849                                     	\N
1388	ARI644	Pantene Nature Fusio 250ml/Pako6	0.00	5410076566372                                     	\N
1384	ARI640	Pantene 2in1 Sheer V 250ml/Pako6	0.00	5410076565955                                     	\N
1368	ARI624	Pamp Prem Care CP 7-18 4/24 Pako 2	0.00	4015400278788                                     	\N
1351	ARI607	Always Platinum Ult. Normal Plus Duo 8 P	0.00	4015400481256                                     	\N
1373	ARI629	H&Sh Menthol + Deo 400ml Pako6	0.00	\N	\N
1375	ARI631	Ariel Gel Color&Style 1120g/Pako3	0.00	\N	\N
1376	ARI632	Ariel Gel Mountaim Spring 1120g/Pako3	0.00	\N	\N
1328	ARI528	H&SH Menthol 200ml+  /Pako 12	0.00	\N	\N
1361	ARI617	Pamp Steep & Play Junjor 11-25  5/58  Pa	0.00	4015400203582                                     	\N
1379	ARI635	Lenor Citrus&Rose /Pako 12	0.00	5410076517596                                     	\N
1356	ARI612	W&Go ADD750ml +Ballsam 200ml Gratis  Pak	0.00	\N	\N
1377	ARI633	Lenor Brillante 1L/Pako8	0.00	\N	\N
1345	ARI603	Fairy Aloe Vera Coco. 500ml /Pako 21	0.00	5410076198337                                     	\N
1322	ARI522	W&Go Chamomile 750ml+Balsam gratis/Pako	0.00	\N	\N
1347	ARI605	Fairy Silk&OrchiDea 500ml Pako21	0.00	5410076808380                                     	\N
1387	ARI643	Pantene Repair&Prot 250ml/Pako6	0.00	5410076565986                                     	\N
1323	ARI523	W&Go Anti Rupture 750ml+Balsam gratis/Pa	0.00	\N	\N
1389	ARI645	Pantene Color Prot Shi 250ml/Pako6	0.00	5410076562763                                     	\N
1390	ARI646	Pantene Repair&Prot 400ml/Pako6	0.00	5410076566013                                     	\N
1371	ARI627	Pamp Prem Care CP 4-9 3/60 Pako 2	0.00	4015400274780                                     	\N
1416	ARI672	Wash&Go Mentol Fresh 750ml+200ml Gratis	0.00	5410076725441                                     	\N
1444	ARI697	Lenor Floreal 2L/Pako8	0.00	5413149962606                                     	\N
1443	ARI696	Lenor Spring 500ml/Pako12	0.00	\N	\N
1445	ari6973	W&Go Gren Tea 750ml/*6	0.00	8008970042312                                     	\N
1406	ARI662	Fairy Apple 1.5L /Pako9	0.00	\N	\N
1446	ARI698	W&Go Honey 750g+200ml/Pako6	0.00	\N	\N
1418	ARI674	Pamp Prem Care CP 1 / 2-5 /Pako 4	0.00	4015400536857                                     	\N
1399	ARI655	Lenor Peach&Peony 1.5l/Pako12	0.00	5410076518364                                     	\N
1404	ARI660	Fairy Aloe Vera & Coc 1L /pako 16	0.00	\N	\N
1407	ARI663	Fairy Orange&Lemon 1.5L /Pako9	0.00	\N	\N
1412	ARI668	Panten Rep&Prot 250ml+200ml  /Pako6	0.00	\N	\N
1426	ARI680	W&Go Honey  200ml/Pako6	0.00	5410076795727                                     	\N
1427	ARI681	W&Go Honey  400ml/Pako6	0.00	8008970042220                                     	\N
1442	ARI695	Pasul 900gr Emona /Pako10	0.00	3903515240022                                     	\N
1393	ARI649	Pantene 2in1 Classic 250ml/Pako6	0.00	5410076566310                                     	\N
1413	ARI669	Panten Aqua Light 250ml+200ml /Pako6	0.00	\N	\N
1408	ARI664	Always Ult.Duo.Light Pako16	0.00	4015400605379                                     	\N
1405	ARI661	Fairy Lem Oxy 1.5L /Pako9	0.00	5413149273900                                     	\N
1431	ARI685	Fairy Lem 10x1L New/Pako10	0.00	\N	\N
1423	ARI677	H&Sh Sports Fresh 400ml/Pako6	0.00	5410076688432                                     	\N
1447	ARI699	H&Sh Men 400 ML+ Fus /Pako6	0.00	4084500023819                                     	\N
1432	ARI686	Fairy Silk&OrchiDea 750ml/Pako16	0.00	5410076808410                                     	\N
1433	ARI687	Fairy Sensitiv 1.5ml/Pako9	0.00	\N	\N
1434	ARI688	Fairy Camomile&Vit 1.5ml/Pako9	0.00	5413149458482                                     	\N
1435	ARI689	FAIRY POMGRNT&RED 1.5ml/Pako9	0.00	5413149963702                                     	\N
1394	ARI650	W&G Anti - Dandruff 750ml + 200 ml Grati	0.00	5410076725359                                     	\N
1395	ARI651	W&G For Greasy Hair 750ml + 200 ml Grati	0.00	5410076725410                                     	\N
1397	ARI653	Lenor Floral 1L Pako12	0.00	5413149962422                                     	\N
1419	ari6741	H&Sh  Thick&Stro 200ml/Pako6	0.00	4084500197534                                     	\N
1398	ARI654	Lenor Brillante 1.5L Pako8	0.00	5410076482146                                     	\N
1422	ARI676	Libresse Mult Normal Classic/Pako12	0.00	7322540063547                                     	\N
1429	ARI683	Combo Gill 2 Dis5+Bll/Pako14	0.00	\N	\N
1424	ARI678	H&Sh Sports Fresh 750ml/Pako6	0.00	5410076688463                                     	\N
1425	ARI679	H&Sh Sports Fresh 200ml/Pako6	0.00	5410076688401                                     	\N
1428	ARI682	W&Go Honey  750ml/Pako6	0.00	8008970042367                                     	\N
1420	ari6742	H&Sh Thick&Stro 200ml/Pako6	0.00	4084500149755                                     	\N
1456	ARI708	Combo Fusion Manua /Pako36	0.00	\N	\N
1436	ARI690	Panttene Aqua Light 250ml/Pako6	0.00	5013965695575                                     	\N
1437	ARI691	Wash & Go Honey 750ml+250ml Gratis/Pako6	0.00	4015600280994                                     	\N
1438	ari6910	Alw Ult Rw 16x10 SP/Pako16	0.00	5997253515991                                     	\N
1440	ARI693	H&Sh Apple 400ml /Pako6	0.00	5410076659296                                     	\N
1441	ARI694	H&Sh Citrus 750ml+250ml Gratis /Pako6	0.00	\N	\N
1448	ARI700	H&Sh Menthol 400ml+F/ Pako6	0.00	4084500023840                                     	\N
1400	ARI656	Lenor Passion&Jasmi 1.5L/Pako8	0.00	5410076518272                                     	\N
1410	ARI666	Panten Extra Volume 400ml/Pako6	0.00	5410076565863                                     	\N
1396	ARI652	Lenor Peach&Peony 750ml/Pako12	0.00	5410076517862                                     	\N
1401	ARI657	Lenor Citrus&Rose 1.5l/Pako8	0.00	5410076517725                                     	\N
1430	ARI684	Lenor MAGNIFIQUE 1.5l/Pako8	0.00	5413149748781                                     	\N
1411	ARI667	Panten Color 250+200ml  /Pako6	0.00	\N	\N
1457	ARI709	Combo Blue II + 6S+M3 /Pako18	0.00	7702018313013                                     	\N
1414	ARI670	H&Sh Menta 400ml+200ml /Pako6	0.00	\N	\N
1415	ARI671	H&Sh Oce 400ml+200ml /Pako6	0.00	\N	\N
1402	ARI658	Fairy Water lily&JoJ 500g /pako 21	0.00	5410076198306                                     	\N
1403	ARI659	Fairy Water lily&JoJ 750ml /pako 16	0.00	5410076198368                                     	\N
1449	ARI701	H&Sh Men 750ml+ Mach/ Pako6	0.00	4084500023758                                     	\N
1450	ARI702	H&Sh Menthol 750ml+M/ Pako6	0.00	4084500023789                                     	\N
1451	ARI703	W&Go Aloe Touch 400ml/Pako6	0.00	8008970042152                                     	\N
1452	ARI704	Gilette Shkum 300ml /Pako6	0.00	\N	\N
1453	ARI705	H&Sh Apple  200ml/ Pako6	0.00	\N	\N
1454	ARI706	Pantene Color 400g+200ml/Pako6	0.00	\N	\N
1455	ARI707	Pantene AL 250ml+200ml/Pako6	0.00	4015600277246                                     	\N
1421	ARI675	Pamp Prem Care CP 4 / 7-18 /Pako3	0.00	4015400278818                                     	\N
1392	ARI648	Pantene Color Prot Shi 400ml/Pako6	0.00	5410076562794                                     	\N
1458	ARI710	Gillete Shkum 300ml SE/Pako6	0.00	7702018094455                                     	\N
1459	ARI711	Panten Moisture 200ml/Pako6	0.00	5410076980925                                     	\N
1460	ARI712	Panten Moisture 400ml/Pako6	0.00	5410076980956                                     	\N
1461	ARI713	Pamp Prem Care CP 1 2-5/Pako4	0.00	4015400274636                                     	\N
1417	ARI673	Pamp Prem Care CP 2 / 3-6 /Pako 4	0.00	4015400274698                                     	\N
1463	ARI715	H&SH Soothing Care 400g/Pako6	0.00	5410076929849                                     	\N
1464	ARI716	W&GO Cond Ginseng 200g/Pako6	0.00	4015600399016                                     	\N
1465	ARI717	W&GO Ginseng 750ml/Pako6	0.00	4015600398927                                     	\N
1471	ari723	Fairy PLT A Fresh 720L/Pako16	0.00	4015600323431                                     	\N
1509	ari777	Bonux 2in1 Magnolia 2Kg/Pako6	0.00	5413149608726                                     	\N
1512	ari780	W&Go Blossm&Gree 750ml/Pako6	0.00	4015600827052                                     	\N
1679	AS769	Ambra -Melmesa per brumera	3.92	\N	\N
1468	ari720	Fairy PLT Lem&Lime 480ml/Pako21	0.00	8001090069443                                     	\N
1469	ari721	Fairy PLT A Fresh 480ml /Pako21	0.00	\N	\N
1473	ari725	H&SH Soothing Care  750g/Pako6	0.00	5410076929788                                     	\N
1474	ari726	H&Sh Dry Scalp 200m/Pako6	0.00	5011321648555                                     	\N
1475	ari727	W&Go Ginseng 400ml/Pako6	0.00	4015600398897                                     	\N
1479	ari732	Pamp JP Midi Plus 2x7/Pako2	0.00	4015400557982                                     	\N
1470	ari722	Fairy PLT Lem&Lime 720L/Pako16	0.00	\N	\N
1478	ari731	Pamp RC Midi Plus 6x/Pako6	0.00	4015400557845                                     	\N
1499	ari767	Ariel White Flower 2Kg/Pako6	0.00	5413149423909                                     	\N
1480	ari733	Pamp GP Midi Plus 2x/Pako2	0.00	4015400558057                                     	\N
1481	ari735	Lenor Almond Oil 12x1/Pako12	0.00	4015600817176                                     	\N
1482	ari736	Alw Duo Normal 18+4/Pako8	0.00	4015400652274                                     	\N
1483	ari737	H&SH Soothing Care 200ml/Pako6	0.00	5410076929818                                     	\N
1484	ari738	H&SH Total Care 200ml/Pako6	0.00	4015600509316                                     	\N
1521	ari933	Lenor Passion Love 1.45ml/Pako6	0.00	4084500522954                                     	\N
1510	ari778	Bonux 2in1 Rose 2Kg/Pako6	0.00	5413149619982                                     	\N
1487	ari741	Lenor Innocente 750L/Pako12	0.00	5410076976805                                     	\N
1488	ari742	W&Go Yeast 400ml/Pako6	0.00	4015600397340                                     	\N
1489	ari743	W&Go Yeast 750ml/Pako6	0.00	4015600397371                                     	\N
1490	ari745	H&SH Total Care 400ml/Pako6	0.00	4015600509347                                     	\N
1491	ari746	H&SH SW Citrus 400ml/Pako6	0.00	5011321331471                                     	\N
1496	ari751	World ngjyr e zez 80ml/Pako6	0.00	8699495590305                                     	\N
1493	ari748	Ariel Tol Oxy 6Kg/Pako6	0.00	5413149544243                                     	\N
1527	ari952	Lenor Spring 925ml/Pako12	0.00	4084500504103                                     	\N
1495	ari750	Alw Duo Night 15x2/Pako15	0.00	4015400612469                                     	\N
1523	ari936	Lenor Floreal 1.425ml/Pako6	0.00	4084500504356                                     	\N
1497	ari756	Ariel Ms 400gr/Pako22	0.00	5413149260214                                     	\N
1498	ari766	Ariel Tol Oxy 400gr/Pako22	0.00	5413149643994                                     	\N
1477	ari730	Fairy Platinium A Fresh 500ml/Pako21	0.00	4015400958758                                     	\N
1500	ari768	Ariel Montain Spring 2Kg/Pako6	0.00	5413149260245                                     	\N
1485	ari739	H&SH Apple 200ml/Pako6	0.00	5410076659265                                     	\N
1502	ari770	Ariel Tol Oxy 2Kg/Pako6	0.00	5413149644021                                     	\N
1504	ari772	Ariel Montain Spring 8Kg/Pako6	0.00	5413149331198                                     	\N
1526	ari939	ALW Normal Duo 18+/Pako12	0.00	4015400658115                                     	\N
1505	ari773	Bonux 2in1 Magnolia 400gr/Pako22	0.00	4084500939950                                     	\N
1506	ari774	Bonux A Fresh 2Kg/Pako6	0.00	5413149247895                                     	\N
1507	ari775	Bonux Lemon 2Kg/Pako6	0.00	5413149247932                                     	\N
1508	ari776	Bonux Lilca 2Kg/Pako6	0.00	5413149999657                                     	\N
1494	ari749	Ariel Ms 6Kg/Pako6	0.00	5413149260337                                     	\N
1467	ARI719	March Turbo Aloe 4C/Pako10	0.00	3014260331313                                     	\N
1513	ari781	Ariel MS 4kg/Pako3	0.00	5413149260306                                     	\N
1514	ari782	Ariel Color 4kg/Pako3	0.00	5413149260757                                     	\N
1515	ari783	Ariel Tol Oxy 4kg/Pako3	0.00	5413149644083                                     	\N
1516	ari784	Ariel Tol Oxy 6Kg/Pako2	0.00	5413149644243                                     	\N
1476	ari729	March 3 Gel Shvp IRRIT/Pako6	0.00	77020182901014                                    	\N
1501	ari769	Ariel Color 2Kg/Pako6	0.00	5413149260665                                     	\N
1511	ari779	Pantene Oil Therapy 400ml/Pako6	0.00	4015600611897                                     	\N
1518	ari793	W&Go Yeast 750ml+200ml/Pako6	0.00	40845000070981                                    	\N
1492	ari747	Lenor Aqua Violet 750ml/Pako12	0.00	4015600651985                                     	\N
1519	ari794	H&SH 2in1 Menthol 400ml/Pako6	0.00	4015600850067                                     	\N
1466	ARI718	W&GO Fruity 750ml/Pako6	0.00	4084500024557                                     	\N
1520	ari932	Lenor Midnight Rose 1.45ml/Pako6	0.00	4084500522794                                     	\N
1522	ari934	Lenor Summer 1.425ml/Pako6	0.00	8001090208897                                     	\N
1524	ari937	Lenor Relaxed 1.425ml/Pako6	0.00	8001090208811                                     	\N
1517	ari786	Lenor Aqua Violet 1.5L/Pako12	0.00	4015600652012                                     	\N
1486	ari740	Lenor Brillante 750L/Pako12	0.00	5410076482030                                     	\N
1525	ari938	ALW Platin. Normal 18/Pako18	0.00	4015400481072                                     	\N
1578	ARS044	Aristea Pjata plast.pizza white 20në1/18	3.85	8001909591028                                     	\N
1535	ARS001	Aristea Gota Plastike White 30/1x100	1.45	8001909180369                                     	\N
1552	ARS018	155805-Pjata plast.rrafshta  te kuqe 50/	1.70	8001909552258                                     	\N
1549	ARS015	165203-Pjata plast.rrafshta  light blue/	1.91	8001909652033                                     	\N
1554	ARS020	155802-Pjata plast.rrafshta  pink 50/1	1.70	8001909553354                                     	\N
1551	ARS017	155806-Pjata plast.rrafshta  dark blue 5	1.70	8001909556065                                     	\N
1566	ARS032	792253-Thika plastike light blue 20/1	0.73	8001909922525                                     	\N
1576	ARS042	Aristea Gota plas.200cc transp. 50në1/60	0.73	8001909182257                                     	\N
1580	ARS046	Aristea Enë Plastike 1750cc 10/1x5	1.38	8001909510609                                     	\N
1562	ARS028	793313-Piruna plastike te kuqe 20/1/P24	0.79	8001909933125                                     	\N
1563	ARS029	792313-Thika plastike te kuqe 20/1/P24	0.73	8001909923126                                     	\N
1564	ARS030	791313-Luge plastike te kuqe 20/1/P24	0.79	8001909913127                                     	\N
1568	ARS034	793273-Piruna plastike pink 20/1/Pako 24	0.79	8001909932722                                     	\N
1569	ARS035	792273-Thika plastike pink 20/1/Pako 24	0.73	8001909922723                                     	\N
1570	ARS036	791273-Luge plastike pink 20/1/Pako 24	0.79	8001909912724                                     	\N
1531	ari967	Pasul 700gr/Pako12	0.00	3903515240237                                     	\N
1533	ari974	Lenor Spring 1.425ml/Pako12	0.00	4084500504158                                     	\N
1573	ARS039	218052-Gota plast. 200cc white 20/1/P150	0.42	8001909180529                                     	\N
1553	ARS019	155801-Pjata plast.rrafshta  light blue	1.70	8001909553156                                     	\N
1555	ARS021	218377-Gota plastike dark blue 50/1/P30	0.77	8001909183759                                     	\N
1529	ari954	Blue 3 Sens Care 6CT/PAko12	0.00	7702018361861                                     	\N
1557	ARS023	218512-Gota plastike light blue 50/1/P30	0.77	8001909183957                                     	\N
1530	ari955	Blue 3 ICE Dis 6/Pako12	0.00	7702018983483                                     	\N
1559	ARS025	793303-Piruna plastike darkblue 20/1/P24	0.79	8001909933026                                     	\N
1536	ARS002	151703-Pjata plast.rrafshta te bardha/30	2.41	8001909511156                                     	\N
1556	ARS022	218437-Gota plastike te kuqe 50/1/P30	0.77	8001909184350                                     	\N
1537	ARS003	152703-Pjata plast.thella  te bardha 50	1.76	\N	\N
1558	ARS024	218510-Gota plastike pink 50/1/Pako 30	0.77	8001909184152                                     	\N
1538	ARS004	151705-Pjata plast.rrafshta te bardha 10	4.89	8001909510265                                     	\N
1539	ARS005	Aristea Pjata plasike te thella  te bard	4.89	8001909520264                                     	\N
1540	ARS006	155555-Pjata plast.rrafshta te bardha 50	1.94	8001909552159                                     	\N
1583	ARS049	218351-Gota plasike 200cc dark blue/P30	0.95	8001909183513                                     	\N
1586	ARS052	165251-Pjata plasike 220cc dark blu/P20	1.98	8001909652514                                     	\N
1532	ari968	Else Sham per Flok nga Hudhra 750ml/12	0.00	8697425860351                                     	\N
1541	ARS007	156045-Pjata plast.thella  te bardha 50/	2.41	8001909560451                                     	\N
1542	ARS008	Aristea Luge Plastike Të Bardha 100/1x25	0.59	8001909917903                                     	\N
1543	ARS009	Aristea Piruna Plastike Të Bardha 100/1x	0.64	8001909937901                                     	\N
1534	ari9961	W&Go For Damaged Hair 400ml/Pako6	0.00	8008970042206                                     	\N
1548	ARS014	165201-Pjata plast.rrafshta  te kuqe 30	1.91	8001909652019                                     	\N
1550	ARS016	165204-Pjata plast.rrafshta  pink 30/1	1.91	8001909652040                                     	\N
1560	ARS026	792303-Thika plastike dark blue 20/1/P24	0.73	8001909923027                                     	\N
1561	ARS027	Aristea Luge plastike dark blue 20në1/24	0.79	8001909913028                                     	\N
1571	ARS037	Aristea Gota Plasike Të Kafta 80cc 96/1x	0.63	8001909084759                                     	\N
1574	ARS040	Aristea Gota Plastike White 200cc 60/1x5	0.69	8001909181458                                     	\N
1575	ARS041	218082-Gota plas.200 cc transp.20/1/P150	0.44	8001909183827                                     	\N
1567	ARS033	791253-Luge plastike light blue 20/1/P24	0.79	8001909912526                                     	\N
1545	ARS011	Aristea Luge Për Kafe Të Bardha 20/1x100	1.99	8001909900462                                     	\N
1565	ARS031	793253-Piruna Plastike light blue 20/1	0.79	8001909932524                                     	\N
1577	ARS043	210345-Gota plast.100cc brown 50/1P96	0.74	8001909100008                                     	\N
1581	ARS047	440060-Ene e thellë plas.380cc 50/1/P18	2.92	8001909400603                                     	\N
1582	ARS048	440065-Ene e thellë plas.380cc 20/1/P36	1.49	8001909400658                                     	\N
1546	ARS012	Aristea Gota Plastike Të Bardha 96/1x50	0.65	8001909084254                                     	\N
1584	ARS050	218360-Gota plasike 200cc red/P30	1.15	8001909183605                                     	\N
1585	ARS051	218354-Gota plasike 200cc pink/P30	0.95	8001909183544                                     	\N
1547	ARS013	165200-Pjata plast.rrafshta  dark blue 3	1.91	8001909652002                                     	\N
1572	ARS038	Aristea Gota Plastike Të Kafta 166c P60/	0.96	8001909164154                                     	\N
1648	AS738	Thithese per ajer Fin-Banke	1478.05	\N	\N
1625	AS715	Vitrina Ftohëse Panama 2 85/216 250(AR96	5282.53	\N	\N
1626	AS716	Vitrina Ftohëse Panama 2 85/216 250(AR96	3949.54	\N	\N
1635	AS725	Komora Fermentim CLE098200	6058.81	\N	\N
1649	AS739	Furre Fin Banke FB8-D	5302.10	\N	\N
1644	AS734	Karroce per futje ne 20etapa per fleta 6	416.97	\N	\N
1653	AS743	Pjese per furra pjekese-Podiumi hapur OP	772.66	\N	\N
1619	AS709	Vitrina Ftohëse Denver Perdhesa(AR961342	2306.59	\N	\N
1597	ARS063	Aristea Gota Plastike Të Medha 575cc 16/	4.19	8001909090903                                     	\N
1598	ARS064	Aristea Gota Plastike Të Medha 400cc 20/	3.32	8001909070905                                     	\N
1650	AS740	Komora Fin Banke Fbp16-m	1567.72	\N	\N
1669	AS759	Doreza plastike	13.21	\N	\N
1663	AS753	Furqa per Furra Buke 430cm	11.54	\N	\N
1613	ART134	Babadimri i embel	0.00	\N	\N
1667	AS757	Qanta per burek Fi 30cm	4.37	\N	\N
1659	AS749	Pijate Inox Gn1/1-60 perforian	37.54	\N	\N
1590	ARS056	218353-Gota plastike bleu clair 50/1/P30	0.95	8001909183537                                     	\N
1607	ART120	Haski Kengetar	0.00	\N	\N
1603	ARS069	Aristea Pjata Plastike Të Rrafshta 170di	1.61	8001909555655                                     	\N
1606	ART102	Meda Special Frend	0.00	\N	\N
1610	ART127	Qeni Kengetar	0.00	\N	\N
1611	ART131	Pinguini kengetar	0.00	\N	\N
1614	AS154	Mikser FIMAR SN25 L.Sh.Saponia	0.01	\N	\N
1660	AS750	Pijate Inox GN1/1-20 Perforiran	29.70	\N	\N
1591	ARS057	155851-Pjata plastike dark blue 50/1/P20	1.95	8001909558519                                     	\N
1615	AS705	Pirunier Elektrik/Liugong(M00082)	13667.66	\N	\N
1616	AS706	Pirunier Elektrik/Liugong(M00080)	15835.60	\N	\N
1617	AS707	Pirunier Elektrik/Liugong(M00081)	14537.60	\N	\N
1588	ARS054	155854-Pjata plasike 170cc pink/P20	1.95	8001909558540                                     	\N
1593	ARS059	165253-Pjata plastike 30/1 light blu/P20	2.05	8001909652538                                     	\N
1594	ARS060	155853-Pjata plastike 50/1 light blu/P20	1.81	8001909558533                                     	\N
1605	ARS071	Aristea Gota Plastike Të Bardha 80cc 48/	1.13	8001909084360                                     	\N
1618	AS708	Vitrina Ftohëse Denver Perdhesa Hleb(AR9	1927.67	\N	\N
1592	ARS058	165250-Pjata plastike red 30/1/P20	1.98	8001909652507                                     	\N
1599	ARS065	Aristea Pjata Plastike Të Thella 203diam	1.82	8001909523050                                     	\N
1623	AS713	Vitrina Ftohëse Brema LF5P 218L (AR96189	9506.22	\N	\N
1624	AS714	Vitrina Ftohëse Brema 5.5P.Al 215 (AR961	9506.22	\N	\N
1670	AS760	Mbajtese per doreza	27.89	\N	\N
1628	AS718	Spirale statike matrix 80	7103.55	\N	\N
1629	AS719	Përçarës Piccolo 3	11089.97	\N	\N
1620	AS710	Vitrina Ftohëse Denver Perdhesa Deli(AR9	4036.41	\N	\N
1631	AS721	Makin Laminues per pasta  SSO5304.AO ECO	7641.06	\N	\N
1601	ARS067	Aristea Pjata Plastike Te Thella 203diam	3.69	8001909523166                                     	\N
1604	ARS070	Arista Pijata Të Thella 36/1x20	1.51	8001909400955                                     	\N
1627	AS717	Dozator i ujit DOX 25M	1659.93	\N	\N
1632	AS722	Mikser Planetar  Bear Teddy 5	959.11	\N	\N
1636	AS726	Thithese per tymëra 4T-60/80	1466.30	\N	\N
1637	AS727	Modul 4T-60/80	4850.77	\N	\N
1674	AS764	Dorëza prej pambuku per pjekje 360x150mm	21.06	\N	\N
1638	AS728	Gjenerator avulli 4T-60/80	599.46	\N	\N
1640	AS730	Qendrues me rrota 8514900000	636.30	\N	\N
1677	AS767	Lopata per furra buke 400x500mm	41.71	\N	\N
1643	AS733	Alu-Lim 600x800 3-anesore  me trashesi 1	21.26	\N	\N
1633	AS723	Tabel Friteze CE140	1624.38	\N	\N
1645	AS735	Alu-Lim 600x400 3-anesore me trashesi 1.	10.63	\N	\N
1609	ART125	Aeroplani i Kershendellave	0.00	\N	\N
1641	AS731	Kolica Inox per pjekje me 12 pllaka 60x8	424.19	\N	\N
1654	AS744	Rrjete skare GN1/1	147.81	\N	\N
1656	AS746	Rrjete Gn 1/1	29.35	\N	\N
1657	AS747	Pjate per pjekje Gn1/1	48.22	\N	\N
1651	AS741	Alu-Lim 600x400 2-ansore ,e trashesi 1.5	9.79	\N	\N
1612	ART132	Arush i vogel Tomi	0.00	\N	\N
1634	AS724	Mbushje per krofne	409.03	\N	\N
1646	AS736	Furrë per ftohje Tp 03 Mid	2490.57	\N	\N
1655	AS745	Kleri Gn 1/1	109.76	\N	\N
1652	AS742	Furre per pjekje Pro-Cook F-611	6942.80	\N	\N
1675	AS765	Furqë 40mm	6.16	\N	\N
1676	AS766	Furqë per pjekje 60mm	8.17	\N	\N
1639	AS729	Mbylles 4T-60/80 85149000	571.79	\N	\N
1647	AS737	Paisje per zbutjen e ujit Mini 10/Digi	774.65	\N	\N
1600	ARS066	Aristea Pjata Plastike Të Rrafshta 203di	1.82	8001909513051                                     	\N
1662	AS752	Skar per pula Gn 1/1	72.83	\N	\N
1658	AS748	Pijate per pjekje Inox  Gn1/1	36.42	\N	\N
1664	AS754	Luge Inox 33cm	19.26	\N	\N
1665	AS755	Lëmuese Inox 120x115mm	5.04	\N	\N
1666	AS756	Thika per pica 100mm	20.34	\N	\N
1661	AS751	Pijate Inox Gn 1/1-20	22.38	\N	\N
1668	AS758	Shport plastike 18cm	5.82	\N	\N
1621	AS711	Vitrina Ftohëse Denver Self Perdhesa Sam	1954.63	\N	\N
1673	AS763	Valak prej plastike 120mm	8.17	\N	\N
1672	AS762	Rroller 120mm	8.17	\N	\N
1602	ARS068	Aristea Pjata Plastike Të Rrafsha 203dia	3.49	8001909513167                                     	\N
1608	ART124	Irvasi Kengetar	0.00	\N	\N
1596	ARS062	Aristea Gota Kartoni 4oz 4/1x50	1.83	8001909041035                                     	\N
1630	AS720	Pezierse  2C 550	5631.96	\N	\N
1622	AS712	Vitrina Ftohëse Denver Perdhesa Meso(AR9	4128.68	\N	\N
1726	AS847	Elemente prej metali per rafta 1000X500	1.12	\N	\N
1697	AS787	Aroma per krofne	6.90	\N	\N
1727	AS848	Rrjjeta druri per rafte	21.36	\N	\N
1728	AS849	Rafta prej druri per dyqane	43.44	\N	\N
1685	AS775	Cereal Top	2.78	\N	\N
1699	AS789	Dyllet vegjetale-Trenwachs	6.12	\N	\N
1689	AS779	Krem qokollade me lajthi	4.14	\N	\N
1754	AS906	Gypa,Sy dhe Vrima,Grepa	0.00	\N	\N
1769	AVN005	Filter per lavaman L-110/P100	0.41	8693395001107                                     	\N
1691	AS781	Margarin Excellense	2.40	\N	\N
1775	AVN011	Varese per peshqir 2pc L-129/P60	0.54	8693395001299                                     	\N
1729	AS850	Rafte prej qelqi per dyqane	50.56	\N	\N
1706	AS796	Elemente per tavolina te arkes qe perdor	249.07	\N	\N
1730	AS851	Elemente prej metali per rafta	53.91	\N	\N
1732	AS853	Rafta prej plastike per dyqane	2.44	\N	\N
1738	AS890	Elemente per dyqane,lavaman,el.2nivelesh	748.69	\N	\N
1765	AVN001	Ene sapuni L-105/P36	1.12	8693395001053                                     	\N
1776	AVN012	Tharese sapuni L-133/P80	0.49	8693395001336                                     	\N
1700	AS790	Preparat ST35	6.56	\N	\N
1737	AS858	Tabel Pleksi Dim 700x160x5	25.38	\N	\N
1739	AS891	Pjese metali per mobilje dyqanesh-Ballor	0.00	\N	\N
1740	AS892	Pjes prej druri per mobile,korniza,pllak	58.49	\N	\N
1741	AS893	Mobile prej druri,kabina per ndrrimin e	789.38	\N	\N
1770	AVN006	Mbajtes luksoz i letrav higjenike L-116	0.69	8693395001169                                     	\N
1742	AS894	Mbylles prej plastike	0.00	\N	\N
1708	AS801	Karroca per perdorim ne market	114.95	\N	\N
1733	AS854	Elemente per Rafta prej metali	0.31	\N	\N
1734	AS855	Foli prej Pvc	4.48	\N	\N
1711	AS806	Pedale (P116248)	0.00	\N	\N
1712	AS811	Derë Hyrese per Marketa	4192.05	\N	\N
1756	AS908	Mbajtese me tri nivele	0.00	\N	\N
1714	AS814	Lidhëse per gypa 120mm	13.33	\N	\N
1736	AS857	Kutija prej plastike	10.58	\N	\N
1743	AS895	Artikuj te tavolines dhe te kuzhines	0.00	\N	\N
1744	AS896	Kosh prej Pvc i veshur me kashte	0.00	\N	\N
1745	AS897	Lule artificiale prej plastike	0.00	\N	\N
1719	AS826	Shporta per markete	10.07	\N	\N
1720	AS827	Karroca per markete	122.07	\N	\N
1721	AS828	Shporta per markete Shop&Roll	22.89	\N	\N
1766	AVN002	Mbajtes i brushave L-106/P24	1.34	8693395001060                                     	\N
1724	AS832	Paletë PA-X1/N	123.09	\N	\N
1747	AS899	Veshje per kuzhine	0.00	\N	\N
1777	AVN013	Pompë kremi L-134/P48	0.86	8693395001343                                     	\N
1682	AS772	Përzierse Madrepan	2.62	\N	\N
1688	AS778	Croissant perzierse	2.19	\N	\N
1762	AS914	Rafta per ekspozimin e mallit 1100x80	346.88	\N	\N
1731	AS852	Rryp per Qmime	1.63	\N	\N
1686	AS776	Barom	1.73	\N	\N
1681	AS771	Perzorese e paptates per buke	3.21	\N	\N
1683	AS773	Përkrahes baguette	3.21	\N	\N
1748	AS900	Shirita prej plastike	0.00	\N	\N
1684	AS774	Perzierese bakina	3.27	\N	\N
1750	AS902	Skelete te ndryshme per piktura etj..	0.00	\N	\N
1771	AVN007	Mbajtes letrave higjenike Corolla L-117	0.79	8693395001176                                     	\N
1751	AS903	Zingjire te ndryshem KT16	0.00	\N	\N
1752	AS904	Paisje prj alumini	0.00	\N	\N
1758	AS910	Kutija,Kasa etj..	0.00	\N	\N
1760	AS912	Foldera prej Pvc	0.00	\N	\N
1693	AS783	Mbushje Nakov+	3.92	\N	\N
1695	AS785	Double qokollate	3.30	\N	\N
1696	AS786	Qokollate e bardhë	3.13	\N	\N
1746	AS898	Kapse(mash) per ushqim	0.00	\N	\N
1709	AS802	Mobileri ftofse per ruajtjen e mallit	2889.98	\N	\N
1710	AS803	Pjes per montimin e mobileve ftofse	25.63	\N	\N
1715	AS815	Elemente per rafta,promovues,mbajtes,kem	71.21	\N	\N
1716	AS818	Tube prej gize dhe çeliku	28.58	\N	\N
1717	AS820	Mbullsa prej alumini	24.41	\N	\N
1753	AS905	Gypa,Rafta,Rrathe	0.00	\N	\N
1772	AVN008	Varese per rroba banjo 1pc L-124/P24	0.43	8693395001244                                     	\N
1755	AS907	Fllamastera 5mm,15mm,24mm	0.00	\N	\N
1764	AVA001	Detergjent Ava 4.2kg	0.00	\N	\N
1757	AS909	Elemente per rafta metali	0.00	\N	\N
1718	AS823	Mbullesa prej metali	12.21	\N	\N
1759	AS911	Kapse (masha) delikatesa	0.00	\N	\N
1725	AS833	Mbajtese Plastike per fruta	142.92	\N	\N
1761	AS913	Shporta plastike SOP&ROLL	26.60	\N	\N
1690	AS780	Pllaka prej kakaos	4.23	\N	\N
1735	AS856	Elemente per mbajtese te eneve	62.56	\N	\N
1778	AVN014	Mbajtes peshqiri L-139/P36	1.82	8693395001398                                     	\N
1702	AS792	Vitrina ftohëse Panama 2/85/216 250(AP96	4159.50	\N	\N
1703	AS793	Vitrina Ftohëse Panama 2 85/216 375(AP96	4524.69	\N	\N
1704	AS794	Vitrina ftohëse Panama 2 85/216 375 (AP9	5200.14	\N	\N
1773	AVN009	Varese per rroba banjo 2pc L-125/P60	0.79	8693395001251                                     	\N
1705	AS795	Vitrina ftohëse Panama  2GL 85/216 375 (	6244.84	\N	\N
1707	AS800	Vitrina Ftohese Panama 2/85/216	5442.24	\N	\N
1713	AS813	Vida per Rafte	0.07	\N	\N
1722	AS829	Vitrina Ftohëse Manhatan	3732.26	\N	\N
1767	AVN003	Mbajtes i letrave higjenike L-107/P50	0.79	8693395001077                                     	\N
1768	AVN004	Mbajtes per peshqirë L-108/P36	1.18	8693395001084                                     	\N
1692	AS782	Arra Fix Und Fertig	4.70	\N	\N
1694	AS784	Cakemix soft	3.45	\N	\N
1774	AVN010	Varese per peshqir 1pc L-128/P125	0.39	8693395001282                                     	\N
1698	AS788	Vaj Diamant Dritier	2.36	\N	\N
1790	AVN026	Leter per browni embelsira L-169/P50	0.71	8693395001695                                     	\N
1834	AVN070	Krypore Avantage L-302/P24	1.38	8693395003026                                     	\N
1835	AVN071	Enë per veze L-303/P60	0.49	8693395003033                                     	\N
1787	AVN023	Model kuarteti L-166/P72	0.60	8693395001664                                     	\N
1794	AVN030	Ndalues dere L-179/P100	0.60	8693395001794                                     	\N
1795	AVN031	Shtrydhëse limoni L-182/P75	0.43	8693395001824                                     	\N
1796	AVN032	Ene sapuni Yakamoz L-191/P50	0.99	8693395001916                                     	\N
1827	AVN063	Kuti ruajtese e mesme Bayleaf L-285/P60	0.60	8693395002852                                     	\N
1797	AVN033	Set per ene sapuni L-197/P40	0.67	8693395001978                                     	\N
1798	AVN034	Lopata 4 cpe L-198/P60	0.67	8693395001985                                     	\N
1801	AVN037	Kuti akulli diamond L-203/P80	0.96	8693395002036                                     	\N
1823	AVN059	Rende Smart L-275/P96	1.24	8693395002753                                     	\N
1806	AVN042	Shtrydhes limoni Lemonex L-217/P96	0.63	8693395002173                                     	\N
1807	AVN043	Qërues praktik L-220/P96	0.81	8693395002203                                     	\N
1828	AVN064	Kuti ruajtese e vogel Bayleaf L-286/P70	0.54	8693395002869                                     	\N
1829	AVN065	Qoshe (dollap) per banjo L-289/P12	5.18	8693395002890                                     	\N
1833	AVN069	Ndalës dere BSF-609/P2	0.54	8693395002999                                     	\N
1840	AVN076	Kuti e rrubmullaket per ushqim L-332/P96	0.91	8693395003323                                     	\N
1791	AVN027	Injektor kremi L-172/P48	0.86	8693395001725                                     	\N
1808	AVN044	Skalites perimesh L-222/P100	0.47	8693395002227                                     	\N
1792	AVN028	Gurë per kallo(kembeve) L-174/P60	0.49	8693395001749                                     	\N
1814	AVN050	Ruajtës i qepës L-247/P96	0.80	8693395002470                                     	\N
1793	AVN029	Formësues i vogel per embelsira L-175/50	0.99	8693395001756                                     	\N
1809	AVN045	Qërues ekomomik horizontal L-232/P144	0.45	8693395002326                                     	\N
1799	AVN035	Set per brusha L-199/P40	0.93	8693395001992                                     	\N
1815	AVN051	Ruajtës i hudhrës L-248/P96	0.54	8693395002487                                     	\N
1816	AVN052	Ruajtës i vertikal L-250/P144	0.60	8693395002500                                     	\N
1819	AVN055	Prerës djathi L-264/P144	0.47	8693395002647                                     	\N
1820	AVN056	Ene me kullosjë L-266/P24	1.18	8693395002661                                     	\N
1822	AVN058	Kuti ruajtese e madhe Elegance L-268/P40	1.04	8693395002685                                     	\N
1824	AVN060	Filter(kullojsë) orizi L-280/P36	0.99	8693395002807                                     	\N
1825	AVN061	Ene per djathë Venus L-281/P24	1.54	8693395002814                                     	\N
1832	AVN068	Rende magjike L-296/P72	1.36	8693395002968                                     	\N
1830	AVN066	Ene sapuni Coral L-293/P120	0.60	8693395002937                                     	\N
1837	AVN073	Brushë per veze L-318/P150	0.35	8693395003187                                     	\N
1836	AVN072	Dërrasë per prerje L-304/P24	2.87	8693395003040                                     	\N
1780	AVN016	Kuti sapuni Avantage L-147/P120	0.54	8693395001473                                     	\N
1781	AVN017	Mbajtes druri mbrapa deres L-148/P24	2.72	8693395001480                                     	\N
1782	AVN018	Mbajtes i dyfishtë 2pc L-149/P50	0.63	8693395001497                                     	\N
1783	AVN019	Formësues metali per embelsira L-155/P36	1.64	8693395001558                                     	\N
1784	AVN020	Formësues metali per biskota L-156/P36	1.24	8693395001565                                     	\N
1800	AVN036	Filter per lavaman L-201/P120	0.35	8693395002012                                     	\N
1785	AVN021	Mbajtes i letrave higjen.Yakam L-161/P36	1.28	8693395001619                                     	\N
1786	AVN022	Formësues biskotash L-163/P36	0.67	8693395001633                                     	\N
1810	AVN046	Filter Nr.12 L-240/P36	0.60	8693395002401                                     	\N
1811	AVN047	Filter Nr.17 L-241/P36	0.63	8693395002418                                     	\N
1812	AVN048	Filter Nr.22 L-242/P36	0.86	8693395002425                                     	\N
1813	AVN049	Filter per tenxhere L-245/P48	0.99	8693395002456                                     	\N
1803	AVN039	Ene per vezë L-210/P48	0.74	8693395002104                                     	\N
1805	AVN041	Dorëza Avantage L-212/P50	0.81	8693395002128                                     	\N
1788	AVN024	Formësues embelsirash L-167/P50	0.60	8693395001671                                     	\N
1817	AVN053	Qërues  horizontal L-251/P144	0.60	8693395002517                                     	\N
1804	AVN040	Mbajtes per veze me pjate L-211/P48	0.61	8693395002111                                     	\N
1826	AVN062	Kuti ruajtese e madhe Bayleaf L-284/P48	0.85	8693395002845                                     	\N
1789	AVN025	Leter e madhe per embelsira L-168/P50	0.60	8693395001688                                     	\N
1818	AVN054	Filter elegant L-261/P36	1.28	8693395002616                                     	\N
1821	AVN057	Kuti ruajtese e vogel Elegance L-267/P80	0.63	8693395002678                                     	\N
1851	AVN087	Kullojsë per oriz L-388/P36	0.97	8693395003880                                     	\N
1894	AXH012	Ajax Glass Blue F.(TA) Trigger 12/750ml	2.40	8718951048461                                     	\N
1886	AVN122	Lopatë ushqimi 2/1 L-466/P10	1.04	8693395004665                                     	\N
1887	AVN123	Shtrydhëse lemoni L-464/P10	0.95	8693395004641                                     	\N
1888	AVN124	Tas mikseri Eco L-418/P10	2.08	8693395004184                                     	\N
1889	AVN125	Kuti ushqimi L-408/P10	1.24	8693395004085                                     	\N
1852	AVN088	Dërrasë per prerje L-389/P40	1.62	8693395003897                                     	\N
1855	AVN091	Ruajtes per qepë Union L-393/P72	0.49	8693395003934                                     	\N
1856	AVN092	Ruajtes per hudher Union L-394/P96	0.43	8693395003941                                     	\N
1860	AVN096	Kuti per ruajtjen e Bukë-Tost L-405/P36	1.67	8693395008007                                     	\N
1844	AVN080	Lugë jo-ngjitëse L-380/P36	0.80	8693395003804                                     	\N
1845	AVN081	Lugë jo-ngjitëse me vrima L-381/P36	0.80	8693395003811                                     	\N
1861	AVN097	Kullojsë çaji BSF-505 50/1/P5000	0.39	8693395005051                                     	\N
1862	AVN098	Enë per sheqer BSF-534/P45	0.63	8693395005341                                     	\N
1863	AVN099	Shtypës hudhre Eco Press BSF-539/P96	1.04	8693395005396                                     	\N
1864	AVN100	Qerues Avantage BSF-543/P120	0.63	8693395005433                                     	\N
1893	AXH009	Ajax Glass Crystal Trigger 12/750ml	2.40	8718951048522                                     	\N
1895	AXH013	Ajax Glass&Multisurfaces Vinegar 750ml t	0.00	8714789562650                                     	\N
1896	AXH014	AJAX Glass Lemon 750ml trigger/ Pako 12	1.87	8714789605258                                     	\N
1897	AXH016	Ajax Glass &Shiny Surfaces 12/750ml	2.40	8718951048799                                     	\N
1898	AXH017	Ajax Glass Green Trigger 12/750ml	2.40	8714789842486                                     	\N
1899	AXH018	Ajax Glass Pink 750ml pomp/12	1.87	\N	\N
1900	AXH019	Ajax Glass Pink 750ml trigger/P12	0.00	\N	\N
1901	AXH021	Ajax Glass Crystal Refill 12/750ml	1.99	8718951048553                                     	\N
1902	AXH022	Ajax Glass Pink Trigger 12/750ml	2.35	8718951048669                                     	\N
1843	AVN079	Garuzhdë Avantage L-379/P36	0.88	8693395003798                                     	\N
1853	AVN089	Kuti e vogel per mikrovalë L-391/P32	1.04	8693395003910                                     	\N
1854	AVN090	Kuti e madhe per mikrovalë L-392/P24	1.32	8693395003927                                     	\N
1876	AVN112	Tas i vogel color L-468/P10	0.68	8693395004689                                     	\N
1883	AVN119	Set servisimi 5/1 L-445/P10	4.39	8693395004450                                     	\N
1842	AVN078	Qerues hudhrash Design L-373/P144	0.85	8693395003736                                     	\N
1848	AVN084	Shtypës patatesh L-384/P36	0.80	8693395003842                                     	\N
1846	AVN082	Kullesë jo-ngjitëse L-382/P36	0.88	8693395003828                                     	\N
1849	AVN085	Garuzhdë per makarona L-385/P36	0.79	8693395003859                                     	\N
1865	AVN101	Qerues Avantage BSF-544/P120	0.70	8693395005440                                     	\N
1866	AVN102	Lugë per akullore BSF-545/P60	0.63	8693395005457                                     	\N
1867	AVN103	Preres picash BSF-547/P120	0.93	8693395005471                                     	\N
1857	AVN093	Ruajtes per lemon L-395/P72	0.56	8693395003958                                     	\N
1868	AVN104	Preres brumi BSF-548/P120	1.11	8693395005488                                     	\N
1847	AVN083	Kullesë jo-ngjitëse per rrotul.L-383/P36	0.80	8693395003835                                     	\N
1859	AVN095	Ruajtes per veze L-404/P60	1.00	8693395004047                                     	\N
1850	AVN086	Dispenser sapuni L-387/P42	1.74	8693395003873                                     	\N
1878	AVN114	Kuti ruajtëse plastik 3/1 L-437/P10	1.97	8693395004375                                     	\N
1879	AVN115	Kuti ruajtëse me vakum Venus L-471/P10	2.15	8693395004719                                     	\N
1880	AVN116	Ruajtëse ushqimi L-439/P3	1.60	8693395004399                                     	\N
1882	AVN118	Kuti ruajtëse mini vakum L-470/P10	1.93	8693395004702                                     	\N
1881	AVN117	Korent mini per tepia L-420/P10	1.08	8693395004207                                     	\N
1869	AVN105	Gdhendës per perime BSF-549/P60	0.43	8693395005495                                     	\N
1870	AVN106	Lugë per akullore BSF-557/P60	0.65	8693395005570                                     	\N
1884	AVN120	Hapëse L-438/P10	0.76	8693395004382                                     	\N
1871	AVN107	Preres i madh brumi BSF-561/P50	1.85	8693395005617                                     	\N
1872	AVN108	Ice Box BSF-564/P100	0.99	8693395005648                                     	\N
1873	AVN109	Mbajtëse pallomash L-452/P10	1.02	8693395004528                                     	\N
1874	AVN110	Mbajtëse per brusha L-426/P10	0.82	8693395004269                                     	\N
1875	AVN111	Mbajtëse sapuni L-425/P10	0.59	8693395004252                                     	\N
1877	AVN113	Tel per rroba L-436/P30	8.12	8693395004368                                     	\N
1885	AVN121	Mbajtëse pallomash L-399/P10	1.62	8693395003996                                     	\N
1891	AXH007	Ajax Window Blue pompe 750ml/Pako 12	0.00	8714789255989                                     	\N
1903	AXH023	Ajax W.Crystal 750ml+750ml refill /P6	3.41	87140002                                          	\N
1892	AXH008	Ajax Window Vinegar pompe750ml/Pako 12	0.00	\N	\N
1905	AXH025	Ajax xhamash 750ml+Pulirapid 500ml Super	3.33	3908920740044                                     	\N
1906	AXH026	Ajax Glass TA 750ml + Ajax Glass free	1.54	3908920740440                                     	\N
1907	AXH027	Ajax Sc Pure Home Apple 750ml/P12	1.87	8718951256361                                     	\N
1908	AXH028	Ajax Sc Pure Home Ede 750ml/P12	1.87	8718951256392                                     	\N
1909	AXH029	Ajax glass triple action trigger 750ml	1.23	\N	\N
1910	AXH10	Ajax Window Crystal pa pompe 750ml/P.12	1.54	8714789256009                                     	\N
1938	015	Burim Mulaj	0.00	\N	\N
1949	028	Lulzim Hashani	0.00	\N	\N
1950	029	Maliq Krasniqi	0.00	\N	\N
1951	031	Mexhid Lanaj	0.00	\N	\N
1952	032	Naim Mahmuti	0.00	\N	\N
1953	034	Perparim Fazlija	0.00	\N	\N
1954	035	Petrit Krasniqi	0.00	\N	\N
1955	037	Qazim Bujupi	0.00	\N	\N
1956	038	Ylber Elshani	0.00	\N	\N
1957	039	Xhevat Duraku	0.00	\N	\N
1958	040	Valon Bujupi	0.00	\N	\N
1960	042	Caner Spahi	0.00	\N	\N
1961	043	Milazim Shahini	0.00	\N	\N
1962	044	Fidan KOZMETIK	0.00	\N	\N
1963	046	Selim Shala	0.00	\N	\N
1964	047	Qazim Gashi	0.00	\N	\N
1965	048	Hysen Hajdini	0.00	\N	\N
1966	049	Labinot Isufi	0.00	\N	\N
1967	053	Debatik Hakiqi	0.00	\N	\N
1968	054	Drilon Duraku	0.00	\N	\N
1969	057	Skender Hasani	0.00	\N	\N
1970	058	Berat Kurtaj	0.00	\N	\N
1971	059	Bujar Rushiti	0.00	\N	\N
1972	061	Sabri Vatovci	0.00	\N	\N
1973	062	Senad Bejiqi	0.00	\N	\N
1975	066	Leotrim Osmani	0.00	\N	\N
1976	068	Kamer Halilaj	0.00	\N	\N
1977	069	Granit Jashanica	0.00	\N	\N
1978	071	Milaim Hiseni	0.00	\N	\N
1979	073	Hajdini Ledo	0.00	\N	\N
1980	074	Qamil Kurtaj	0.00	\N	\N
1981	075	Denis Bylykbashi	0.00	\N	\N
1982	076	Elizabeta	0.00	\N	\N
1983	078	Erion Duraku	0.00	\N	\N
1984	079	Fatmir Shurdhiqi	0.00	\N	\N
1985	080	Gezim Krasniqi	0.00	\N	\N
1986	084	Florent Tahiraj	0.00	\N	\N
1987	087	Festim Kastrati	0.00	\N	\N
1989	10831	10831-GE Poqa 25 w/230v/Pako 50	0.00	5994102329662                                     	\N
1990	150	150 C - jaPZ	0.00	\N	\N
1991	200	HOREKA	0.00	\N	\N
1992	26447	GE Poqa 15w/FLE15TBXT3827/E27/8	2.65	0043168264471                                     	\N
1993	34883	GE Poqa 18W/T8/54/GE/ 25	0.87	0043168348836                                     	\N
1994	40443	40443-GE Poqa 20W/220-240V/*10	0.00	0043168404433                                     	\N
1995	56	Skender Hasani	0.00	\N	\N
1996	57	Skender Hasani	0.00	\N	\N
1997	704	Shitja e punimeve dhe sherbimeve 18%	0.00	\N	\N
1998	705	Shitja e punimeve dhe sherbimeve 8%	0.00	\N	\N
1999	84759	GE Poq Inkandeshent 100W/240V/120	0.88	0043168199490                                     	\N
2000	90543	GE Poqa 75W/230 V/ 50	0.95	5994102282073                                     	\N
2001	91095	GE Poqa 100W/230 V/20	2.74	5994102287146                                     	\N
2002	91700	GE Poqa 100W/230 V/50	0.99	0043168333375                                     	\N
2003	999998	TEST FISNIK NIKOLA	0.00	\N	\N
2005	BAD001	Kisko Uthull Molle 5% 12/1L	1.44	3850164340118                                     	\N
1911	AXH11	Ajax Window Vinegar pa pompe750ml/Pako 1	0.00	\N	\N
15	AHM010	Ahmad Tea Fruta Mali Hibiskus 6/(20x2g)	1.73	054881000055                                      	\N
50	AHM045	Ahmad Tea Peach& Passionfruit 12/(10x2g)	0.85	054881004299                                      	\N
67	AIA016	Mushkeri zogu A6539 / 10kg/P1	10.22	1241256632514                                     	\N
72	AIA021	Nuggets pule me spinaq 300g A8046/P9	1.91	AIA021                                            	\N
109	AIA059	AIA Wudy Pop 500gr+virshlle 100gr gratis	1.14	3908920750357                                     	\N
138	ALF007	ROLLS MINI FETA CHEESE 500G	0.00	\N	\N
142	ALK001	Liker Kruskovac 25% 1L Maraska/P6	7.44	3850158403607                                     	\N
166	ALP009	Alpro pije e ëmbël Orizi 1l/P12	1.88	5411188111375                                     	\N
1912	001	Abaz Mulaj	0.00	\N	\N
1913	002	Aftim Baliu	0.00	\N	\N
1914	003	Albert Deliu	0.00	\N	\N
1915	004	Arben Berisha	0.00	\N	\N
1916	005	Ardian Mulaj	0.00	\N	\N
1917	006	Arberim Mjekiqi	0.00	\N	\N
1918	007	Arsim Krasniqi	0.00	\N	\N
1919	008	Artan Maliqi	0.00	\N	\N
1920	009	Arian Gucati	0.00	\N	\N
1921	010	Asman Haliti	0.00	\N	\N
1922	011	Azem Smakiqi	0.00	\N	\N
1923	050	A.Shatri	0.00	\N	\N
1924	051	Arian Terdevci	0.00	\N	\N
1925	052	Arlind Gashi	0.00	\N	\N
1926	055	Arton Duraku	0.00	\N	\N
1927	060	Amir Rashica	0.00	\N	\N
1928	063	Arben Thaqi	0.00	\N	\N
1929	067	Artani Elshani	0.00	\N	\N
1930	070	Arsim Bogici	0.00	\N	\N
1931	077	Auron	0.00	\N	\N
1932	081	Avni Morina	0.00	\N	\N
1934	083	Arbes	0.00	\N	\N
1935	01	RENAULT TIPI MASTER FRIGO CCM 2299	0.00	\N	\N
1936	012	Besim Ademi	0.00	\N	\N
1937	014	Blerim Beka	0.00	\N	\N
1939	016	Dionis Abazi	0.00	\N	\N
1940	017	Enver Krasniqi	0.00	\N	\N
1941	018	Fisnik Hoxha	0.00	\N	\N
1942	019	Fejz Halilaj	0.00	\N	\N
1943	020	Idriz Sadiku	0.00	\N	\N
1945	023	Kushtrim Baliu	0.00	\N	\N
1946	024	Kushtrim Pllana	0.00	\N	\N
1947	025	Leart Bullaku	0.00	\N	\N
1948	026	Leotrim Muzhaku	0.00	\N	\N
1001	ari161	Pantene R&P 600ml+200ml Gratis/6	0.00	4084500580190                                     	\N
1067	ARI242	Pantene 2in1 Classic Clean 200ml/Pako 6	0.00	5011321620667                                     	\N
1285	ARI416	W&GO Chamomile 400ml/Pako 6	0.00	5011321957961                                     	\N
1409	ARI665	Always Ultra Normal PI 10/Pako16	0.00	4015400500919                                     	\N
990	ari1494	Always ULT Duo Super PLus/Pako12	0.00	4015400006756                                     	\N
962	ARI089	Fairy Apple 1L /pako 10	0.00	5413149137158                                     	\N
1078	ARI257	Fairy Sensitiv 500ml/Pako 21	0.00	5413149349209                                     	\N
1166	ari3516	Fairy Pomgrnt&Red 450ml/Pako21	0.00	4084500981898                                     	\N
1177	ari3545	Fariy Chamomile&vit 900ml/Pako10	0.00	4084500981492                                     	\N
1250	ari3943	Fairy Ss Tea Tree&Mi 1,350L/Pako9	0.00	4084500981256                                     	\N
731	APK096	Ajax Professional Multipurpose Trigger 1	2.97	8718951277410                                     	\N
1026	ARI196	Pantene Anti Harifa 250ml/Pako6	0.00	4084500146419                                     	\N
1243	ari3936	H&Sh Citrus Fresh 750ml + 200ml/PAko6	0.00	4084500958715                                     	\N
1381	ARI637	Lenor Tropical Fresh 1L /Pako 12	0.00	5413149584587                                     	\N
1391	ARI647	Pantene Nature Fusio 400ml/Pako6	0.00	5410076566402                                     	\N
598	ANM130	SPONTEX-0072-Shpuz Qeliku 6/1/Pako 6	2.90	\N	\N
1084	ARI277	Gillette shkum rroje 200ml/Pako6	0.00	3014260228743                                     	\N
744	APK109	Ajax Power Mousse Multi-purpos 12/500ml	2.97	8718951644021                                     	\N
519	ANM047	SPONTEX Rolne pastrim tekstili 0804 /P48	1.21	9001378800804                                     	\N
1153	ARI343	Lenor Sensitiv 2L/Pako8	0.00	5413149586895                                     	\N
1213	ARI372	H&SH Ocean energy 750ml+200ml gratis*6	0.00	5013965670954                                     	\N
1244	ari3937	H&Sh Mentoll 750ml + 200ml/PAko6	0.00	4084500697102                                     	\N
1316	ARI517	H&SH Menthol 750ml+SHKUM gratis/Pako 6	0.00	5013965974335                                     	\N
1115	ARI309	Always duo Super Plus 16x14/Pako16	0.00	4015400523079                                     	\N
1439	ARI692	Pantene Conditioner Aqua Light 250ml /Pa	0.00	5013965695957                                     	\N
200	ALT022	ELG360-Gota Whisky 315 6/1/P8	3.65	8692952016387                                     	\N
210	ALT032	LUN337-Gota Whisky 325cc/Pako 48	0.52	8692952048159                                     	\N
241	ALT063	Altanlar-Tenxhere Expreks 5LT 4/1/Pako4	17.38	8697414823572                                     	\N
260	ALT082	ZEN277-Tablla  Qaji 6/1/P12	1.77	8692952057823                                     	\N
277	ALT099	KYF72-Shpuzore e madhe 2/1/P24	1.09	8692952001208                                     	\N
308	ALT130	K003DM00-Qajnik i madhe Porcelan/P6	10.31	150414                                            	\N
322	ALT146	A-105-Talya tharese per rroba	16.85	8699349540142                                     	\N
337	ALU007	Leter per pjekje 200m*43cm/P6	21.18	9001376775500                                     	\N
368	ALU038	Tabakë per servim 2/1 545x360mm/P25	3.11	9001376088853                                     	\N
384	and008	O Fresh Pepermint Sadet 15gr/Pako24	0.00	8693323342203                                     	\N
393	and017	Akullore Qoko-Banane 75gr Eskimko/Pako30	0.00	8606015710266                                     	\N
539	ANM067	Spontex Mbules per Hekurosje  135*46(022	3.38	9001378210221                                     	\N
577	ANM106	SPONTEX 0579 Shpuze antibak.2/1/Pako 18	1.38	9001378700579                                     	\N
657	APK003	Ajax Baking Orange Lemon 1000ml/P.12	1.83	5900273476258                                     	\N
780	ARC011	G9496- Bime clear transp Buller Tum./P24	0.93	0883314198058                                     	\N
792	ARC023	D7499- Tempe.Multi   Purepose Bowl/P48	2.28	0026102413920                                     	\N
930	ari004	W&Go Blossm&Gree 400ml/Pako6	0.00	4015600827779                                     	\N
999	ARI16	FA DEO STICK 50ML SPICY BLACK	0.00	\N	\N
1321	ARI521	W&Go Herbal Coctail 750ml+Balsam gratis/	0.00	5013965972737                                     	\N
1346	ARI604	Fairy Water Liliy& Jojoba 500ml Pako 21	0.00	540076198306                                      	\N
465	ANL051	Choko Peanut Crem 250g Lexus/P12	1.47	8699462609603                                     	\N
430	ANL016	Kinder top CHAMPION  30gr /P24x6	0.26	8699462606008                                     	\N
448	ANL034	Kinder Ve 25g PRINCESS/P24x6	0.21	8699462604875                                     	\N
497	ANM025	Leter-4082-per pjekje 39*8 Alupack/P30	1.01	3856004914082                                     	\N
599	ANM131	SPONTEX-1641-Leck per pastrim Top 5/1/16	1.12	9001378421641...                                  	\N
700	APK065	Ajax APC Mediterranean Red 750ml/P12	1.34	8714789915227                                     	\N
807	ARC038	E5060- Elegance Stemmed 3/1Glass/P6	4.09	0026102399064                                     	\N
858	ARC090	E9346- Elegance world 4/1w.Experienc/P4	10.59	0883314138870                                     	\N
865	ARC097	20584- Tempe. poeme Rose 19pc 1/1	48.23	0026102205846                                     	\N
843	ARC075	H3658-Tempe. White quadrato dessert/P24	3.76	0026102077122                                     	\N
897	ARC129	H4910-Tempered ene little flowers/P24	2.34	0883314230574                                     	\N
665	APK026	Ajax Fdf Flowers of Spring 1000@1250ml/P	0.00	\N	\N
666	APK028	Ajax Fdf Lagoon Flowers 1000@1250ml/Pako	0.00	8714789310534                                     	\N
919	ARF005	Saponia Arf Xhamash Lavanda 12/650ml	1.59	3850105181138                                     	\N
1462	ARI714	H&SH Citrus 400ml+Co /Pako6	0.00	5410076637829                                     	\N
1472	ari724	H&Sh Ocean 750+200ml/Pako6	0.00	5410076818365                                     	\N
1503	ari771	Ariel Tol Relaxed 2Kg/Pako6	0.00	5413149645080                                     	\N
1671	AS761	Rroller 110x150	139.96	\N	\N
1904	AXH024	Ajax Triple Action+Crystal pa pompe750ml	3.41	87141115                                          	\N
5139	266	266 ledo	0.00	\N	\N
5140	267	267 ledo	0.00	\N	\N
5141	84810	GE Poq elektrik TU 60D1/FR/E27 240V 10/5	0.91	5994102283001                                     	\N
5234	030	Mehmet Rexhepi	0.00	\N	\N
5235	036	Remzi Gerguri	0.00	\N	\N
5236	045	Shof.KOZMETIK	0.00	\N	\N
1701	AS791	Vitrina Ftohëse Panama 2 85/216 250 (AR9	4238.59	\N	\N
5615	BFF006	Vaj per femije 200ml Pielor/P24	1.62	8699954153010                                     	\N
5618	BUR132	Vaskë transparente për foshnje Follow me	5.96	8694917002657                                     	\N
1779	AVN015	Rende Avantage L-145/P96	0.86	8693395001459                                     	\N
5657	BAD012	Uthull vere bardh 0.5  5% Kisko/Pako 20	0.00	\N	\N
5658	BAD013	Kisko Uthull Vere 6% 12/0.5L	0.80	3850164321148                                     	\N
4514	BAD008	Uthull alkoholi 3l  9% Kisko/Pako 3	2.08	3850164310180                                     	\N
4515	BAD009	Kisko Uthull Alkooli 9% 12/1L	0.99	3850164310111                                     	\N
4516	BAD010	Uthull alkoholi 0.75  9% Kisko/Pako 20	0.00	\N	\N
4517	BAD011	Uthull vere e bardhë 1l  5% Kisko/Pako 1	0.00	3850164321216                                     	\N
4518	00	BLERS	0.00	\N	\N
4519	013	Besim Rexhepi	0.00	\N	\N
4520	056	BLERIM GJINOFCI	0.00	\N	\N
4574	065	Kreshnik Bekteshi	0.00	\N	\N
1544	ARS010	Aristea Thika plastike te bardha 100në1/	0.55	8001909927902                                     	\N
622	ANM154	Spon-Leck pastrimi 10/1 +sungjer 5/1 gra	2.07	3908920730304                                     	\N
5135	072	Rexhep Ledo	0.00	\N	\N
5136	100	Ne DEPO	0.00	\N	\N
5137	260	260 ledo	0.00	\N	\N
5138	261	261 ledo	0.00	\N	\N
5237	33928	GE Poq elektrik OT FLE7SPH/T2/827/E14/18	3.25	0043168339285                                     	\N
5238	61502	GE Poq Ekonomik 11W E27/10	2.39	043168404389                                      	\N
5239	61504	GE Poq Ekonomik 20W E27/10	2.88	043168615044                                      	\N
5240	88176	GE Poq 15W/220-240V/6	5.35	0043168881760                                     	\N
5241	88209	GE Poq Ekonomik 12W E27/6	4.88	043168458375                                      	\N
5242	91533	GE Poq thjeshte 40W/230 V/25	1.86	5994102356156                                     	\N
1687	AS777	Krofne me Vezë	2.67	\N	\N
1587	ARS053	155850-Pjata plasike 170cc red/P20	1.95	8001909558502                                     	\N
1642	AS732	Kolica  Inox per pjekeje me 16 pllaka 60	424.19	\N	\N
1749	AS901	Paisje te ndryshme prej plastike	0.00	\N	\N
1890	AXH006	Ajax Window Antistatic pompe 750ml/P.12	1.87	8714789256047                                     	\N
5590	197 KOZ	197 KOZ	0.00	\N	\N
5591	199 KOZ	199 KOZ	0.00	\N	\N
5616	BUR130	Vaskë për foshnje Follow me/P1	5.17	8694917000080                                     	\N
5617	BUR131	Vaskë për foshnje Follow me 311802/P1	7.18	8694917003586                                     	\N
1723	AS830	Shporta,tavolina  per ekspozimin e malli	110.88	\N	\N
5659	BAD015	Uthull vere e aromatizuar 0.5l Kisko/P6	2.36	3850164330997                                     	\N
5660	BAD016	Uthull vere mediteran 0.5l Kisko/P6	2.51	3850164310999                                     	\N
5661	BAL012	Biskota Balocco Vita Mia, pa sheqer 325g	1.99	8001100066912                                     	\N
1802	AVN038	Shtrydhese Limoni Titanic L-206/P44	1.08	8693395002067                                     	\N
1838	AVN074	Kuti katrore per ushqim L-328/P90	0.91	8693395003286                                     	\N
1841	AVN077	Ene per grimcarina Lux L-363/P36	0.86	8693395003637                                     	\N
199	ALT021	ELG353-Gota Uji190cc 6/1/P8	3.16	8692952078224                                     	\N
1933	082	Ardin Feta	0.00	\N	\N
1944	021	Ilir Kushumlia	0.00	\N	\N
1959	041	Bastri Skeraj	0.00	\N	\N
1974	064	Hamdi Krasniqi	0.00	\N	\N
1988	10456	GE Poq CIrcline Daylight 32W/12	4.74	0043168104562                                     	\N
2004	BAB001	Faculeta te lagura BabyMondo 64/1/P12	0.99	3859892397135                                     	\N
1528	ari953	Blue 3 Sens Care 3CT/PAko12	0.00	7702018361892                                     	\N
1680	AS770	Bollgur drithrash pej misri	1.82	\N	\N
4573	033	Endrit Budeci	0.00	\N	\N
1589	ARS055	205053-Gota plastike light blue 25/1/P25	1.39	8001909050532                                     	\N
1595	ARS061	216738-Gota plast.166cc brown 100/1/P30	0.00	8001909167780                                     	\N
1763	ASR001	Ajax Detergent Laundry Bar  2*300g/P36	1.81	8003520000729                                     	\N
1858	AVN094	Mbajtes per peshqir Pearl L-400/P50	1.11	8693395004009                                     	\N
4909	33763	GE Poq elektrik OT FLE9CDL/T2/827/E27/18	3.47	0043168337632                                     	\N
4508	BAD002	Uthull molle 0.75l  5% Kisko/Pako 20	0.00	\N	\N
5697	BID006	Kaçkavall i perzier	7.47	2704747003703                                     	\N
5698	BID007	Kaçkavall i dhenve	8.24	2704748004129                                     	\N
5699	BID013	Pavllak Bimilk 20% 180g 2+1gratis/6	0.69	53100115                                          	\N
5700	BID014	Bimilk Pavllak Bitolska 20% 6/400ml	1.12	5310054003076                                     	\N
5701	BID016	Pavllak Bimilk 20% 500g/P6	0.74	5310054000365                                     	\N
5702	BID022	Bimilk Pavllak Bitolska 20% 6/700ml	2.01	5310054000150                                     	\N
5703	BIJ012	Jogurt Bimilk VIVA 1% 1L/Pako 12	0.00	\N	\N
5704	BIJ016	Frigorifera vertikal VK 400C	0.01	\N	\N
5705	BIJ025	Jogurt Balans mollë, kanellë dhe vanilje	0.47	5310054000976                                     	\N
5706	BIJ029	Jogurt Balans mollë,kanellë dhe van.2+1	0.93	5310054001560                                     	\N
5707	BIQ002	Qumesht Vitaminoz Bimilk UHT 1.5% 1L/P12	0.83	\N	\N
5708	BIQ005	Bimilk Qumësht me 10 Vitamina 2.8% 12/1L	1.40	5310054000037                                     	\N
5709	BIQ009	Qumesht me qokollade Bimilk+10Vitamin, 1	1.17	5310054002499                                     	\N
5710	BIQ010	Qumesht me qokollade Bimilk+10Vitamin, 0	0.74	5310054002505                                     	\N
5711	BIS002	Biser Shampon Kopriva 500ml/ Pako 12	0.62	8600208000721                                     	\N
5712	BIS003	Biser Shampon Aloe Vera 500ml/ Pako 12	0.66	8600208003098                                     	\N
5713	BIS005	Biser Shampon Kopriva 1L/ Pako 8	0.88	8600208002381                                     	\N
5714	BIS006	Biser Shampon Aloe Vera 1L/ Pako 8	0.93	8600208003043                                     	\N
5716	BIS025	Biser Pastrues Universal 750ml pompe/P8	1.26	8600208003623                                     	\N
5717	BIS032	Biser Varikin Bella 1L/ Pako 6	0.89	8600208000639                                     	\N
5718	BIS034	Biser Paste abrazive per larjen e duarve	0.79	8600208001025                                     	\N
5719	BIS036	Biser Kopriva 1l + Biser Kopriva 500ml G	0.00	\N	\N
5720	BIS037	Biser Aloe Vera 1l + Biser Aloe Vera 500	0.00	\N	\N
5721	BRI003	Kaqkavall Petali GranBiraghi 100g/P12	1.50	8002004824219                                     	\N
5722	BUL009	Motta Panettone Tartufone V.Box 8/800g	8.79	8034097876424                                     	\N
5723	BUL010	Bauli Panettone Tartufone V.Box 8/800g	11.99	8034097874253                                     	\N
5724	BUR029	Enë e vogël me kapak -1 (1,2 lt) Follow	0.64	8694917001865                                     	\N
5725	BUR030	Enë e vogël me kapak -2 (1,8 lt) Follow	0.89	8694917001872                                     	\N
5726	BUR031	Enë e vogël me kapak -3 (2,8 lt) Follow	1.21	8694917001889                                     	\N
5663	BAL021	Balocco Biskota Novellini 10/350g	1.73	8001100012384                                     	\N
5664	BAL029	Napolitankë kubëza me qumësht vanile, Ba	1.48	8001100059266                                     	\N
5665	BAL030	Savoiardi, Balocco 200gr/P15	1.15	8001100012018                                     	\N
5666	BAU003	Jogurta Fru Fru vishnje  0.1% 100g Bauer	0.25	\N	\N
5667	BAU007	Jogurta Fru Fru vishnje 0.1% 150g Bauer/	0.33	\N	\N
5668	BAU019	Jogurt vishnje e freskët 3.5% 4x100g/P10	1.17	\N	\N
5669	BAU022	Jogurta Sahne të freskëta krem vishnje 1	0.42	\N	\N
5670	BAU025	Mövenpick Ice Coffe Espresso 10/200g	0.92	4002334110307                                     	\N
5671	BAU026	Mövenpick Ice Coffee Machiato 10/200g	0.92	4002334110314                                     	\N
5672	BAU027	Mövenpick Ice Coffee Cappuccino 10/200g	0.92	4002334110321                                     	\N
5673	BAU038	Jogurt pa sheqer vishnje 1.8% 150g/P20	0.40	\N	\N
5674	BAU046	Jogurt orizi  me vishnje 3.5% 200g/P12	0.53	\N	\N
5675	BAU055	Mövenpick Coffe Freddo Espresso 10/ 200g	0.00	\N	\N
5676	BAU056	Mövenpick Caffe Freddo Macchiato 10/200	0.00	\N	\N
5677	BAU057	Mövenpick Caffe Freddo Cappucino 10/200g	0.00	\N	\N
5678	BES004	Ajvar 720 ml Besfood/P12	0.00	\N	\N
5680	BFF053	Maske  per floke Olive Oil 500ml/P12	1.84	8699954105019                                     	\N
5681	BFF076	Maske  per floke Olive Oil 500ml/P12	1.84	8699954105026                                     	\N
5682	BFF090	Sapun i lenget Mediterrenean Olive 500ml	1.02	8699954130059                                     	\N
5683	BFF092	Sapun i lenget Vanilla Dreams 500ml/P12	1.02	8699954130073                                     	\N
5684	BFF101	Shower Gel Vanilla Dreams 300ml Pielor/P	0.95	8699954131070                                     	\N
5685	BFF108	Shower Gel Nat.Aloe Vera 300ml Pielor/P2	0.95	8699954137058                                     	\N
5686	BFF113	Spray trupi Mediterrenean Olive 200ml Pi	1.45	8699954133050                                     	\N
5687	BFF115	Spray trupi Vanilla Dreams 200ml Pielor/	1.45	8699954133074                                     	\N
5688	BFF122	Krem trupi Mediterrenean Olive tube 200m	1.14	8699954134057                                     	\N
5689	BFF124	Krem trupi Vanilla Dreams tube 200ml Pie	1.14	8699954134071                                     	\N
5690	BFF129	Krem trupi Mediterrenean Olive 250ml jar	1.02	8699954135054                                     	\N
5691	BFF132	Balsam i frutave për flokë Leave in 300m	1.29	8699954104029                                     	\N
5692	BFF136	Body Scrub Mediterrenean Olive 250ml jar	1.14	8699954136068                                     	\N
5693	BFF139	Shampon meshk.Hair Loss Prevention 400ml	1.60	8699954160025                                     	\N
5694	BFF174	Balsam i frutave për flokë Leave in Perf	1.29	8699954104043                                     	\N
5695	BID004	Pavllak Bimillk 20% 0.18L 2+1 GRATIS/Pak	0.00	\N	\N
5696	BID005	Bimilk Pavllak Bitolska 20% 20/180ml	0.50	5310054003113                                     	\N
5807	BAL041	Balocco - Zuppa Inglese 12/650g	7.20	8001100071398                                     	\N
5808	BAR003	Baronie Alpia Çokollate e zeze 20/100g	0.64	4001743021822                                     	\N
5809	BAR005	Baronie Sarotti Çokollate e Zeze me Port	1.62	4030387043938                                     	\N
5810	BAR006	Baronie Sarotti Çokollate e Zeze 72% 10/	1.66	4030387044294                                     	\N
5811	BAR007	Baronie Sarotti Çokollate e Zeze 85% 10/	1.99	4030387043501                                     	\N
5812	BAU037	Jogurt pa sheqer dredhez 1.8% 150g/P20	0.40	\N	\N
5813	BAU044	Jogurt me shije dredheze,limoni 3.5% 250	0.64	\N	\N
5814	BAU047	Jogurt orizi me çokollate 3.5% 200g/P12	0.53	\N	\N
5815	BAU048	Jogurt orizi me kanelle 3.5% 200g/P12	0.53	\N	\N
5816	BAU049	Jogurt i pijshëm Bauer dredhëz 235ml/P8	0.61	4002334114121                                     	\N
5817	BFF027	Parfum Men Juego Azul 100ml Pielor/ P12	5.08	8699954190053                                     	\N
5818	BFF094	Sapun i lenget Chamomile Breeze 500ml	1.02	8699954130097                                     	\N
5819	BFF103	Shower Gel Chamomile Breeze 300ml Pielor	0.95	8699954131094                                     	\N
5820	BFF117	Spray trupi Chamomile Breeze 200ml Pielo	1.45	8699954133098                                     	\N
5821	BFF126	Krem trupi Chamomile Breeze tube 200ml P	1.14	8699954134095                                     	\N
5822	BID012	Djathë i Përzier Bitolski 800g/P4	4.16	5310054002215                                     	\N
5823	BID019	Djathë Perzier  Bitolski-konfekcija	4.54	5315405004283                                     	\N
5824	BIS001	Biser Shampon Breza 500ml/ Pako 12	0.62	8600208000189                                     	\N
5825	BIS004	Biser Shampon Breza 1L/ Pako 8	0.88	8600208002374                                     	\N
5826	BIS035	Biser Breza 1l + Biser Breza 500ml Grati	0.88	3214785214781                                     	\N
5827	BMI005	Jogurta pemesh dredhëz 125g Frankenland	0.00	4074800002416                                     	\N
5828	BON001	Bombola Gazi 190g Continent/P48	0.53	5319991111028                                     	\N
5829	BON18 K	Bonusi Kozmetike	0.00	\N	\N
5830	BRI008	Biraghi Djathë Gorgonzola 12/100g	1.80	8002004343109                                     	\N
5831	BRI012	Djathë Gorgonzola Biraghi	9.73	\N	\N
5832	BRI024	Biraghi Djathë Gorgonzola 12/150g	2.40	8002004315410                                     	\N
5833	BUR078	Kulluese për orizë -1 (2,1 lt) Follow	0.55	8694917003166                                     	\N
5728	BUR033	Enë e vogël rrumbullakët - 2 (1,8lt) Fol	0.44	8694917001964                                     	\N
5729	BUR034	Enë e vogël rrumbullakët - 3 (2,8lt) Fol	0.59	8694917001971                                     	\N
5730	BUR035	Enë e vogël rrumbullakët - 4 (4,2lt) Fol	0.80	8694917001988                                     	\N
5731	BUR036	Enë e vogël transparente me kapak-1(1,2	0.70	8694917001919                                     	\N
5732	BUR037	Enë e vogël transparente me kapak-2(1,8	0.85	8694917001926                                     	\N
5733	BUR038	Enë e vogël transparente me kapak-3(2,8	1.18	8694917001933                                     	\N
5734	BUR039	Enë e vogël me kapak -4 (4	1.37	8694917001940                                     	\N
5735	BUR088	Pjatë ovale - 1 Follow me 114001/P96	0.45	8694917001216                                     	\N
5736	BUR089	Pjatë ovale - 2 Follow me/P60	0.63	8694917001223                                     	\N
5737	BUR116	Enë ovale Follow me 213701/P72	0.53	8694917000981                                     	\N
5738	BUR117	Enë ovale transparente Follow me 213791/	0.56	8694917003159                                     	\N
5739	BUR127	Kovë me kapak - 1 (4 lt) Follow me/P1	1.17	8694917000691                                     	\N
5740	BUR128	Kovë me kapak - 2 (7 lt) Follow me/P1	1.56	8694917000707                                     	\N
5741	BUR129	Kovë me kapak-3(10 lt) Follow me	2.26	8694917000516                                     	\N
5742	BUR150	Rafte i vogel ne formë ovale Follow me/P	2.34	8694917003661                                     	\N
5743	BUR154	Ulëse të vogla Follow me/P12	4.94	8694917000059                                     	\N
5744	BUR167	Kovë 14 lt Follow me/P16	2.57	8699878651746                                     	\N
1831	AVN067	Rende me dorezë L-295/P48	1.48	8693395002951                                     	\N
1839	AVN075	Kuti eliptike per ushqim L-330/P85	0.91	8693395003309                                     	\N
5782	BEL001	Zdenke 'Laughing Cow' 120g/P36	0.89	3073786155186                                     	\N
5783	BEL002	Zdenke 'Laughing Cow' 240g/P24	1.95	3073781014471                                     	\N
5794	BAK001	Karuzo - Kroasant Çokollate 24/82gr	0.00	3800200450691                                     	\N
5795	BAK002	Karuzo - Kroasant Dredhez&Yogurt 24/82gr	0.00	3800200451575                                     	\N
5796	BAK003	Karuzo-Kroasant Çershi&Cheesecake 24/82g	0.00	\N	\N
5797	BAK004	Karuzo-Krosant Boronice&Cheesecake 24/82	0.00	\N	\N
5798	BAK005	Karuzo - Kroasant Tiramisu 24/82gr	0.00	3800200451810                                     	\N
5799	BAK006	Karuzo - Kroasant Festek 24/82gr	0.00	3800200452800                                     	\N
5800	BAL004	Balocco Biskota Zuppole 12/350g	1.73	8001100011899                                     	\N
5801	BAL013	Balocco Biskota Zero me Drithera pa sheq	2.04	8001100071039                                     	\N
5802	BAL014	Balocco Biskota Zero me Çokollate pa she	2.04	8001100071046                                     	\N
5803	BAL026	Biskota Breakfast me oriz dhe fruta të k	1.73	8001100067124                                     	\N
5804	BAL027	Napolitankë kubëza me kakao, Balocco 250	1.48	8001100059242                                     	\N
5806	BAL032	Sfogliatine Glazed, Balocco 200gr/P15	1.20	8001100012117                                     	\N
5869	CAB049	00 Zilja pa tel 2 (411-107)/P10	8.62	3858883839135                                     	\N
5870	CAB051	55 Shirit izolues palstik 19mmx10m (365-	0.23	3858890440454                                     	\N
5871	cab052	55 Shirit izolues palstik 19mmx10m (365-	0.23	3858890440478                                     	\N
5872	CAB053	55 Shirit izolues palstik 19mmx10m	0.23	3858890440492                                     	\N
5873	CAB059	89 LED Reflektor i zi 10W  (306-210)/P1	6.55	3858883831597                                     	\N
5874	CAB068	90 Kabell vazhduese 1/1 HO5VV-F(220-502)	2.75	3858890442861                                     	\N
5875	CAB069	90 Kabëll vazhduese 1/1(220-504),5/4m/P1	4.01	3858890442878                                     	\N
5876	CAB070	90 Kabëll vazhduese 1/1 HO5VV-F (220-508	6.43	3858890442885                                     	\N
5877	CAL006	Calvo Tuna Copëza në Vaj Ulliri 24/80g	1.75	8410090088758                                     	\N
5878	CAL007	Calvo Tuna Copëza në Vaj Ulliri(3+1) 24/	5.59	8410299983663                                     	\N
5879	CAT020	Catrice Liquid Liner rezistent ndaj ujit	3.99	4250338474400                                     	\N
5880	CAT049	Catrice Lip Foundation laps per buze 010	1.92	4251232218480                                     	\N
5881	CAT050	Catrice Lip Foundation laps per buze 020	1.92	4251232218497                                     	\N
5882	CAT051	Catrice Lip Foundation laps per buze 030	1.92	4251232218503                                     	\N
5883	CAT052	Catrice Lip Foundation laps per buze 040	1.92	4251232218510                                     	\N
5884	CAT053	Catrice Lip Foundation laps per buze 050	1.92	4251232283389                                     	\N
5885	CAT054	Catrice Velvet Matt laps per buze	1.92	4251232218398                                     	\N
5886	CAT055	Catrice Velvet Matt laps per buze	1.92	4251232218404                                     	\N
5887	CAT056	Catrice Velvet Matt laps per buze	1.92	4251232218411                                     	\N
5888	CAT057	Catrice Velvet Matt laps per buze	1.92	4251232218428                                     	\N
5889	CAT059	Catrice Velvet Matt laps per buze	1.92	4251232218435                                     	\N
5890	CAT060	Catrice Velvet Matt laps per buze	2.49	4251232218442                                     	\N
5891	CAT061	Catrice Velvet Matt laps per buze	1.92	4251232218459                                     	\N
5835	BUR080	Kulluese transparente për orizë -1 (2,1	0.59	8694917003173                                     	\N
5836	BUR081	Kulluese transparente për orizë-2 (2,8 l	0.75	8694917003197                                     	\N
5837	BUS005	Kroisant Busto me dredhëz dhe vanilla 60	0.25	5310192000081                                     	\N
5838	BUS008	Kroisant Busto dredhëz dhe kako 80g/P18	0.33	5310192000111                                     	\N
5839	CAB004	90 6-Krika transferuese me mbrojtes i zi	6.03	3858883838800                                     	\N
5840	CAB005	90 3-Kabëll vazhduese 3/1 HO5VV-F (0802)	2.01	3859888558014                                     	\N
5841	CAB006	90 3-Kabëll vazhduese 3/1 HO5VV-F (0802)	2.01	3859888558014                                     	\N
5842	CAB007	90 3-Kabëll vazhduese (0804) 5/3m/P20	3.44	3859888558021                                     	\N
5843	CAB008	90-3-Kabëll vazhduese HO5VV-F(0806) 3G1.	4.94	3859888558038                                     	\N
5844	CAB009	90 6-Kabëll vazhduese me nderpreses 3G1/	2.43	3859889306546                                     	\N
5845	CAB010	90 6-Kabëll vazhduese me nderpreses 3G1/	2.43	3859889306546                                     	\N
5846	CAB011	90-3-Kabëll vazhduese me nderpreses	3.90	3858883830415                                     	\N
5847	CAB012	90 3-Kabëll vazhduese me nderpreses HO5V	5.28	3859889306560                                     	\N
5848	CAB013	90 5-Kabëll vazhduese me nderpreses 6/1	2.91	3859889306522                                     	\N
5849	CAB015	90 6-Kabëll vazhduese me nderpreses 5/1	5.81	3858883836134                                     	\N
5850	CAB016	90 6-Kabëll vazhduese me nderpreses 3G1/	3.27	3859889306607                                     	\N
5851	CAB017	90 6-Kabell vazhduese me nderpreses HO5V	4.68	3858883830439                                     	\N
5852	CAB018	90 6-Kabëll vazhduese me nderpreses 6/1	6.09	3859889306584                                     	\N
5853	CAB019	90 6-Kabëll vazhduese me nderpreses 3G1/	3.32	3859889306621                                     	\N
5854	CAB020	83 Spinë e levizshme e bardhe 16A 250V	0.71	3858883833928                                     	\N
5855	CAB021	83 Spinë e levizshme e bardhe 16A 250V	0.71	3858883833928                                     	\N
5856	CAB022	83 Spinë e levizshme e zeze 16A 250V	0.71	3858883833935                                     	\N
5857	CAB023	83 Spinë e levizshme e zeze 16A 250V	0.71	3858883833935                                     	\N
5858	CAB024	83 Spinë e levizshme e bardhe (290-201)	0.72	3858883833942                                     	\N
5859	CAB026	83 Spinë e levizshme e zeze ( 290-202)	0.72	3858883833959                                     	\N
5860	CAB027	83 Spinë e levizshme e zeze ( 290-202)	0.72	3858883833959                                     	\N
5861	CAB028	83 Prizë e levizshme e bardhë 16A 250V	0.85	3858883833966                                     	\N
5862	CAB029	83 Prizë e levizshme e zezë16A 250V (291	0.85	3858883833973                                     	\N
5863	CAB030	83 Prizë e levizshme e bardhe 16A 250V	0.85	3858883833980                                     	\N
5864	CAB031	83 Prizë e levizshme e zezë 16A 250V (29	0.85	3858883833997                                     	\N
5866	CAB036	83 3-Pershtates Shuko teshe i zi 16A 250	1.58	3858883838435                                     	\N
5867	CAB042	83 Pershtates univezal per udhtim (480-1	3.44	3858883834895                                     	\N
5868	CAB045	83 Priza me telekomandë 2/1(265-112)/P1	10.34	3858890442847                                     	\N
5927	CAT136	Catr.Lip Treatment balsam per buze 010	3.07	4251232283556                                     	\N
5928	CAT1427	Catrice The Cozy Earth Eyeshadow Palette	5.99	4059729419088                                     	\N
5929	CAT1452	Catrice Melted Sun Cream Bronzer 020	5.19	4059729419248                                     	\N
5930	CAT1453	Catrice Melted Sun Cream Bronzer 030	5.19	4059729419255                                     	\N
5931	CAT1468	Catrice Dream In Soft Glaze Nail Polish	3.79	4059729420176                                     	\N
5932	CAT1469	Catrice Dream In Soft Glaze Nail Polish	3.79	4059729420183                                     	\N
5933	CAT1481	Catrice TESTER The Cozy Earth Eyeshadow	0.01	4059729419064                                     	\N
5934	CAT1495	Catrice TESTER Melted Sun Cream Bronzer	0.01	4059729419453                                     	\N
5935	CAT1496	Catrice TESTER Melted Sun Cream Bronzer	0.01	4059729419460                                     	\N
5936	CAT1516	Catrice METAFACE Highl. Face Glaze Pot C	5.99	4059729425577                                     	\N
5937	CAT1517	Catrice METAFACE Lip Glaze C01	5.19	4059729425683                                     	\N
5938	CAT1518	Catrice METAFACE Lip Glaze C02	5.19	4059729425720                                     	\N
5939	CAT1519	Catrice METAFACE Lip Glaze C03	5.19	4059729425768                                     	\N
5940	CAT1520	Catrice METAFACE Glaze Primer C01	7.19	4059729425645                                     	\N
5941	CAT1522	Catrice TESTER METAFACE Highl. Glaze C01	0.01	4059729425614                                     	\N
5942	CAT1523	Catrice TESTER METAFACE Lip Glaze C01	0.01	4059729425805                                     	\N
5943	CAT1524	Catrice TESTER METAFACE Lip Glaze C02	0.01	4059729425836                                     	\N
5944	CAT1525	Catrice TESTER METAFACE Lip Glaze C03	0.01	4059729425867                                     	\N
5945	CAT1614	Catrice Skin Glaze Hydrating Serum Prime	5.69	4059729444882                                     	\N
5946	CAT1641	Catrice TESTER Skin Glaze Hydrating Seru	0.01	4059729444899                                     	\N
5947	CAT166	Catrice Tinted Lip Glow Zbutes per buze	5.19	4250587792119                                     	\N
5948	CAT1678	Catrice MY JEWELS. MY RULES. Lip Glaze C	4.49	4059729442192                                     	\N
5949	CAT1679	Catrice MY JEWELS. MY RULES. Lip Glaze C	4.49	4059729442239                                     	\N
5950	CAT1680	Catrice MY JEWELS. MY RULES. Lip Glaze C	4.49	4059729442277                                     	\N
5892	CAT062	Catrice Velvet Matt laps per buze	1.92	4251232218466                                     	\N
5894	CAT065	Catrice Velvet Matt laps per buze	1.92	4251232253832                                     	\N
5895	CAT070	Catr.Ultimate Matt buzekuq 240	3.07	4059729018328                                     	\N
5896	CAT071	Generation Plump&Shine shkelqyes buzesh	3.07	4059729192073                                     	\N
5897	CAT072	Catr.Ultimate Matt buzekuq 200	3.07	4059729018281                                     	\N
5898	CAT077	Catr.Power Plumping buzekuq 010	3.99	4059729049520                                     	\N
5899	CAT079	Catr.Power Plumping buzekuq 020	3.07	4059729049537                                     	\N
5900	CAT080	Catr.Power Plumping buzekuq 030	3.07	4059729049544                                     	\N
5901	CAT081	Catr.Power Plumping buzekuq 040	3.99	4059729049551                                     	\N
5902	CAT082	Catr.Power Plumping buzekuq 050	3.99	4059729049568                                     	\N
5903	CAT083	Catr.Power Plumping buzekuq 060	3.07	4059729049575                                     	\N
5904	CAT084	Catr.Power Plumping buzekuq 070	3.99	4059729049582                                     	\N
5905	CAT085	Catr.Power Plumping buzekuq 080	3.07	4059729049599                                     	\N
5906	CAT086	Catr.Power Plumping buzekuq 090	3.07	4059729049605                                     	\N
5907	CAT087	Catr.Power Plumping buzekuq 100	3.99	4059729049612                                     	\N
5908	CAT094	Generation Plump&Shine shkelqyes buzesh	3.07	4059729173362                                     	\N
5909	CAT095	Generation Plump&Shine shkelqyes buzesh	3.07	4059729173386                                     	\N
5910	CAT100	Generation Plump&Shine shkelqyes buzesh	3.07	4059729192066                                     	\N
5911	CAT1010	Catr. Volumizing Extreme Lip Booster 040	3.99	4059729359506                                     	\N
5912	CAT1011	Catr. Volumizing Lip Booster 190	3.49	4059729359513                                     	\N
5913	CAT1012	Catr. Volumizing Lip Booster 200	3.49	4059729359520                                     	\N
5914	CAT1057	Catrice TESTER Volumizing Extreme Lip Bo	0.01	4059729359476                                     	\N
5915	CAT1058	Catrice TESTER Volumizing Lip Booster 19	0.01	4059729359483                                     	\N
5916	CAT1059	Catrice TESTER Volumizing Lip Booster 20	0.01	4059729359490                                     	\N
5917	CAT111	The Blazing Bronze Collection palete	4.00	4059729031983                                     	\N
5918	CAT1140	Catrice TESTER Volumizing Extreme Lip Bo	0.01	4059729378538                                     	\N
5919	CAT115	Dewy-ful Lips balsam per buze	3.07	4059729024480                                     	\N
5920	CAT116	Dewy-ful Lips balsam per buze	3.07	4059729024497                                     	\N
5921	CAT1171	Catr. Volumizing Extreme Lip Booster 050	3.99	4059729379139                                     	\N
5922	CAT118	Catr.Dewy-ful Lips balsam buzesh	3.07	4059729024510                                     	\N
5923	CAT133	catr. Ultimate matt buzekuq 070	3.07	4059729010988                                     	\N
5924	CAT134	catr. Ultimate matt buzekuq 090	3.07	4059729011008                                     	\N
5926	CAT135	catr. Ultimate matt buzekuq 100	3.07	4059729011015                                     	\N
5986	CAT2096	Catrice TESTER Melted Sun Liquid Bronzer	0.01	4059729515063                                     	\N
5987	CAT2097	Catrice TESTER Melted Sun Liquid Bronzer	0.01	4059729515100                                     	\N
5988	CAT2110	Catrice Cozy Glow Eye & Cheek Palette	0.01	4059729487971                                     	\N
5989	CAT212	Catrice Volumizing buzekuq 010	3.49	4250587792386                                     	\N
5990	CAT2129	Catrice Wonder Woman Shimmer Lip Glaze 0	5.19	4059729533685                                     	\N
5991	CAT213	Catrice Volumizing buzekuq 030	3.49	4251232202267                                     	\N
5992	CAT214	Catrice Volumizing buzekuq 040	3.49	4251232202274                                     	\N
5993	CAT2146	Catrice Wonder Woman Shimmer Lip Glaze 0	5.19	4059729533722                                     	\N
5994	CAT2153	Catrice Wonder Woman Liquid Luminizer Fa	5.99	4059729533012                                     	\N
5995	CAT2154	Catrice Wonder Woman Butter Bronzer Stic	5.99	4059729532855                                     	\N
5996	CAT2155	Catrice Wonder Woman Butter Bronzer Stic	5.99	4059729532893                                     	\N
5997	CAT2158	Catrice TESTER Wonder Woman Butter Bronz	0.01	4059729532572                                     	\N
5998	CAT2159	Catrice TESTER Wonder Woman Butter Bronz	0.01	4059729532602                                     	\N
5999	CAT2169	Catrice DESERT DUNE Matte Cream Bronzer	5.99	4059729523655                                     	\N
6000	CAT2170	Catrice DESERT DUNE Matte Cream Bronzer	5.99	4059729523693                                     	\N
6001	CAT2171	Catrice DESERT DUNE Luminizing Mousse Bl	5.19	4059729523570                                     	\N
6002	CAT2172	Catrice DESERT DUNE Luminizing Mousse Bl	5.19	4059729523617                                     	\N
6003	CAT2180	Catrice TESTER DESERT DUNE Luminizing Mo	0.01	4059729543813                                     	\N
6004	CAT2181	Catrice SUMMER LIPS Lip Glaze C01	3.99	4059729545909                                     	\N
6005	CAT2182	Catrice SUMMER LIPS Lip Glaze C02	3.99	4059729545947                                     	\N
6006	CAT2194	Catrice MIDNIGHT SUN Bronzing Drops C01	5.99	4059729545497                                     	\N
6007	CAT2201	Catrice TESTER MIDNIGHT SUN Bronzing Dro	0.01	4059729545688                                     	\N
6008	CAT2226	Catrice Gloss Obsessed Lip Glaze 010	2.99	4059729541284                                     	\N
5952	CAT1705	Catrice The Joker Maxi Baked Bronzer 020	8.19	4059729470997                                     	\N
5953	CAT1755	Catrice SUMMER OBSESSED Bronzing Cushion	5.99	4059729484499                                     	\N
5954	CAT1756	Catrice SUMMER OBSESSED Bronzing Cushion	5.99	4059729484536                                     	\N
5955	CAT1757	Catrice SUMMER OBSESSED Bronzing Cushion	5.99	4059729484574                                     	\N
5956	CAT1765	Catrice TESTER SUMMER OBSESSED Bronzing	0.01	4059729484611                                     	\N
5957	CAT1766	Catrice TESTER SUMMER OBSESSED Bronzing	0.01	4059729484642                                     	\N
5958	CAT1767	Catrice TESTER SUMMER OBSESSED Bronzing	0.01	4059729484673                                     	\N
5959	CAT1801	Catrice Soft Glaze Glow Lip Balm 010	5.19	4059729489975                                     	\N
5960	CAT1820	Catrice Holiday Skin 4 in 1 Luminizer 01	4.49	4059729488718                                     	\N
5961	CAT1837	Catrice TESTER Soft Glaze Glow Lip Balm	0.01	4059729489982                                     	\N
5962	CAT184	Catrice Ultimate Matt buzekuq 010	3.07	4251232253672                                     	\N
5963	CAT185	Catrice Ultimate Matt buzekuq 020	3.07	4251232253689                                     	\N
5964	CAT186	Catrice Ultimate Matt buzekuq 030	3.07	4251232253696                                     	\N
5965	CAT187	Catrice Ultimate Matt buzekuq 040	3.07	4251232253702                                     	\N
5966	CAT188	Catrice Ultimate Matt buzekuq 050	3.07	4251232253719                                     	\N
5967	CAT189	Catrice Sun Lover Glow Bronzing Powder 0	5.19	4251232254884                                     	\N
5968	CAT1978	Catrice MYSTIC FOREST Illuminizing Prime	7.19	4059729497154                                     	\N
5969	CAT1990	Catrice ARCTIC ILLUSION Face Glaze C01	5.19	4059729497499                                     	\N
5970	CAT1995	Catrice TESTER ARCTIC ILLUSION Face Glaz	0.01	4059729497536                                     	\N
5971	CAT2024	Catrice Diamond Glaze Lip Gloss 010	3.99	4059729515711                                     	\N
5972	CAT2025	Catrice Diamond Glaze Lip Gloss 020	3.99	4059729515735                                     	\N
5973	CAT2026	Catrice Diamond Glaze Lip Gloss 030	3.99	4059729515759                                     	\N
5974	CAT2027	Catrice Diamond Glaze Lip Gloss 040	3.99	4059729516060                                     	\N
5975	CAT2030	Catrice Melted Sun Liquid Bronzer 015	5.19	4059729515070                                     	\N
5976	CAT2033	Catrice Diamond Haze Highlighter 010	5.19	4059729514998                                     	\N
5977	CAT2034	Catrice Dream In Shimmer Bronzer Nail Po	3.79	4059729445858                                     	\N
5978	CAT2073	Catrice TESTER Diamond Glaze Lip Gloss 0	0.01	4059729515728                                     	\N
5979	CAT2074	Catrice TESTER Diamond Glaze Lip Gloss 0	0.01	4059729515742                                     	\N
5980	CAT2075	Catrice TESTER Diamond Glaze Lip Gloss 0	0.01	4059729515766                                     	\N
5981	CAT2076	Catrice TESTER Diamond Glaze Lip Gloss 0	0.01	4059729516077                                     	\N
5982	CAT2080	Catrice TESTER Melted Sun Liquid Bronzer	0.01	4059729515087                                     	\N
5983	CAT2083	Catrice TESTER Diamond Haze Highlighter	0.01	4059729515001                                     	\N
5985	CAT2090	Catrice Melted Sun Liquid Bronzer 025	5.19	4059729515094                                     	\N
6060	CAT255	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032188                                     	\N
6061	CAT256	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032195                                     	\N
6062	CAT257	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032201                                     	\N
6063	CAT258	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032218                                     	\N
6010	CAT2228	Catrice Gloss Obsessed Lip Glaze 040	2.99	4059729541345                                     	\N
6015	CAT2282	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729541291                                     	\N
6016	CAT2283	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729541314                                     	\N
6017	CAT2284	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729541352                                     	\N
6018	CAT2285	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729541376                                     	\N
6023	CAT2309	Catrice Diamond Glaze Gloss Stick 020	5.19	4059729541062                                     	\N
6024	CAT231	catr. Volum balsam per buze 03	4.49	4059729011114                                     	\N
6025	CAT2310	Catrice Diamond Glaze Gloss Stick 030	5.19	4059729541086                                     	\N
6026	CAT2311	Catrice Gloss Obsessed Lip Glaze 030	2.99	4059729541321                                     	\N
6031	CAT238	Catr. Ultimate dark blow buzekuq	4.00	4251232283181                                     	\N
6032	CAT242	Catrice Eye'Matic Dip Liner I zi	2.30	4251232217735                                     	\N
6034	CAT2422	Catrice HOLLYGLAZING Liquid Blush C02	5.99	4059729553225                                     	\N
6035	CAT2423	Catrice HOLLYGLAZING Glazing Eyeshadow C	3.99	4059729552990                                     	\N
6052	CAT2504	Catrice Skin Like Tinted Moisturizer 023	5.99	4059729587695                                     	\N
6053	CAT2505	Catrice Skin Like Tinted Moisturizer 032	5.99	4059729587794                                     	\N
6054	CAT2506	Catrice Skin Like Tinted Moisturizer 045	5.99	4059729587756                                     	\N
6055	CAT251	Catr.Prisma Glaze shkelqyes buzesh 010	3.07	4251232283730                                     	\N
6011	CAT2229	Catrice Gloss Obsessed Lip Glaze 050	2.99	4059729541369                                     	\N
6019	CAT2286	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729548245                                     	\N
6020	CAT230	catr. Volum balsam per buze 020	4.49	4059729011107                                     	\N
6021	CAT2307	Catrice Bronze Glow Grip Primer 010	5.19	4059729547224                                     	\N
6022	CAT2308	Catrice Diamond Glaze Gloss Stick 010	5.19	4059729541048                                     	\N
6027	CAT2317	Catrice TESTER Gloss Obsessed Lip Glaze	0.01	4059729541338                                     	\N
6028	CAT234	catr.Eye foundation baze per hije per sy	2.69	4059729030566                                     	\N
6029	CAT235	Catr.Charming Fairy buzekuq 010	4.00	4059729032171                                     	\N
6030	CAT237	Catrice Sun Glow Matt Bronzing Powder 03	4.29	4059729028976                                     	\N
6048	CAT247	Catrice Sun Glow Matt Bronzing Powder 03	4.29	4250587732825                                     	\N
6049	CAT2477	Catrice Skin Like Tinted Moisturizer 027	0.00	4059729587770                                     	\N
6050	CAT248	Catrice Volumizing Zbutes per buze 010	4.49	4251232253535                                     	\N
6051	CAT250	Catr.Prisma Glaze shkelqyes buzesh 040	3.07	4251232283761                                     	\N
6056	CAT252	Catr.Prisma Glaze shkelqyes buzesh 020	3.07	4251232283747                                     	\N
6057	CAT253	Catr.Prisma Glaze shkelqyes buzesh 030	3.07	4251232283754                                     	\N
6058	CAT2535	Catrice TESTER Diamond Haze Jelly Highli	0.01	4059729587619                                     	\N
6059	CAT254	Catr.Prisma Glaze shkelqyes buzesh 080	3.07	4251232283969                                     	\N
6064	CAT259	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032225                                     	\N
6065	CAT260	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032232                                     	\N
6066	CAT261	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032249                                     	\N
6012	CAT2230	Catrice Gloss Obsessed Lip Glaze 060	2.99	4059729548238                                     	\N
6013	CAT226	Catr.Bouncy Caribbean Vibes bronzer 010	3.07	4059729048974                                     	\N
6014	CAT227	Catr.Bouncy Caribbean Vibes bronzer 020	3.07	4059729048981                                     	\N
6101	CAT337	Catrice TESTER Volumizing buzekuq 03	0.01	4251232202298                                     	\N
6102	CAT338	Catrice TESTER Volumizing buzekuq 04	0.01	4251232202304                                     	\N
6104	CAT362	Catrice TESTER Sun Glow Matt Bronzing Po	0.01	4250587732832                                     	\N
6105	CAT363	Catrice TESTER Sun Glow Matt Bronzing Po	0.01	4059729029508                                     	\N
6106	CAT364	Catrice TESTER Sun Lover Glow Bronzing P	0.01	4251232254891                                     	\N
6107	CAT371	Catr.TESTER Bouncy Caribbean Vibes bronz	0.01	4059729048998                                     	\N
6108	CAT372	Catr.TESTER Bouncy Caribean Vibes bronze	0.01	4059729049001                                     	\N
6109	088	088	0.00	\N	\N
6110	090	090	0.00	\N	\N
6111	091	091	0.00	\N	\N
6112	093	093	0.00	\N	\N
6113	094	094	0.00	\N	\N
6114	130	130	0.00	\N	\N
6115	201	201	0.00	\N	\N
6116	202	202	0.00	\N	\N
6117	205	205	0.00	\N	\N
6118	206	206	0.00	\N	\N
6119	208	208	0.00	\N	\N
6120	209	209	0.00	\N	\N
6121	210	210	0.00	\N	\N
6122	250	250	0.00	\N	\N
6123	127	127	0.00	\N	\N
6124	129	129	0.00	\N	\N
6125	133	133	0.00	\N	\N
6126	211	211	0.00	\N	\N
6127	614	614	0.00	\N	\N
1579	ARS045	159275-Pjata plas.Maxi white 12/1/P32	1.76	8001909592759                                     	\N
5662	BAL019	Biskota Vita Mia 290g/P10	1.73	8001100066936                                     	\N
5679	BFF052	Balsam i frutave  Leave in 300ml Pielor	1.29	8699954104012                                     	\N
5715	BIS014	Biser WC saint+ per pastrimin e nyjeve s	0.78	8600208002923                                     	\N
5727	BUR032	Enë e vogël rrumbullakët - 1 (1,2lt) Fol	0.73	8694917001957                                     	\N
5805	BAL028	Napolitankë kubëza me lajthi, Balocco 25	1.68	8001100059259                                     	\N
5834	BUR079	Kulluese për orizë - 2 (2,8 lt) Follow	0.68	8694917003180                                     	\N
5865	CAB033	83 2-Pershtates Shuko dyshe i zi 16A 250	1.37	3858883838411                                     	\N
5893	CAT063	Catrice Velvet Matt laps per buze	1.92	4251232218473                                     	\N
6068	CAT263	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032263                                     	\N
6069	CAT264	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032270                                     	\N
6070	CAT299	Catr.TESTER The Blazing Bronzer	0.01	4059729031754                                     	\N
6071	CAT303	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049797                                     	\N
6072	CAT304	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049803                                     	\N
6073	CAT305	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049810                                     	\N
6074	CAT306	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049827                                     	\N
6075	CAT307	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049834                                     	\N
6076	CAT308	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049841                                     	\N
6077	CAT309	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049858                                     	\N
6078	CAT310	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049865                                     	\N
6079	CAT311	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049872                                     	\N
6080	CAT312	Catr.TESTER Power Plumping gel buzekuq	0.01	4059729049889                                     	\N
6081	CAT313	Catrice TESTER Tinted Lip Glow Zbutes	0.01	4250587792126                                     	\N
6082	CAT314	Catrice TESTER Ultimate Dark Buzekuq 01	0.01	4251232283198                                     	\N
6083	CAT315	Catrice TESTER Ultimate Matt Buzekuq 02	0.01	4251232253733                                     	\N
6084	CAT316	Catrice TESTER Ultimate Matt Buzekuq 03	0.01	4251232253740                                     	\N
6085	CAT317	Catrice TESTER Ultimate Matt Buzekuq 04	0.01	4251232253757                                     	\N
6086	CAT318	Catrice TESTER Ultimate Matt Buzekuq 05	0.01	4251232253764                                     	\N
6087	CAT319	Catrice TESTER Ultimate Matt Buzekuq 06	0.01	4251232253771                                     	\N
6088	CAT320	Catrice TESTER Ultimate Matt Buzekuq 07	0.01	4059729011046                                     	\N
6089	CAT321	Catrice TESTER Ultimate Matt Buzekuq 09	0.01	4059729011060                                     	\N
6090	CAT322	Catrice TESTER Ultimate Matt Buzekuq 100	0.01	4059729011077                                     	\N
6091	CAT323	Catrice TESTER Ultimate Matt Buzekuq 240	0.01	4059729073952                                     	\N
6092	CAT324	Catrice TESTER Ultimate Matt Buzekuq 200	0.01	4059729073983                                     	\N
6093	CAT325	Catrice TESTER Zbutes per buze 010	0.01	4251232253542                                     	\N
6094	CAT326	Catrice TESTER Zbutes per buze 020	0.01	4059729011121                                     	\N
6095	CAT327	Catrice TESTER Zbutes per buze 030	0.01	4059729011138                                     	\N
6096	CAT328	Catrice TESTER Dewy-ful zbutes per buze	0.01	4059729024602                                     	\N
6097	CAT329	Catrice TESTER Dewy-ful zbutes per buze	0.01	4059729024619                                     	\N
6098	CAT330	Catrice TESTER Dewy-ful zbutes per buze	0.01	4059729024626                                     	\N
6099	CAT331	Catrice TESTER Dewy-ful zbutes per buze	0.01	4059729024633                                     	\N
6100	CAT336	Catrice TESTER Volumizing buzekuq 01	0.01	4250947544495                                     	\N
6042	CAT2430	Catrice TESTER HOLLYGLAZING Liquid Blush	0.01	4059729553294                                     	\N
6043	CAT2431	Catrice TESTER HOLLYGLAZING Glazing Eyes	0.01	4059729553072                                     	\N
6044	CAT2443	Catrice Diamond Haze Jelly Highlighter S	5.19	4059729587602                                     	\N
38401	PSH044	Palmolive Shampon Long&Shine (Olive) 12/	1.35	\N	\N
909	ARC142	H3659-Tempered white q.soup plate/P24	3.93	026102838754                                      	\N
914	ARC147	Luminarc pjate e madhe volare/P1	1.79	883314140781                                      	\N
945	ARI05	FA SET SPEEDSTER DEO+A.SH+SH.G	0.00	\N	\N
946	ARI06	FA SET TENDER&GENTLE CARE ALOE	0.00	\N	\N
949	ARI069	Lenor Flour de lune 1l/Pako 12	0.00	\N	\N
952	ARI075	Lenor Flour de Lune 2l/Pako 6	0.00	\N	\N
1029	ari1973	Alw Ult Duo Light 16/Pako16	0.00	4015400605379                                     	\N
5925	CAT1341	Catrice TESTER Holiday Skin Bronze & Glo	0.01	4059729400734                                     	\N
5951	CAT1704	Catrice The Joker Maxi Baked Bronzer 010	8.19	4059729470980                                     	\N
5984	CAT2089	Catrice Melted Sun Liquid Bronzer 005	5.19	4059729515056                                     	\N
6009	CAT2227	Catrice Gloss Obsessed Lip Glaze 020	2.99	4059729541307                                     	\N
6033	CAT2421	Catrice HOLLYGLAZING Liquid Blush C01	5.99	4059729553188                                     	\N
6036	CAT2424	Catrice HOLLYGLAZING Shimmer Lip Balm C0	3.99	4059729553409                                     	\N
6037	CAT2425	Catrice HOLLYGLAZING Glazing Lip Colour	3.99	4059729553324                                     	\N
6045	CAT2467	Catrice Skin Like Tinted Moisturizer 020	0.00	4059729587671                                     	\N
6046	CAT2468	Catrice Skin Like Tinted Moisturizer 030	5.99	4059729587718                                     	\N
6047	CAT2469	Catrice Skin Like Tinted Moisturizer 042	5.99	4059729587732                                     	\N
6067	CAT262	Catr.Generation Matt Comfortable buzekuq	3.07	4059729032256                                     	\N
6103	CAT339	Catrice TESTER Lip Tretman per buze 010	0.01	4251232283563                                     	\N
1093	ARI288	W&G 1in1 AD 400ml/Pako 6	0.00	8008970042169                                     	\N
1114	ARI308	Always duo light 20*16	0.00	\N	\N
47577	NMX054	Nescafe 3in1 Classic 10/(28x15.5g)	5.71	\N	\N
237	ALT059	Altanlar-Tenxhere 40x26 2/1/Pako 2	41.60	8697414822971                                     	\N
332	ALU002	Folie alumini paketim ekonomik 20m, 30cm	1.16	9001376113203                                     	\N
1147	ARI338	Nat ,ditore light duo *15	0.00	\N	\N
6038	CAT2426	Catrice HOLLYGLAZING Glazing Lip Colour	3.99	4059729553362                                     	\N
6039	CAT2427	Catrice HOLLYGLAZING Multi-Use Glitter S	5.19	4059729553034                                     	\N
6040	CAT2428	Catrice HOLLYGLAZING Charm Ring C01	1.99	4059729553102                                     	\N
6041	CAT2429	Catrice TESTER HOLLYGLAZING Liquid Blush	0.01	4059729553263                                     	\N
333	ALU003	Folie alumini 150m, 45cm/P4	15.38	9001376030265                                     	\N
334	ALU004	Folie alumini 200m, 45cm/P6	21.72	9001376130606                                     	\N
357	ALU027	Ene alumini 2730ml 321x173x76mm 3/1/P27	1.89	9001376110752                                     	\N
4509	BAD003	Kisko Uthull Molle 5% 12/0.5L	0.88	3850164340149                                     	\N
4510	BAD004	Uthull vere 3l  5% Kisko/Pako 3	0.00	\N	\N
4511	BAD005	Kisko Uthull Vere 6% 12/1L	1.23	3850164321117                                     	\N
4512	BAD006	Uthull vere 0.75l  5% Kisko/Pako 20	0.00	\N	\N
4513	BAD007	Uthull alkoholi 5l  9% Kisko/Pako 3	0.00	\N	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, user_id, user_email, action, entity, entity_id, detail, ip, created_at) FROM stdin;
1	1	admin@local	pb_sync	system	\N	{"buyers": 3328, "articles": 2293}	172.18.0.1	2026-03-20 22:47:43.405512+00
2	1	admin@local	upsert	agent_limit	5	{"period": "weekly", "max_amount": 56666}	172.18.0.1	2026-03-21 11:20:05.563419+00
3	1	admin@local	upsert	agent_limit	5	{"period": "weekly", "max_amount": 123}	172.18.0.1	2026-03-21 18:54:28.273633+00
\.


--
-- Data for Name: buyer_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buyer_sites (id, buyer_id, site_code, site_name, pb_sifra_obj) FROM stdin;
29	232	36	Al Petrol SHPK-Decan	\N
35	232	19	Al Petrol SHPK-Ferizaj 5	\N
36	232	20	Al Petrol SHPK-Ferizaj 6	\N
37	232	55	Al Petrol SHPK-Gjakove	\N
38	232	60	Al Petrol SHPK-Gjakove 2	\N
39	232	12	Al Petrol SHPK-Gjilan 1	\N
41	232	14	Al Petrol SHPK-Gjilan 3	\N
40	232	13	Al Petrol SHPK-Gjilan 2	\N
42	232	11	Al Petrol SHPK-Hani Elezit	\N
43	232	47	Al Petrol SHPK-Istog 1	\N
44	232	9	Al Petrol SHPK-Kamenice	\N
45	232	22	Al Petrol SHPK-Kline	\N
46	232	41	Al Petrol SHPK-Komoran	\N
47	232	21	Al Petrol SHPK-Llapushnik	\N
48	232	44	Al Petrol SHPK-Malisheva 1	\N
50	232	31	Al Petrol SHPK-Matiqan	\N
51	232	37	Al Petrol SHPK-Mitrovica 2	\N
52	232	53	Al Petrol SHPK-Mitrovice 1	\N
53	232	34	Al Petrol SHPK-Obiliq 1	\N
54	232	52	Al Petrol SHPK-Obiliq 2	\N
55	232	33	Al Petrol SHPK-Obiliq 4	\N
56	232	48	Al Petrol SHPK-Peje 1	\N
57	232	49	Al Petrol SHPK-Peje 2	\N
58	232	45	Al Petrol SHPK-Peje 3	\N
59	232	46	Al Petrol SHPK-Peje 4	\N
60	232	23	Al Petrol SHPK-Peje 5	\N
61	232	58	Al Petrol SHPK-Peje 6	\N
62	232	15	Al Petrol SHPK-Pirane	\N
63	232	27	Al Petrol SHPK-Podujeve 1	\N
64	232	25	Al Petrol SHPK-Podujeve 2	\N
65	232	26	Al Petrol SHPK-Podujeve 3	\N
67	232	5	Al Petrol SHPK-Prizeren 2	\N
68	232	6	Al Petrol SHPK-Prizeren 3	\N
69	232	7	Al Petrol SHPK-Prizeren 5	\N
70	232	61	Al Petrol SHPK-Prizeren 6 Landovice	\N
71	232	57	Al Petrol SHPK-Rahovec	\N
72	232	10	Al Petrol SHPK-Shtime	\N
73	232	35	Al Petrol SHPK-Sllatine 1	\N
74	232	51	Al Petrol SHPK-Sllatine 2	\N
75	232	3	Al Petrol SHPK-Suhareke 1	\N
76	232	62	Al Petrol SHPK-Veternik 4	\N
77	232	29	Al Petrol SHPK-Veterrnik 1	\N
78	232	30	Al Petrol SHPK-Veterrnik 2	\N
79	232	32	Al Petrol SHPK-Veterrnik 3	\N
80	232	1	Al Petrol SHPK-Viti	\N
81	232	50	Al Petrol SHPK-Vragoli	\N
82	232	24	Al Petrol SHPK-Vranjevc	\N
84	232	8	Al Petrol SHPK-Xerxe	\N
85	236	2	ALBA PETROL SHPK-BIBAJ-Ferizaj	\N
86	236	3	ALBA PETROL SHPK-Magj.Ferizaj-Shkup	\N
87	236	1	ALBA PETROL SHPK-Mursel Bajram Sylejmani	\N
88	246	5	Albapetrol Group SH.P.K 2 -Viti	\N
89	246	4	Albapetrol Group SH.P.K 2.-Ferizaj	\N
90	246	6	Albapetrol Group SH.P.K -Gjilan	\N
91	246	2	Albapetrol Group SH.P.K.-Ferizaj	\N
92	246	3	Albapetrol Group SH.P.K.-Prishtine	\N
93	246	1	Albapetrol Group SH.P.K.-Viti	\N
94	256	26	ALBI  HIPMARKET 16 SHPK-Prizeren	\N
95	256	27	ALBI  MARKET 17 SHPK-Fushe Kosove	\N
96	256	28	ALBI  MARKET 18 SHPK-Prishtine	\N
97	256	29	ALBI  MARKET 19 SHPK-Prishtine	\N
99	256	31	ALBI  MARKET 21 SHPK-Prishtine	\N
100	256	32	ALBI  MARKET 22 SHPK-Prishtine	\N
101	256	33	ALBI  MARKET 23 SHPK-Lipjan	\N
102	256	34	ALBI  MARKET 24 SHPK-Prishtine	\N
103	256	35	ALBI  MARKET 25 SHPK-Fushë Kosovë	\N
104	256	36	ALBI  MARKET 26 SHPK-Prishtinë	\N
105	256	37	ALBI  MARKET 27 SHPK-Prishtinë	\N
106	256	38	ALBI  MARKET 28 SHPK-Prishtinë	\N
107	256	39	ALBI  MARKET 29 SHPK-Prishtinë	\N
108	256	40	ALBI  MARKET 30 SHPK-Prishtinë	\N
109	256	41	ALBI  MARKET 31 SHPK-Prishtinë	\N
110	256	42	ALBI  MARKET 32 SHPK-Prishtinë	\N
111	256	43	ALBI  MARKET 33SHPK-Lipjan	\N
112	256	44	ALBI  MARKET 34 SHPK-Gjilan	\N
113	256	45	ALBI  MARKET 35-SHPK-Prishtine	\N
114	256	46	ALBI  MARKET 36-SHPK-Prishtine	\N
115	256	47	ALBI  MARKET 37-SHPK-Gjilan	\N
116	256	48	ALBI  MARKET 38-SHPK-Gjakove	\N
3	58	3	FRUCTAL Depo 03 Ferizaj Sh.P.K	\N
4	150	1	ZEM ZEM - Junik- Deqan Sh.P.K	\N
5	150	2	ZEM ZEM 2 - JUNIK	\N
6	155	2	€URO MARKET NTP 02 -Ferizaj	\N
7	155	3	€URO MARKET NTP 03-Prizeren	\N
8	155	4	€URO MARKET NTP 04- William W.Prizren	\N
10	155	5	€URO MARKET NTP-Ferizaj	\N
11	165	2	7 VELLEZRIT 2 NTP-MUZEQIN	\N
9	155	1	€URO MARKET NTP-Ferizaj	\N
13	165	1	NTP 7 VELLEZERIT-KOSHARE	\N
12	165	3	7 VELLEZRIT 3 NTP-Llojza	\N
14	170	2	A2 Market SH.P.K. - Bregu u Diellit	\N
16	178	2	ABI MARKET - PRIZREN	\N
17	178	1	ABI SHPK  - Prizren	\N
18	178	3	ABI STORE-Prizeren	\N
15	170	1	A2 Market SH.P.K. - Prishtine	\N
20	197	1	AG MARKET 1-PEJE	\N
19	181	1	Ada Pharm Sh.p.k.-Kaçanik-Market	\N
21	197	2	AG MARKET 2-PEJE	\N
22	197	3	AG MARKET 3-PEJE	\N
23	197	4	AG MARKET 4-PEJE	\N
25	231	3	AKTIV SHPK-Skenderaj	\N
26	231	4	AKTIV SHPK-Vushtrri	\N
27	232	56	Al Petrol SHPK-Bregu i diellit	\N
24	231	1	AKTIV  SHPK-Drenas	\N
28	232	59	Al Petrol SHPK-Bubavece	\N
30	232	28	Al Petrol SHPK-Dragodan 2	\N
31	232	42	Al Petrol SHPK-Drenas	\N
33	232	17	Al Petrol SHPK-Ferizaj 3	\N
34	232	18	Al Petrol SHPK-Ferizaj 4	\N
152	256	8	ALBI SHOPING SHPK 9 -Veternik- Prishtine	\N
153	256	13	ALBI SHOPING SHPK-10  Arberia -Prishtine	\N
154	258	2	ALBINI - Kline	\N
155	258	1	ALBINI - Kline Sh.P.K	\N
156	258	3	ALBINI-Vitomerice	\N
158	305	1	AMPM 24 H MARKET SH.P.K.-Ferizaj	\N
159	314	1	Andi Sport SH.P.K.-Gjilan	\N
160	319	1	ANI - B.Diellit - Prishtine Sh.P.K	\N
161	324	1	ANILA FREESHOP SH.P.K. Njesia  4	\N
162	333	2	APOLLONIA 1991 2 SHPK-Ferizaj	\N
163	334	1	APOLONIA RESTAURANT 1991 SHPK - FERIZAJ	\N
164	370	1	ARI NTSH - FERIZAJ	\N
165	370	2	ARI NTSH 2 -FERIZAJ	\N
166	370	4	ARI NTSH 4 -FERIZAJ	\N
167	376	2	Arjeta Group SHPK(QTA)-Kline e eperme	\N
168	376	1	Arjeta Group SHPK(QTA)-Skenderaj	\N
169	376	10	QTA Express 10-Kline	\N
170	376	11	QTA EXPRESS 10-Prishtine	\N
171	376	12	QTA Express 11-Fushe Kosove	\N
172	376	7	QTA Express 8 Skenderaj	\N
173	376	9	QTA Express 9-Mitrovice	\N
174	376	8	QTA Express 9-Prishtine	\N
175	376	5	QTA Express Fushe Kosove	\N
176	376	6	QTA Express Fushe Kosove 2	\N
177	376	4	QTA Express Mitrovice	\N
178	376	3	QTA Express Skenderaj	\N
179	385	1	AROMA SHPK	\N
181	387	1	Arrbi SH.P.K.	\N
182	402	2	ARTIDA LD SHPK-Fushe Kosove	\N
183	406	2	Artizzan Bakery  Njesi 2 SH.P.K.	\N
184	406	1	Artizzan Bakery  Njesia 1 SH.P.K.	\N
185	417	4	ATC SHPK  -Prishtine	\N
186	417	6	ATC SHPK 4 -Fushe Kosove	\N
187	417	3	ATC SHPK 4 -Prishtine	\N
188	417	5	ATC SHPK 5 -Drenas	\N
189	417	7	ATC SHPK 5-Fushe Kosove	\N
190	417	1	ATC SHPK-Drenas	\N
191	417	8	ATC SHPK-Drenas-Rr.Xhevat Demaku	\N
192	417	2	ATC SHPK-Fushe Kosove	\N
194	474	2	Ballkan Petrol SH.P.K. - Ana e djathte	\N
195	474	1	Ballkan Petrol SH.P.K. - Ana e majte	\N
196	474	5	Ballkan Petrol SH.P.K. - te QMI	\N
197	474	4	Ballkan Pizzeria SH.P.K -  Ferizaj	\N
198	476	2	BAMEX DEPO   - Mitrovice SHPK	\N
199	476	1	BAMEX MARKET - Mitrovice Sh.P.K	\N
200	481	2	Banana Group SH.P.K. 2 -Qagllavice	\N
201	481	1	Banana Group SH.P.K.-Graçanicë	\N
202	496	2	Barnatore Joni L.L.C.-1 Hajrullah Zymi	\N
203	496	1	Barnatore Joni L.L.C.-Fushë Kosovë	\N
204	503	13	Bas market-Ferizaj	\N
205	503	12	Bas SHPK 10 -Pleshine,  Ferizaj	\N
206	503	2	BAS SHPK 2 -Ferizaj	\N
207	503	3	Bas SHPK 3 -Greme	\N
208	503	4	Bas SHPK 4 -Lipjan	\N
209	503	5	Bas SHPK 5-Millosheve	\N
210	503	6	Bas SHPK -Ferizaj	\N
211	503	1	BAS SHPK-Ferizaj	\N
212	503	9	Bas SHPK-Kaqanik	\N
213	503	10	Bas SHPK-Sodovine	\N
214	503	7	Bas SHPK-Viti	\N
215	503	8	Bas SHPK-Vushtrri	\N
216	508	2	BASILICO N.H - Prishtine	\N
217	508	1	BASILICO SHPK - Fushe Kosove	\N
219	512	1	BBC TRADE - Prishtine Sh.P.K	\N
220	512	2	BBC TRADE 2 - Fushe Kosove	\N
221	518	1	BEDI Market Group 1-Shpk	\N
222	518	2	BEDI Market Group 2-Shpk	\N
223	519	1	BEDI MARKET-02-Perball Shkoll.Ibrahim Ru	\N
224	519	2	Bedi Market-Podujevë	\N
225	522	1	BEE TRADE GROUP L.L.C.-Mitrovicë	\N
226	522	3	BEE TRADE GROUP L.L.C.-Rr. 300 Deshmoret	\N
227	522	2	BEE TRADE GROUP L.L.C.-Rr.Avni Shabani	\N
229	527	1	BEHARI MARKET PREMIUM SH.P.K.	\N
230	531	1	BEKA TRADE-1 " SH.P.K."	\N
228	527	2	BEHARI MARKET PREMIUM SH.P.K.	\N
232	553	1	BENI DONA - PRISHTINE	\N
231	531	2	BEKA TRADE-1 " SH.P.K." 3	\N
345	1045	5	Durmart L.L.C.- 4  Mitrovicë	\N
119	256	51	ALBI  MARKET 41-SHPK-Hajvali	\N
122	256	12	ALBI  MARKET 9 SHPK - SALLA 1 TETORI-PR	\N
124	256	18	ALBI HIPERMARKET 11 SHPK - Fushe Kosove	\N
123	256	17	ALBI DEPO QENDRORE-QMI	\N
125	256	15	ALBI HIPERMARKET 6 SHPK  -BARDHOSH	\N
127	256	5	ALBI MARKET 1 SHPK - Prishtine	\N
128	256	24	ALBI MARKET 11 SHPK-Fushe Kosove	\N
129	256	20	ALBI MARKET 12 SHPK-Te parku Prishtine	\N
130	256	21	ALBI MARKET 13 SHPK- Shefki Kuleta F.K.	\N
126	256	4	ALBI HIPERMARKET4 SHPK- Prishtine	\N
132	256	25	ALBI MARKET 15 SHPK-Arberi Prishtine	\N
133	256	6	ALBI MARKET 2 SHPK - Prishtine	\N
134	256	53	ALBI MARKET 42- SHPK-Prishtine	\N
131	256	23	ALBI MARKET 14 SHPK-Fushe Kosove	\N
135	256	54	ALBI MARKET 43 -ShPK Prishtine	\N
136	256	55	ALBI MARKET 44 -ShPK Prishtine	\N
137	256	56	ALBI MARKET 45-SHPK Prishtine	\N
139	256	58	ALBI MARKET 47-SHPK PRIZREN	\N
141	256	10	ALBI MARKET 5 SHPK- Prishtine	\N
142	256	61	Albi market 50-Prishtine	\N
143	256	62	Albi Market 51-Podujeve	\N
144	256	11	ALBI MARKET 7 SHPK- Prishtine	\N
138	256	57	ALBI MARKET 46-SHPK GJILAN	\N
145	256	14	ALBI MARKET 8  SHPK - Te Permendorja	\N
146	256	2	ALBI MARKET SHPK 3- -Prishtine	\N
147	256	19	ALBI MARKET SHPK-Xh.Llapit Prishtine	\N
148	256	3	ALBI SHOPING SHPK - Besiane	\N
149	256	7	ALBI SHOPING SHPK - Fushe Kosove	\N
150	256	16	ALBI SHOPING SHPK - Prizren	\N
151	256	1	ALBI SHOPING SHPK - Vushtrri	\N
264	669	5	BLISS SHPK - Gjilan	\N
267	669	10	BLISS SHPK -Prishtine	\N
266	669	9	BLISS SHPK- Ferizaj (Ahmet Kaqiku)	\N
269	684	2	Bon Marche Market L.L.C. 2	\N
268	684	1	Bon Marche Market L.L.C. 1	\N
270	689	1	BONNARD L.L.C.	\N
271	701	1	BOTTEGA MARKET SH.P.K.	\N
273	725	1	BTP Corporation L.L.C.-Stanovc-Vushtrri	\N
274	725	2	BTP Corporation L.L.C.-Vushtrri	\N
275	730	1	BUJANA Sweets & Lunch SH.P.K. Njesia 1	\N
276	730	2	BUJANA Sweets & Lunch SH.P.K. Njesia 2	\N
277	779	1	ÇANA MARKET SHPK - Shterpce	\N
278	779	2	ÇANA MARKET SHPK 2 - Shterpce	\N
279	787	1	CASA MIA LOUNGE -Visar I Berisha SH.P.K.	\N
280	787	2	CASA MIA TERRAZZA SH.P.K	\N
281	788	1	CASA RITA DPH-  Njesi 1 Prishtine	\N
282	788	2	RITAS DPH-  Njesi 2 Prishtine	\N
283	795	13	CFO GREEN PHARMACY 15-Kamenice	\N
284	795	20	CFO GREEN PHARMACY 22-Fushe Kosove	\N
285	795	21	CFO GREEN PHARMACY 23-Gjilan	\N
286	795	22	CFO GREEN PHARMACY 24-Gjilan	\N
287	795	29	CFO GREEN PHARMACY 31-Gjakove	\N
288	795	5	CFO GREEN PHARMACY 5-Ferizaj	\N
290	797	2	Che Bar - Market	\N
292	804	1	Chicken House Te Pula SH.P.K.	\N
293	804	2	Chicken House Te Pula SH.P.K. - Rruga B	\N
294	811	2	CINEPLEXX KOSOVO LLC-Prizeren	\N
295	817	2	CITY MARKET ABSH 2 SH.P.K.-Ferizaj	\N
296	817	1	CITY MARKET ABSH SH.P.K.-Ferizaj	\N
297	847	1	D.D & O SH.P.K. Njesi  1-Prishtine	\N
298	860	2	D.P.T. " Jaffa " 2-Gjakovë	\N
299	860	1	D.P.T. " Jaffa "-Gjakovë	\N
300	911	2	DDG Group SH.P.K.-01 Anna's Brunch Caff	\N
301	911	1	DDG Group SH.P.K.-Prishtinë	\N
302	920	1	DEDA COMMERC 1 - Doganaj-Kaqanik Sh.P.K	\N
303	926	3	DELIA Cosmetics  SHPK-Prishtine	\N
304	926	2	DELIA Cosmetics 2 SHPK-Prishtine	\N
305	926	4	DELIA Cosmetics 3 SHPK-Ulpiane Prishtine	\N
306	926	5	DELIA Cosmetics 4 SHPK-Fushe Kosove	\N
307	926	7	DELIA Cosmetics 5 SHPK-Royal Mall	\N
308	926	1	DELIA Cosmetics SHPK-Prishtine	\N
309	928	2	DELISH L.L.C 2 -Prishtine	\N
310	928	1	DELISH L.L.C -Prishtine	\N
312	942	12	DHF COMPANY SHPK , Rahovec	\N
313	942	13	DHF COMPANY SHPK , Raushiq	\N
314	942	10	DHF COMPANY SHPK Buroje, Skenderaj	\N
315	942	4	DHF COMPANY SHPK Deqan	\N
316	942	7	DHF COMPANY SHPK Kline	\N
317	942	8	DHF COMPANY SHPK Komoran	\N
318	942	6	DHF COMPANY SHPK Llozic	\N
319	942	9	DHF COMPANY SHPK Poterqk	\N
320	942	15	DHF COMPANY SHPK-Kline	\N
321	942	2	DHF COMPANY SHPK-Vitomerice	\N
322	955	2	DIELLZA SHPK 2 -Drenas	\N
323	955	1	DIELLZA SHPK-Drenas	\N
324	960	2	DINA R - Gjakove 2-Gjakove	\N
325	960	3	DINA R - Gjakove 3-Gjakove	\N
326	960	1	DINA R - Gjakove Sh.P.K	\N
327	964	2	DINI SHPK-Gjilan Qender	\N
329	979	2	Rose Cocktail Cafe,   Doel S.Q SH.P.K.	\N
330	1027	1	DRIN GROUP SHPK-Kline	\N
331	1027	2	PROPERLOUNGE SH.P.K.-Kline	\N
332	1038	1	DUO Cosmetics SHPK- Njesi  2 Prishtine	\N
333	1038	2	DUO Cosmetics SHPK- Njesi 3 Prishtine	\N
334	1039	1	Duo Market F&S SH.P.K.01-Gjilan	\N
335	1039	2	Duo Market F&S SH.P.K.02-Gjilan	\N
336	1039	3	Duo Market F&S SH.P.K.03-Gjilan	\N
337	1039	4	Duo Market F&S SH.P.K.04-Gjilan	\N
338	1039	5	Duo Market F&S SH.P.K.05-Gjilan	\N
339	1045	2	Durmart L.L.C.- 1  Mitrovicë	\N
340	1045	11	Durmart L.L.C.- 10 Mitrovice Rr.M.Gashi	\N
342	1045	13	Durmart L.L.C.- 12 Shufkofc Mitrovic	\N
343	1045	3	Durmart L.L.C.- 2  Mitrovicë	\N
344	1045	4	Durmart L.L.C.- 3  Mitrovicë	\N
234	558	2	BENI SHPK(Planet)  Korishe	\N
235	558	3	BENI SHPK(Planet) 3-Rahovec	\N
236	558	1	BENI SHPK(Planet) Shiroke - Therande	\N
237	558	4	Te sheshi Suhareke	\N
238	559	1	BENITA COMANY SHPK- Gremnik	\N
239	559	2	BENITA COMPANY  Gremenike- Sh.P.K	\N
240	559	3	BENITA COMPANY Shpk-2-Dollc, Kline	\N
241	560	2	BENITA CORPORATION SH.P.K.-Drenas	\N
242	560	1	BENITA CORPORATION SH.P.K.-Kline	\N
243	561	2	Berat Rr. Pllana B.I.-Toplica Top Market	\N
245	571	1	BESA - 2 NT - HANI I ELEZIT	\N
246	571	2	BESA - 2 NT - KAQANIK ( Banesa e madhe )	\N
247	573	1	BESA 3 - Kaqanik	\N
244	561	1	Berat Rr. Pllana B.I.-Toplica Top Market	\N
250	605	1	BESNIKU - Livoq i Eperm- Gjilan	\N
248	597	2	Njesia Resorti Liqeni i Mjellmave	\N
252	626	2	Binak M.Çoçaj B.I.-OREX 7 -Prishtine	\N
251	610	1	BESURI DPT - FUSHE KOSOVE	\N
254	644	2	Blenda 2 -Te policia	\N
255	650	1	BLERCOM - Kieve- Malisheve Sh.P.K	\N
253	644	1	BLENDA - Gjilan Sh.P.K	\N
257	656	3	Blerta Dushi B.I. - Kline	\N
258	656	1	Blerta Dushi B.I. (Bake my Day)	\N
256	650	2	BLERCOM CENTER Kieve	\N
259	660	1	BLETA  1 - Ferizaj Sh.P.K	\N
260	660	2	BLETA  2 - Ferizaj Sh.P.K.	\N
262	663	1	BLETA STORE SH.P.K.-Ferizaj	\N
261	663	2	BLETA STORE SH.P.K 2.-Fushe Kosove	\N
263	669	6	BLISS SHPK - Ferizaj	\N
265	669	3	BLISS SHPK - Prishtine	\N
289	795	8	CFO GREEN PHARMACY 8 -Fushe Kosve	\N
367	1067	1	EBC Company SHPK-Prishtine	\N
370	1067	2	EBC Superstore - Prishtine	\N
371	1086	2	Edona Company L.L.C. 2 -Vushtrri	\N
372	1086	1	Edona Company L.L.C.-Vushtrri	\N
373	1086	3	Edona Company L.L.C-Vushtrri	\N
374	1087	3	Edona  Market 2-Vushttri	\N
375	1087	2	EDONA GROUP  DEPO  SHPK-Vushtrri	\N
376	1087	1	EDONA GROUP SHPK-Vushtrri	\N
377	1098	2	EGZONITA DEPO - Besiane	\N
392	1124	3	ELIRA Ntp njesia 2-RrAdem Jashari Shtime	\N
393	1124	4	ELIRA Ntp njesia 3-Muzeqin	\N
394	1124	6	ELIRA Ntp njesia 4-Rr Anton Qeta Shtime	\N
395	1124	1	ELIRA Ntp selia-Rr.Tiranes Shtime	\N
396	1124	5	Elira NTP-Koshare	\N
397	1129	3	ELLIE Coffe SHPK-Central Park	\N
398	1129	1	ELLIE Coffe SHPK-Prishtine	\N
399	1129	2	ELLIE Coffe SHPK-Rr.B	\N
400	1143	22	Emona Center 7-Ferizaj	\N
414	1143	20	EMONA CENTER SHPK 17  Vushtrri	\N
415	1143	19	EMONA CENTER SHPK 19-Prishtine	\N
416	1143	2	EMONA CENTER SHPK 2  - Vushtrri	\N
417	1143	3	EMONA CENTER SHPK 3  - Mitrovice	\N
418	1143	4	EMONA CENTER SHPK 4 - Obiliq	\N
419	1143	17	EMONA CENTER SHPK -Prishtine	\N
421	1157	1	ENDRITI BUS SH.P.K.-Ferizaj	\N
422	1187	1	Ereniku 2021 SH.P.K.-Podujevë	\N
423	1187	2	Ereniku 2021 SH.P.K-Njesia 1.-Podujevë	\N
424	1199	2	ESPO MARKET SH.P.K 2-Ferizaj	\N
347	1045	7	Durmart L.L.C.- 6  Prishtine	\N
348	1045	8	Durmart L.L.C.- 7 Prishtine	\N
350	1045	10	Durmart L.L.C.- 9 Prishtine	\N
351	1045	1	Durmart L.L.C.- HQ Mitrovicë	\N
352	1046	1	QTA  Store 1  SH.P.K- Mitrovice	\N
353	1046	10	QTA  Store 10 -SH.P.K- Mazgit	\N
354	1046	4	QTA  Store 2 -SH.P.K- Mitrovice	\N
355	1046	5	QTA  Store 3-SH.P.K- Mitrovice	\N
356	1046	2	QTA  Store 4 -SH.P.K- Mitrovice	\N
378	1098	1	EGZONITA MARKET NTP - Besiane	\N
379	1098	3	EGZONITA MARKET NTP 2 - Besiane	\N
401	1143	7	EMONA CENTER SHPK - 9 Lipjan	\N
403	1143	6	EMONA CENTER SHPK - Fushe Kosove	\N
425	1199	1	ESPO MARKET SH.P.K.-Kaqanik	\N
463	1207	1	EURO FOOD  - Prizren Sh.P.K	\N
357	1046	3	QTA  Store 5 -SH.P.K- Mitrovice	\N
358	1046	7	QTA  Store 6-SH.P.K- Prishtine	\N
380	1112	2	ELAN PETROL - Pestove Sh.P.K	\N
404	1143	8	EMONA CENTER SHPK - Prizeren	\N
405	1143	21	EMONA CENTER SHPK 06  Mitrovica	\N
406	1143	1	EMONA CENTER SHPK 1  - Vushtrri	\N
407	1143	9	EMONA CENTER SHPK 10 - Ferizaj	\N
359	1046	8	QTA  Store 7-SH.P.K- Prishtine	\N
360	1046	9	QTA  Store 8-SH.P.K- Prishtine	\N
361	1046	6	QTA SH.P.K- Shipol Mitrovice	\N
362	1058	2	E Hasani BTP L.L.C.2 -Vushtrri	\N
363	1058	1	E Hasani BTP L.L.C.-Vushtrri	\N
365	1067	6	EBC Company SHPK-Albi Mall	\N
366	1067	5	EBC Company SHPK-Galeria Prizeren	\N
368	1067	3	EBC Company SHPK-Prishtine	\N
369	1067	9	EBC Company SHPK-Prishtine	\N
381	1112	1	ELAN PETROL - Vushtri Sh.P.K	\N
382	1121	1	ELI AB  SHPK - Ferizaj Sh.P.K	\N
383	1121	3	ELI AB 1 - FERIZAJ	\N
384	1121	2	ELI AB 3 - SHTIME	\N
386	1121	9	ELI AB SHPK 4 Te Ura Ferizaj	\N
387	1121	5	ELI AB SHPK 5-Ferizaj	\N
388	1121	6	ELI AB SHPK 6-Fushe Kosove	\N
389	1121	7	ELI AB SHPK 7-Lipjan	\N
390	1121	8	ELI AB SHPK 8-Mbrapa Royal Mall Prishtin	\N
408	1143	10	EMONA CENTER SHPK 11-Prishtine	\N
409	1143	12	EMONA CENTER SHPK 12-Prishtine	\N
410	1143	14	EMONA CENTER SHPK 13-Mitrovice	\N
411	1143	13	EMONA CENTER SHPK 14-Vushtrri	\N
412	1143	15	EMONA CENTER SHPK 15-Fushe Kosove	\N
413	1143	16	EMONA CENTER SHPK 16-Vushtrri	\N
391	1124	2	ELIRA Ntp njesia 1-RrTahir Sinani Shtime	\N
498	1233	35	EX FIS SHPK - Emshir(te rrethi)	\N
499	1233	12	EX FIS SHPK - Ferizaj	\N
501	1233	26	EX FIS SHPK - Ferizaj 3(Rr.Brahim Ademi)	\N
502	1233	14	EX FIS SHPK - Gjakove	\N
503	1233	7	EX FIS SHPK - Gjilan	\N
504	1233	2	EX FIS SHPK - Hajvali - Prishtine	\N
505	1233	38	EX FIS SHPK - Istog	\N
506	1233	40	EX FIS SHPK - Istog 2	\N
507	1233	22	EX FIS SHPK - Kolovice Prishtine	\N
508	1233	3	EX FIS SHPK - Konjuhe - Lipjan	\N
509	1233	6	EX FIS SHPK - Koretin Kamenice	\N
510	1233	21	EX FIS SHPK - Korishe Suhareke	\N
511	1233	10	EX FIS SHPK - Korrotice Drenas	\N
512	1233	20	EX FIS SHPK - Lupc Podujeve	\N
513	1233	9	EX FIS SHPK - Millosheve	\N
514	1233	27	EX FIS SHPK - Mitrovice	\N
515	1233	45	EX FIS SHPK - Nashecit	\N
516	1233	23	EX FIS SHPK - Prishtine	\N
517	1233	46	EX FIS SHPK - Prizeren	\N
518	1233	28	EX FIS SHPK - Prizeren-Gjakove	\N
519	1233	42	EX FIS SHPK - Prizren 2 Tranzit	\N
520	1233	18	EX FIS SHPK - Qerim Gjakove	\N
521	1233	31	EX FIS SHPK - Rahovec	\N
523	1233	44	EX FIS SHPK - Shkabaj	\N
524	1233	11	EX FIS SHPK - Shupkovc Mitrovice	\N
525	1233	4	EX FIS SHPK - Sllatine - Fushe Kosove	\N
526	1233	16	EX FIS SHPK - Te tregu Prishtine	\N
527	1233	41	EX FIS SHPK - Tranzit Peje	\N
528	1233	15	EX FIS SHPK - Trude Podujeve	\N
529	1233	1	EX FIS SHPK - Ulpiane Prishine	\N
530	1233	25	EX FIS SHPK - Vushtrri	\N
531	1233	17	EX FIS SHPK - Xhamia e Llapit Prishtine	\N
532	1233	47	EX FIS SHPK 44 - Prizeren	\N
533	1233	48	EX FIS SHPK 46-Malisheve	\N
534	1233	49	EX FIS SHPK 51-Peje	\N
535	1233	50	EX FIS SHPK 52-Peje	\N
536	1233	51	EX FIS SHPK 53-Prugofc	\N
537	1233	52	EX FIS SHPK 54-Graqanice	\N
538	1233	36	EX FIS SHPK 7 - Gjilan	\N
540	1237	12	Express Store 1 SHPK-Peje(ura gurit)	\N
541	1237	19	Express Store 12 SHPK-Dardani Peje	\N
542	1237	21	Express Store 14 SHPK-Peje	\N
543	1237	22	Express Store 15 SHPK-Deqan	\N
544	1237	5	Express Store 2 SH.P.K-Ulpiane Prishtine	\N
545	1237	13	Express Store 2 SHPK-Peje(gjimnazi)	\N
546	1237	6	Express Store 3 SH.P.K-Dardani Prishtine	\N
547	1237	24	Express Store 3 SHPK-Istog	\N
548	1237	14	Express Store 3 SHPK-Peje(maxi)	\N
549	1237	7	Express Store 4 SH.P.K.-Emshir Prishtine	\N
550	1237	9	Express Store 6 SH.P.K.-Bregu i Diellit	\N
551	1237	16	Express Store 6 SHPK-Peje(ish Emarket)	\N
552	1237	17	Express Store 7 SHPK-Peje(Dardani)	\N
553	1237	11	Express Store 8 SH.P.K.-Peje	\N
554	1237	18	Express Store 8 SHPK-Prishtine	\N
555	1237	2	Express Store 9 SH.P.K-Peje.	\N
556	1237	26	Express Store SHPK-Drenas	\N
557	1237	28	Express Store SHPK-Peje	\N
558	1237	29	Express Store SHPK-Radac	\N
559	1237	25	Express Store SHPK-Vrelle Istog	\N
560	1248	1	FABS INTERNATIONAL L.L.C.  Njesia 1	\N
562	1274	3	FATI 1 PHARM - Te Spitali -Peje Sh.P.K	\N
563	1275	2	FATI-G N.T 2 .-Peje	\N
565	1275	1	FATI-G N.T.-Peje	\N
566	1292	2	FEMIS COSMETICS 02 - Prishtine	\N
567	1292	6	Femis Cosmetics Sh.P.K Prishtina Mall	\N
571	1294	2	N.T. FER PETROL - Drenas -Gllobar	\N
572	1294	1	N.T. FER PETROL - KOMORAN	\N
573	1294	4	N.T. FER PETROL 4. - Skenderaj	\N
574	1306	1	FIENTI NTP - F.Kosove	\N
575	1330	1	FITORJA  SHPK - FERIZAJ	\N
576	1330	2	FITORJA 2  - Rruga e Pleshines	\N
577	1330	3	FITORJA SHPK REST.PIC - Ferizaj	\N
578	1339	2	FLEX GYM SH.P.K.02 -Prishtinë	\N
465	1207	4	EURO FOOD 51 - Prizren	\N
467	1207	6	EURO FOOD 53 - Prizren	\N
469	1207	8	EURO FOOD 55 - Prizren	\N
470	1207	9	EURO FOOD 56 - Prizren	\N
471	1207	10	EURO FOOD 57 - Prizeren	\N
472	1207	14	EUROFOOD	\N
473	1207	26	EUROFOOD 49-Prizeren	\N
474	1207	12	EUROFOOD 58 - Prizren	\N
475	1207	15	EUROFOOD 59- Prizeren	\N
476	1207	16	EUROFOOD 60-Recan	\N
477	1207	17	EUROFOOD 61-Arbane	\N
478	1207	18	EUROFOOD 62-Jaglenice	\N
479	1207	20	EUROFOOD 63-Prizeren	\N
480	1207	21	EUROFOOD 64-Prizeren	\N
481	1207	22	EUROFOOD 66-Prizeren	\N
482	1207	24	EUROFOOD 67-Prizeren	\N
483	1207	25	EUROFOOD 68-Prizeren	\N
484	1207	13	EUROFOOD 70 - Gjakove	\N
487	1214	1	Euro Max Plus SH.P.K.-Prishtinë Njesi 1	\N
488	1215	2	Euro Mili Petrol SH.P.K 2.-Prishtinë	\N
489	1215	1	Euro Mili Petrol SH.P.K.-Prishtinë	\N
490	1216	1	EURO MIT SHPK - FERIZAJ	\N
491	1216	2	EURO MIT SHPK - Gjilan	\N
492	1216	3	EURO MIT SHPK - Hajvali Prishtine	\N
493	1233	13	EX FIS SHPK - Babush Ferizaj	\N
494	1233	37	EX FIS SHPK - Banje Peje	\N
495	1233	30	EX FIS SHPK - Banulle Lipjan	\N
496	1233	32	EX FIS SHPK - Baza Sllatine	\N
497	1233	5	EX FIS SHPK - Bresalc Gjilan	\N
466	1207	5	EURO FOOD 52 - Prizren	\N
610	1465	1	GASHI Commerce NTP - Prizren	\N
613	1469	2	GASHI Y SH.P.K.-1 Mitrovicë	\N
614	1469	1	GASHI Y SH.P.K.-Mitrovicë Veriore	\N
616	1477	1	GEGË RESTAURANT 1  SH.P.K.-Brezovice	\N
617	1477	2	GEGË RESTAURANT 2  SH.P.K.	\N
618	1481	2	GENA NTP- Gaqke	\N
615	1476	1	GEGA BARNAT.- Gjakove Sh.P.K	\N
619	1522	1	GNTC Group  SH A	\N
621	1522	4	GNTC Group  SH A -Gjilan	\N
620	1522	6	GNTC Group  SH A -Ferizaj	\N
623	1522	5	GNTC Group  SH A -Peje	\N
625	1522	7	GNTC Group SH A - Lipjan	\N
622	1522	2	GNTC Group  SH A -Mitrovice	\N
626	1522	9	GNTC Group SH A - Malisheve	\N
628	1522	24	GNTC Group SH A -Crep	\N
627	1522	8	GNTC Group SH A - Viti	\N
629	1522	10	GNTC Group SH A Depo Qendrore-Lipjan	\N
631	1522	30	GNTC Group SH A -Fushe Kosove	\N
630	1522	27	GNTC Group SH A -Doganaj	\N
632	1522	13	GNTC Group SH A -Gjakove	\N
633	1522	19	GNTC Group SH A -Greme	\N
635	1522	12	GNTC Group SH A -H Prishtine	\N
634	1522	33	GNTC Group SH A -Gurakoc Istog	\N
637	1522	23	GNTC Group SH A -Kaqanik	\N
638	1522	15	GNTC Group SH A -Kline	\N
639	1522	18	GNTC Group SH A -Korishe	\N
636	1522	11	GNTC Group SH A -Hoteli Prishtine	\N
641	1522	31	GNTC Group SH A -Mitrovice Veriore	\N
642	1522	16	GNTC Group SH A -Podujeve	\N
643	1522	28	GNTC Group SH A -Prishtine	\N
644	1522	32	GNTC Group SH A -Rahovec	\N
645	1522	21	GNTC Group SH A -Shtime	\N
646	1522	22	GNTC Group SH A -Skenderaj	\N
647	1522	25	GNTC Group SH A -Sllatinë	\N
648	1522	14	GNTC Group SH A -Therande	\N
649	1522	17	GNTC Group SH A -Vushtrri	\N
650	1522	26	GNTC Group SH A -Xërxë	\N
651	1522	29	GNTC Group Sh.A-Drenas	\N
652	1534	3	Golden Market SH.P.K 3.-Prishtinë	\N
653	1545	1	GR ERIONA Shpk - Lakrishte- Prishtine	\N
654	1558	1	GREEN SALLAD 1-  Prishtine	\N
655	1558	3	GREEN SALLAD 3-  Prizeren	\N
656	1558	6	GREEN SALLAD 4-  Albi Mall	\N
657	1558	5	GREEN SALLAD 4-  Prishtina Mall	\N
658	1558	7	GREEN SALLAD 5-  Albi Mall Gjilan	\N
660	1563	1	GRESA LOUNGE RESTAURANT SHPK Njesi 1	\N
661	1569	2	GRYKA 1 SHPK-Shtimje	\N
662	1569	1	GRYKA SHPK-Shtimje	\N
663	1579	1	HA SA SH.P.K.-Ferizaj	\N
664	1581	2	HAJDINI 1 NTP- DRENAS	\N
665	1581	1	HAJDINI 2 NTP  - Drenas	\N
666	1599	1	Happy Days 2 D.O.O Njesia 2 Shterpce	\N
667	1599	2	HAPPY DAYS 2 D.O.O.	\N
668	1604	1	HAS 4 SH.P.K.-HQs -Prishtine	\N
669	1613	1	HEALTHSOME SH.P.K. 1 -Prishtinë	\N
670	1613	2	HEALTHSOME SH.P.K. 2-Fushe  Kosove	\N
671	1622	1	HIB Petrol Corporation SH.P.K.-F.Kosove	\N
672	1622	3	HIB Petrol Corporation SH.P.K.-Ferizaj 1	\N
673	1622	4	HIB Petrol Corporation SH.P.K.-Ferizaj 2	\N
674	1622	5	HIB Petrol Corporation SH.P.K.-Ferizaj 3	\N
675	1622	8	HIB Petrol Corporation SH.P.K.-Ferizaj 4	\N
676	1622	6	HIB Petrol Corporation SH.P.K.-Gjilan	\N
677	1622	10	HIB Petrol Corporation SH.P.K.-Kalabri	\N
678	1622	2	HIB Petrol Corporation SH.P.K.-Mitrovicë	\N
680	1622	9	HIB Petrol Corporation SH.P.K.-Viti	\N
681	1623	1	HIB PETROL  - EMERALD HOTEL - CAGLLAVICE	\N
682	1623	13	HIB PETROL - CAGLLAVICE	\N
683	1623	2	HIB PETROL - FUSHE KOSOVE	\N
684	1623	14	HIB PETROL - GJILAN	\N
685	1623	10	HIB PETROL - KOMORAN	\N
686	1623	12	HIB PETROL - MITROVICE	\N
687	1623	16	HIB PETROL - PEJE	\N
688	1623	15	HIB PETROL - PODUJEVE	\N
689	1623	9	HIB PETROL - PRIZREN	\N
690	1623	21	HIB PETROL - VITI	\N
691	1623	3	HIB PETROL 1 - FERIZAJ	\N
692	1623	7	HIB PETROL 1 - LIPJAN	\N
693	1623	4	HIB PETROL 2 - FERIZAJ	\N
694	1623	8	HIB PETROL 2 - LIPJAN	\N
580	1345	1	FLORENTI - Mitrovice NPT	\N
581	1345	3	FLORENTI 3 - Mitrovice NPT	\N
582	1345	4	FLORENTI- Agim Hajrizi-Mitrovice	\N
583	1362	1	FREE SHOP A-Prishtine	\N
584	1391	1	Fresh Fruits 005 SH.P.K.-Ferizaj	\N
585	1391	2	Fresh Fruits 005 SH.P.K.-Rr.Reçaku	\N
586	1393	1	FRESH MARKET 2 SH.P.K 1.-PEJE	\N
587	1393	2	FRESH MARKET 2 SH.P.K 2.-PEJE	\N
589	1402	1	FRESHI SHPK - PEJE	\N
590	1402	2	Freshi Shpk - Peje 2	\N
591	1402	3	Freshi Shpk - Peje 3	\N
592	1411	1	FRUITS MARKET SHPK-Prishtinë	\N
593	1411	2	FRUITS MARKET2 SHPK-Prishtinë	\N
594	1412	3	FRUKTAL GROUP SHPK-(Depo)-Ferizaj	\N
595	1412	4	FRUKTAL GROUP SHPK-Fat.Retkoceri-Ferizaj	\N
596	1413	4	FRUTARIA  SHPK-Ferizaj 2	\N
597	1413	6	FRUTARIA  SHPK-Ferizaj 6	\N
598	1413	5	FRUTARIA  SHPK-Greme 7	\N
599	1413	19	FRUTARIA SHPK 11 - Ferizaj	\N
600	1413	15	FRUTARIA SHPK 15-Ferizaj	\N
601	1413	1	FRUTARIA SHPK-Ferizaj 1	\N
602	1413	3	FRUTARIA SHPK-Ferizaj 3	\N
603	1413	9	FRUTARIA SHPK-Fushe Kosove	\N
605	1413	2	FRUTARIA SHPK-Prishtine  4	\N
606	1413	11	FRUTARIA SHPK-Velani	\N
607	1413	10	FRUTARIA SHPK-Veterrnik	\N
609	1421	2	Fuat Shabani B.I.-Market Narti 2017	\N
608	1421	1	Fuat Shabani B.I.-Market Narti 2017	\N
611	1465	3	GASHI Commerce NTP - Tusuz Prizren	\N
612	1465	2	GASHI Market - Prizren	\N
729	1633	9	HOFFMAN Stores SH.P.K. 9- Peje	\N
730	1657	1	IDEAL CENTER SHPK 1- PEJE	\N
731	1657	2	IDEAL CENTER SHPK 2 - PEJE	\N
732	1657	4	IDEAL CENTER SHPK 3 PEJE	\N
733	1657	3	IDEAL CENTER SHPK 4 - PEJE	\N
734	1663	2	IFFI'S SH.P.K. 2-Prishtine	\N
735	1663	1	IFFI'S SH.P.K.-Gjakove	\N
736	1675	1	ILIRIA COSMETICS 1 Shpk-Kline	\N
737	1694	5	IP KOS  PETROL SHPK - Te Amortizerat	\N
738	1694	23	IP KOS PETROL 2 SHPK-Vragoli	\N
739	1694	30	IP KOS PETROL SHPK - Arllat	\N
740	1694	26	IP KOS PETROL SHPK - Besiane	\N
741	1694	29	IP KOS PETROL SHPK - Deqan	\N
743	1694	10	IP KOS PETROL SHPK - Ferizaj	\N
744	1694	32	IP KOS PETROL SHPK - Fidanishte Peje	\N
745	1694	39	IP KOS PETROL SHPK - Gjakove	\N
747	1694	25	IP KOS PETROL SHPK - Kline	\N
748	1694	45	IP KOS PETROL SHPK - Merdare	\N
746	1694	35	IP KOS PETROL SHPK - Gjakove	\N
749	1694	3	IP KOS PETROL SHPK - PENUH - BESIANE	\N
750	1694	9	IP KOS PETROL SHPK - Poklek - Drenas	\N
751	1694	40	IP KOS PETROL SHPK - Preoc 2	\N
753	1694	6	IP KOS PETROL SHPK - Prizren	\N
752	1694	4	IP KOS PETROL SHPK - Prishtine - Te qafa	\N
754	1694	2	IP KOS PETROL SHPK - QYSHKE - PEJE	\N
756	1694	31	IP KOS PETROL SHPK - Sojeve Ferizaj	\N
755	1694	8	IP KOS PETROL SHPK - Rr.Ferizajit-Gjilan	\N
758	1694	37	IP KOS PETROL SHPK - Vranjevc	\N
757	1694	24	IP KOS PETROL SHPK - VITI	\N
760	1694	42	IP KOS PETROL SHPK 13- Prizeren	\N
762	1694	44	IP KOS PETROL SHPK 19- Prizeren	\N
761	1694	27	IP KOS PETROL SHPK 19 - Prizeren	\N
763	1694	28	IP KOS PETROL SHPK 24- Gurakoc	\N
764	1694	41	IP KOS PETROL SHPK 48- Drenas	\N
765	1694	43	IP KOS PETROL SHPK 79- Komoran	\N
767	1694	12	IP KOS PETROL SHPK -Vushtrri	\N
766	1694	7	IP KOS PETROL SHPK -Rr. Bujanovci Gjilan	\N
768	1694	14	IP KOS PETROL SHPK-Bazhdarhane Prizeren	\N
770	1694	16	IP KOS PETROL SHPK-Kamenice	\N
769	1694	17	IP KOS PETROL SHPK-Gjurakovc Istog	\N
771	1694	18	IP KOS PETROL SHPK-Kaqanik	\N
773	1694	15	IP KOS PETROL SHPK-LIPJAN	\N
774	1694	20	IP KOS PETROL SHPK-Preoc	\N
772	1694	13	IP KOS PETROL SHPK-Kastriot	\N
775	1694	19	IP KOS PETROL SHPK-Shapkos Mitrovice	\N
777	1694	22	IP KOS PETROL SHPK-Vushtrri	\N
778	1717	1	JARA PHARMACY SHPK	\N
779	1717	2	JARA PHARMACY SHPK-1 Galaria Shopping	\N
780	1741	2	JORA CENTER SHPK 2-Fushe Kosove	\N
781	1741	3	JORA CENTER SHPK 3-Komoran	\N
782	1741	1	JORA CENTER SHPK-KOMORAN	\N
783	1758	2	Kafshate Sh.p.k- Njesi 2  Prishtine	\N
784	1758	1	Kafshate Sh.p.k-Njesia 1-Fushe Kosove	\N
785	1770	1	KAI Cosmetics	\N
786	1773	2	KASTRATI CENTER SH.P.K.- Shirok, Suharek	\N
787	1773	1	KASTRATI CENTER SH.P.K.-Malishevë	\N
788	1798	10	Kipper 10-Ferizaj	\N
789	1798	11	Kipper 11- Ferizaj	\N
790	1798	12	Kipper 12-Prishtine	\N
791	1798	13	Kipper 13-Ferizaj	\N
792	1798	14	Kipper 14-Gjilan	\N
793	1798	15	Kipper 15-Ferizaj	\N
794	1798	16	Kipper 16-Ferizaj	\N
795	1798	17	Kipper 17-Prishtine	\N
796	1798	18	Kipper 18-Gjilan	\N
797	1798	19	Kipper 19-Prizren	\N
798	1798	1	Kipper 1-Lipjan	\N
799	1798	2	Kipper 2- Ferizaj	\N
800	1798	20	Kipper 20-Viti	\N
801	1798	21	Kipper 21-Prizren	\N
802	1798	22	Kipper 22-Gjakove	\N
804	1798	24	Kipper 24-Gjilan	\N
805	1798	25	Kipper 25-Gjilan	\N
806	1798	26	Kipper 26-Vushtrri	\N
807	1798	27	Kipper 27-Lipjan	\N
808	1798	28	Kipper 28-Fushe Kosove	\N
809	1798	30	Kipper 30-Prishtine	\N
810	1798	31	Kipper 31-Prizren	\N
696	1623	5	HIB PETROL 3 - FERIZAJ	\N
697	1623	19	HIB PETROL 4-Ferizaj	\N
698	1623	23	HIB PETROL -Gjakove	\N
699	1623	25	HIB PETROL -Komoran 2	\N
700	1623	22	HIB PETROL -Prishtine	\N
701	1623	26	HIB PETROL -Vushtrri	\N
702	1623	27	HIB PETROL-PRIZREN 3	\N
703	1623	18	HIB PETROL-Shkabaj	\N
705	1624	17	HIB Restaurantet SH.P.K.-Ferizaj 2	\N
706	1624	9	HIB Restaurantet SH.P.K.-Komoran	\N
707	1624	6	HIB Restaurantet SH.P.K.-Mitrovicë	\N
708	1624	4	HIB Restaurantet SH.P.K.-Prizeren 1	\N
709	1624	3	HIB Restaurantet SH.P.K.-Prizeren 2	\N
710	1624	10	HIB Restaurantet SH.P.K.-Shkabaj	\N
711	1633	14	HOFFMAN Depo	\N
712	1633	19	HOFFMAN Store SH.P.K. 18-Gjakove	\N
713	1633	20	HOFFMAN Store SH.P.K. 19-Mitrovice	\N
714	1633	1	HOFFMAN Stores SH.P.K. 1 -Prishtinë	\N
715	1633	10	HOFFMAN Stores SH.P.K. 10- Prishtine	\N
716	1633	11	HOFFMAN Stores SH.P.K. 11- Prishtine	\N
717	1633	12	HOFFMAN Stores SH.P.K. 12- Vushtrri	\N
720	1633	16	HOFFMAN Stores SH.P.K. 15-Fushe Kosove	\N
721	1633	17	HOFFMAN Stores SH.P.K. 16-Eliza F.Kosove	\N
722	1633	18	HOFFMAN Stores SH.P.K. 17-Drenas	\N
723	1633	2	HOFFMAN Stores SH.P.K. 2 -Prishtinë	\N
724	1633	4	HOFFMAN Stores SH.P.K. 4 -Ferizaj	\N
725	1633	5	HOFFMAN Stores SH.P.K. 5- Gjilan	\N
726	1633	6	HOFFMAN Stores SH.P.K. 6- Mitrovice	\N
727	1633	7	HOFFMAN Stores SH.P.K. 7- Fushe Kosove	\N
728	1633	8	HOFFMAN Stores SH.P.K. 8- Ferizaj	\N
844	1886	3	LANDI STAR SHPK Njesia 3-Gjakove	\N
845	1886	4	LANDI STAR SHPK Njesia 4-Gjakove	\N
846	1886	1	LANDI STAR SHPK-Gjakove	\N
847	1886	5	Landi Star SHPK-Kozmetike	\N
848	1886	6	Landi Star SHPK-Njesi 7	\N
849	1898	1	LAVDA SHPK-FUSHE KOSOVE	\N
850	1902	2	LEAR MARKET SH.P.K. 2 -Gjilan	\N
852	1913	4	Lenoma SHPK 04	\N
853	1913	2	LENOMA SHPK 2 -Ferizaj	\N
854	1913	3	LENOMA SHPK 3- Ferizaj	\N
855	1913	1	LENOMA SHPK-Ferizaj	\N
856	1919	1	LENTIL FOODS SH.P.K.	\N
857	1919	2	LENTIL FOODS SH.P.K. 2	\N
858	1931	2	LID Market SH.P.K 1 -Prizren	\N
859	1931	3	LID Market SH.P.K 3 -Prizren	\N
860	1931	4	LID Market SH.P.K 4 -Prizren	\N
861	1931	5	LID Market SH.P.K 5-Prizren	\N
862	1931	6	LID Market SH.P.K 6-Prizren	\N
863	1931	7	LID Market SH.P.K 7-Prizren	\N
864	1931	1	LID Market SH.P.K-Prizren	\N
865	1932	3	LIDER MARKET SH.P.K 3.-Drenas	\N
867	1932	1	LIDER MARKET SH.P.K.-Gllogoc	\N
868	1932	2	LIDER MARKET SH.P.K.-Korretice	\N
869	1948	1	LINDI MARKET - Greme Ferizaj	\N
870	1954	1	LIPS CAFFE - Prishtine Sh.P.K	\N
871	1965	2	LIRIDONI QT SHPK 2 -Deqan	\N
872	1965	3	LIRIDONI QT SHPK 3 -Gjakove	\N
873	1965	4	LIRIDONI QT SHPK 4 -Peje	\N
874	1965	1	LIRIDONI QT SHPK-Peje	\N
875	1976	2	LM KUSHTRIMI SHPK-4 Prishtine	\N
876	1976	4	LM KUSHTRIMI SHPK-6 Prishtine	\N
877	1988	1	LORD`s 3 SH.P.K.-Prishtinë	\N
878	1991	1	LORIKU- Malisheve Sh.P.K	\N
879	1991	5	LORIKU- Peje	\N
880	1991	4	LORIKU- Prishtine	\N
881	1991	2	LORIKU- Prizeren	\N
882	1991	3	LORIKU- Prizren ( Rr. Tirana nr 5)	\N
883	2003	2	LUANI LLG SH.P.K.-1 Mehmet Bajraktari	\N
884	2003	1	LUANI LLG SH.P.K.-Pejë	\N
885	2005	1	LUANI NT DEPO-PEJE	\N
886	2006	2	LUANI-SG  2 SHPK-Peje	\N
887	2006	1	LUANI-SG SHPK-Peje	\N
888	2017	2	DIAMOND HOTEL	\N
890	2045	2	MAB PROJECT SHPK - MITROVICE	\N
891	2055	2	Maison Ysabel SH.P.K. Kati 23	\N
892	2057	2	Majlinda Duriqi B.I.(Donati 3 DPT)-02	\N
893	2057	1	Majlinda Duriqi B.I.(Donati 3 DPT)-Prish	\N
894	2063	4	Malesia Petrol Muhamet Maloku B.I	\N
895	2073	2	MALVESA GROUP SH.P.K. 02-Vushtrri	\N
896	2073	3	MALVESA GROUP SH.P.K. 03-Peje	\N
897	2073	4	MALVESA GROUP SH.P.K. 04-Prizeren	\N
898	2084	2	MANI DEPO SHPK-Bellanice 2	\N
899	2084	1	MANI DEPO SHPK-Malisheve	\N
901	2086	2	MANI DEPO - Malisheve NTP	\N
902	2086	3	MANI MARKET 1 Bekimi - Malisheve NTP	\N
903	2111	2	Market Caprilla SH.P.K Depo.-Lipjan	\N
904	2111	1	Market Caprilla SH.P.K.-Lipjan	\N
905	2125	2	Market Express Molla SH.P.K 2.-Gavran	\N
906	2125	1	Market Express Molla SH.P.K.-Gjilan	\N
907	2140	2	Market Lini SH.P.K. 2-Prizren	\N
908	2140	3	Market Lini SH.P.K.-Prizeren	\N
909	2140	1	Market Lini SH.P.K.-Prizren	\N
910	2175	2	MARKOVAC 2 - Plemetin - Obiliq	\N
911	2175	1	MARKOVAC P..P - Plemetin-Obiliq Sh.P.K	\N
912	2176	1	Marlette SH.P.K.-Fushë Kosovë	\N
913	2181	13	MARTIUS L.L.C -Matisse- Ferizaj	\N
914	2181	12	MARTIUS L.L.C -Matisse- Gjakove	\N
915	2181	14	MARTIUS L.L.C -Matisse- Gjilan	\N
916	2181	11	MARTIUS L.L.C -Matisse- Prishtina Mall	\N
917	2181	3	MARTIUS L.L.C.-Matisse Albi Mall	\N
918	2181	10	MARTIUS L.L.C.-Matisse -Central Park	\N
919	2181	9	MARTIUS L.L.C.-Matisse -Podujevë	\N
920	2181	2	MARTIUS L.L.C.-Matisse -Prizeren	\N
921	2181	8	Martius LLC-Ulpiane	\N
922	2181	5	MATISSE - Rruga B	\N
924	2185	2	MAX Market SHPK-2 Gjilan	\N
925	2185	1	MAX Market SHPK-Gjilan	\N
926	2199	1	MEDITERAN 2 SHPK - Viti	\N
927	2199	2	MEDITERAN SHPK - VITI	\N
928	2208	2	Melisa Market SH.P.K. 2-Vushtrri	\N
929	2208	1	Melisa Market SH.P.K.-Vushtrri	\N
812	1798	34	Kipper 34-Peje	\N
813	1798	35	Kipper 35-Fushe Kosove	\N
814	1798	36	Kipper 36- Prishtine	\N
815	1798	37	Kipper 37 -Prishtine	\N
816	1798	38	Kipper 38- Prishtine	\N
817	1798	39	Kipper 39- Viti	\N
818	1798	3	Kipper 3-Ferizaj	\N
819	1798	4	Kipper 4-Ferizaj	\N
820	1798	5	Kipper 5-Shtime	\N
822	1798	7	Kipper 7-Lipjan	\N
823	1798	8	Kipper 8- Kaqanik	\N
824	1798	9	Kipper 9-Lipjan	\N
825	1798	40	Kipper Depo-Lipjan	\N
826	1819	1	Konmar 2-Gjilan	\N
827	1832	2	ZAHIDE ADEMAJ B.I. 2 -Mitrovicë	\N
828	1832	1	ZAHIDE ADEMAJ B.I.-Mitrovicë	\N
829	1839	1	KRONI COMMERC  1  - Drenas	\N
830	1855	2	ARTI MARKET SHPK- MATI 1 - PRISHTINE	\N
831	1855	1	KUSHTRIMI& B SHPK- PRISHTINE	\N
832	1868	1	Labi - Petrol N.T.P.	\N
833	1868	2	Labi Petrol Korishe 1	\N
834	1868	3	Labi Petrol Korishe 2	\N
835	1878	9	LAB-OIL 9-Prishtine	\N
837	1878	4	LAB-OIL SHPK 1-Komoran	\N
838	1878	5	LAB-OIL SHPK 2-Komoran	\N
839	1878	6	LAB-OIL SHPK -Prishtine	\N
840	1878	2	LAB-OIL SHPK-Bresje Fushe Kosove	\N
841	1885	2	LANDI STAR RSH 1 SH.P.K.-Gjakovë	\N
842	1885	1	LANDI STAR RSH SH.P.K.-Gjakovë	\N
843	1886	2	LANDI STAR SHPK Njesia 2-Gjakove	\N
963	2225	26	MERIDIAN EXPRESS 3-GJAKOVE-Beqir Kastra	\N
964	2225	52	MERIDIAN EXPRESS 48 -Fushe Kosove	\N
965	2225	53	MERIDIAN EXPRESS 49 -Prishtine B1	\N
966	2225	56	MERIDIAN EXPRESS 53-Prishtine	\N
967	2225	63	MERIDIAN EXPRESS 59-Exfis Komoran	\N
968	2225	11	MERIDIAN EXPRESS- Afer Restauran Davidof	\N
969	2225	1	MERIDIAN EXPRESS- Arberi PRISHTINE	\N
970	2225	4	MERIDIAN EXPRESS- FERIZAJ	\N
971	2225	49	MERIDIAN EXPRESS -Gjilan Adem Jashari 2	\N
972	2225	16	MERIDIAN EXPRESS- LAGJIA SPITALIT	\N
973	2225	6	MERIDIAN EXPRESS- MITROVICE	\N
974	2225	64	MERIDIAN EXPRESS- Mitrovice e Veriut	\N
976	2225	62	MERIDIAN EXPRESS Prime-Prishtine	\N
977	2225	54	MERIDIAN EXPRESS -Prishtine	\N
978	2225	51	MERIDIAN EXPRESS -Rr. William Walker	\N
979	2225	14	MERIDIAN EXPRESS- Rr.Rexhep Krasniq- UBT	\N
980	2225	13	MERIDIAN EXPRESS-DEPO QENDRORE-Prishtin	\N
981	2225	37	MERIDIAN EXPRESS-Deshmoret e kom-Ferizaj	\N
982	2225	21	MERIDIAN EXPRESS-FERIZAJ-REXHEP BISLIMI	\N
983	2225	20	MERIDIAN EXPRESS-GJILAN BRIGADA E UCK-SE	\N
984	2225	39	MERIDIAN EXPRESS-Gjilan-Adem Jashari	\N
985	2225	41	MERIDIAN EXPRESS-Lagjia e Spitali-Shpija	\N
986	2225	27	MERIDIAN EXPRESS-MITROVIC-Rr UÇK-s	\N
987	2225	23	MERIDIAN EXPRESS-PEJE - ADEM JASHARI	\N
988	2225	42	MERIDIAN EXPRESS-Prishtine	\N
989	2225	10	MERIDIAN EXPRESS-Tophane-Prishtine	\N
990	2227	2	Merlinda Halili B.I.-2 Prishtine	\N
991	2231	1	Mess market Sh.p.k.-Ferizaj -Objekti 1	\N
992	2231	2	Mess Market Sh.p.k.-Ferizaj Objekti 2	\N
994	2240	5	Metro Market Group  SH.P.K 5 .-Babush,	\N
995	2240	6	Metro Market Group  SH.P.K 6 .-Begrace	\N
996	2240	2	Metro Market Group Njesia 1 SH.P.K.	\N
997	2240	3	Metro Market Group Njesia 3 SH.P.K.	\N
998	2240	4	Metro Market Group Njesia 4 SH.P.K.	\N
999	2240	1	Metro Market Group SH.P.K.	\N
1000	2246	1	MIGROS GROUP SHPK- PRISHTINE	\N
1001	2286	2	Molla Express Shpk- Gjilan	\N
1002	2286	1	Molla Express Shpk-qarkorja Gjilan-Kamen	\N
1003	2351	3	N.P.H. "BISTROL" 2 -Film City - Arberi	\N
1004	2351	2	N.P.H. "BISTROL" 2 -Fushe Kosove	\N
1005	2351	1	N.P.H. "BISTROL"-Mitrovicë	\N
1006	2364	1	N.T.P. BUKËPJEKËS " QERIMI 1 "-B.Diellit	\N
1007	2370	5	Cherry Store 4 Ferizaj	\N
1008	2370	4	Cherry Store Om - Emin Duraku Ferizaj	\N
1009	2370	6	Cherry Store Om - Ferizaj	\N
1011	2370	7	Cherry Store Om -Babush	\N
1010	2370	3	Cherry Store Om - Ferizaj	\N
1013	2370	9	Cherry Store SHPK-Ferizaj	\N
1015	2370	1	N.T.SH. " O & M "-Ferizaj	\N
1012	2370	2	Cherry Store SHPK-Feriza	\N
1016	2390	1	NATYRA 1 NTP  - Shtime	\N
1017	2390	2	NATYRA 2 NTP - Shtime	\N
1014	2370	8	Cherry Store SHPK-Ferizaj	\N
1021	2409	4	NERTILI-Brekoc Gjakove	\N
1019	2409	3	NERTILI - Hysni Dobruna	\N
1020	2409	2	NERTILI 1 - Gjakove	\N
1024	2451	2	NORA MARKET SHPK-Kline	\N
1023	2451	3	NORA MARKET SHPK-Istog	\N
1025	2456	29	NORWEGIAN PX  07-Prishtine	\N
1026	2456	30	NORWEGIAN PX  09-Prishtine	\N
1028	2456	32	NORWEGIAN PX  30-Zona Industriale	\N
1022	2451	1	NORA MARKET SHPK-Fushe Kosove	\N
1029	2456	26	NORWEGIAN PX  6 - Prishtine	\N
1027	2456	31	NORWEGIAN PX  15-Prishtine	\N
1030	2456	28	NORWEGIAN PX  CAFE&RESTAURANT	\N
1033	2456	24	NORWEGIAN PX  MAXI E-SHOP	\N
1031	2456	27	NORWEGIAN PX  Depo - Prishtine	\N
1036	2456	11	NORWEGIAN PX 11 - Dardani- Prishtine	\N
1035	2456	10	NORWEGIAN PX 10- Bregu i Diellit Pr.	\N
1034	2456	1	NORWEGIAN PX 1 - Prishtine Sh.P.K	\N
1037	2456	21	NORWEGIAN PX 12-Prishtine Velani	\N
932	2225	59	MERIDIAN EXFIS Lipjan	\N
931	2225	61	MERIDIAN EXFIS Kijeve	\N
935	2225	12	MERIDIAN EXPRES- Dragodan -Te Cigllana	\N
936	2225	65	MERIDIAN EXPRESS-  046 Prizren Kabash	\N
933	2225	60	MERIDIAN EXFIS Llapushnik	\N
938	2225	31	MERIDIAN EXPRESS - AFER REST.DUBROVNIKUT	\N
937	2225	58	MERIDIAN EXPRESS  54-Prishtine	\N
939	2225	25	MERIDIAN EXPRESS - FERID CURRI-PRISHTINE	\N
940	2225	57	MERIDIAN EXPRESS  -Fushe Kosove 2	\N
941	2225	5	MERIDIAN EXPRESS - GJILAN	\N
942	2225	35	MERIDIAN EXPRESS - GJILAN -15 Qershori	\N
943	2225	34	MERIDIAN EXPRESS - HAJRULLAH ABDULLAHI	\N
944	2225	33	MERIDIAN EXPRESS - Ismet Jashari	\N
945	2225	32	MERIDIAN EXPRESS - MUSTAFE VENHARI	\N
946	2225	45	MERIDIAN EXPRESS - Perballe BosnesKurriz	\N
947	2225	47	MERIDIAN EXPRESS-  PRI Ali Pashe Tepelen	\N
948	2225	40	MERIDIAN EXPRESS - Prishtine -  Mati 1	\N
949	2225	2	MERIDIAN EXPRESS 002- Emshir PRISHTINE	\N
950	2225	3	MERIDIAN EXPRESS 003- Veternik-PRISHTINE	\N
951	2225	8	MERIDIAN EXPRESS 008- GJAKOVE	\N
952	2225	15	MERIDIAN EXPRESS 014- GJAKOVE	\N
954	2225	7	MERIDIAN EXPRESS 022 - PEJE	\N
955	2225	30	MERIDIAN EXPRESS 026 - I.POPOVC-MITROVIC	\N
956	2225	43	MERIDIAN EXPRESS 038-Rruga e Zagrebit-Pr	\N
957	2225	44	MERIDIAN EXPRESS 040- Marigona Rezidence	\N
958	2225	46	MERIDIAN EXPRESS 041-PRI Gazmend Zajmi 2	\N
959	2225	48	MERIDIAN EXPRESS 042- PRI Dardania	\N
960	2225	55	MERIDIAN EXPRESS 051 -Ulpiane Prishtine	\N
961	2225	22	MERIDIAN EXPRESS 1-PRIZREN	\N
962	2225	29	MERIDIAN EXPRESS 3 FERIZAJ	\N
1071	2570	1	PASA DÖNER SH.P.K. Njesi 1	\N
1072	2570	2	PASA DÖNER SH.P.K. Njesi 2	\N
1073	2576	2	Bar Bon- Abi Qarshi	\N
1074	2576	1	PASSAGE Prime SHPK-Prizeren	\N
1075	2577	3	PASTA FASTA SHPK Depo Prishtinë	\N
1076	2600	10	PETROL COMPANY 2 SHPK- ÇAGLLAVICE	\N
1077	2600	23	PETROL COMPANY SHPK - Arllat	\N
1078	2600	17	PETROL COMPANY SHPK - Baza Fushe Kosove	\N
1079	2600	14	PETROL COMPANY SHPK - FERIZAJ 2	\N
1080	2600	11	PETROL COMPANY SHPK - GJILAN	\N
1081	2600	22	PETROL COMPANY SHPK - Hajvali	\N
1082	2600	20	PETROL COMPANY SHPK - Kline	\N
1084	2600	15	PETROL COMPANY SHPK - MTROVICE	\N
1085	2600	21	PETROL COMPANY SHPK - Peje 3	\N
1086	2600	13	PETROL COMPANY SHPK - PRISHTINE	\N
1087	2600	19	PETROL COMPANY SHPK - Prizren 2	\N
1088	2600	16	PETROL COMPANY SHPK - Qender Peje	\N
1089	2600	12	PETROL COMPANY SHPK - RAHOVEC	\N
1090	2600	18	PETROL COMPANY SHPK - Skenderaj	\N
1091	2600	28	PETROL COMPANY SHPK - VITI	\N
1092	2600	29	PETROL COMPANY SHPK - Vushtrri	\N
1093	2600	30	PETROL COMPANY SHPK 47 -KLINE	\N
1094	2600	26	PETROL COMPANY SHPK 50 - PEJE	\N
1095	2600	33	PETROL COMPANY SHPK 71 -Trude	\N
1096	2600	32	PETROL COMPANY SHPK 87 -GJAKOVE	\N
1097	2600	31	PETROL COMPANY SHPK 89 -GJAKOVE	\N
1098	2600	7	PETROL COMPANY SHPK- BESIANE	\N
1099	2600	4	PETROL COMPANY SHPK- BRESJE	\N
1100	2600	1	PETROL COMPANY SHPK- ÇAGLAVICE	\N
1102	2600	6	PETROL COMPANY SHPK- FERIZAJ	\N
1103	2600	2	PETROL COMPANY SHPK- FUSHE KOSOVE	\N
1104	2600	9	PETROL COMPANY SHPK- GJAKOVE	\N
1105	2600	8	PETROL COMPANY SHPK- PRIZREN	\N
1106	2600	5	PETROL COMPANY SHPK- QYSHKE - PEJE	\N
1107	2601	2	PETROL KABASHI SHPK - Polac	\N
1108	2620	1	PIZZA CRUST L.L.C.-Prishtinë	\N
1109	2634	1	Plus Market group SH.P.K.	\N
1110	2634	2	Plus Market group SH.P.K. 2-Ferizaj	\N
1111	2634	4	Plus market group SH.P.K. 3 -Sojeve	\N
1112	2634	3	Plus Market group SH.P.K. 3-Ferizaj	\N
1113	2641	1	Ponte Lounge SHPK-ABI Prizeren	\N
1114	2641	2	Ponte Lounge SHPK-Jaglenice Prizeren	\N
1115	2654	2	PREMIJA MARKET DPT - GRAQANICE	\N
1116	2654	1	PREMIJA MARKET DPT - GUSHTERIC	\N
1117	2658	2	PREMIUM DAA SH.P.K.-Mitrovicë	\N
1118	2665	12	PRETTY SHPK  -Suhareke	\N
1119	2665	5	PRETTY SHPK 14 -Prishtinë	\N
1120	2665	15	PRETTY SHPK 16 -Prishtine	\N
1121	2665	10	PRETTY SHPK 2 -Ferizaj	\N
1122	2665	8	PRETTY SHPK 3 -Gjilan	\N
1123	2665	2	PRETTY SHPK 5 -Gjakove	\N
1124	2665	13	PRETTY SHPK 7  -Ferizaj	\N
1125	2665	6	PRETTY SHPK 8 -Fushe Kosove	\N
1126	2669	1	PRIME MARKET SH.P.K.	\N
1128	2672	1	PRISHTINA CITY SHOP SHPK-Fushe Kosove	\N
1129	2678	1	PRIZMA 1 - Plemetin-Obiliq Sh.P.K	\N
1130	2678	2	PRIZMA 2 - Plemetin - Obiliq	\N
1131	2683	21	MOS FATURO-GABIM	\N
1132	2683	33	Proex 29-Ferizaj II	\N
1133	2683	34	Proex 30 - Fushe Kosova II	\N
1134	2683	36	Proex 31 Prishtinë -Central Park	\N
1135	2683	35	Proex 32 - Istog	\N
1136	2683	37	Proex 33 - Prishtinë, Rrethi Marigona	\N
1137	2683	40	Proex 34 Kline	\N
1138	2683	39	Proex 36 Gjakove	\N
1139	2683	41	Proex 37 Leposaviq	\N
1140	2683	43	Proex 38 - Velani Prishtinë	\N
1141	2683	42	Proex 40 - Vitomerice-Peje	\N
1143	2683	9	Proex Sh.p.k	\N
1144	2683	17	Proex Sh.p.k	\N
1145	2683	5	Proex Sh.p.k 10-Lipjan	\N
1146	2683	19	Proex Sh.p.k 12-Prizeren	\N
1147	2683	20	Proex Sh.p.k 13-Gjakove	\N
1148	2683	24	Proex Sh.p.k 14-Ferizaj	\N
1149	2683	22	Proex Sh.p.k 15-Vushtrri	\N
1150	2683	23	Proex Sh.p.k 16-Fushe Kosove	\N
1040	2456	14	NORWEGIAN PX 14-PRISHTINA ISH-OAZA	\N
1041	2456	17	NORWEGIAN PX 15-PRISHTINE ish-MSS	\N
1039	2456	16	NORWEGIAN PX 14-PRISHTINA ISH-OAZA	\N
1044	2456	20	NORWEGIAN PX 18-Prishtine Sllovenia Spor	\N
1046	2456	2	NORWEGIAN PX 2 - Te Ombuspersoni - Pr	\N
1047	2456	3	NORWEGIAN PX 3 - Prishtine Sh.P.K	\N
1045	2456	23	NORWEGIAN PX 19-Fushe Kosove -Bresje	\N
1049	2456	5	NORWEGIAN PX 5 - Lagjja e Spitalit	\N
1050	2456	7	NORWEGIAN PX 7 - Prishtine Sh.P.K	\N
1043	2456	19	NORWEGIAN PX 17-Prishtine PDK	\N
1048	2456	4	NORWEGIAN PX 4 - KALABRI	\N
1052	2456	13	NORWEGIAN PX 8- Rruga B- Prishtine	\N
1054	2456	22	NORWEGIAN PX -Tophane	\N
1053	2456	9	NORWEGIAN PX 9 - Dragodan - Pr	\N
1055	2456	12	Restaurant te Maxi - Çagllavice	\N
1057	2479	1	NUNO LOUNGE L.L.C. Njesia 1 -Prishtinë	\N
1056	2465	1	NPN RENELUAL TAHIRI  SH.P.K -ÇAGLLAVICE	\N
1051	2456	8	NORWEGIAN PX 8 - Prishtine Rruga B	\N
1060	2500	1	OLSA MARKET- Prishtine	\N
1062	2504	3	OLTI MARKET FH SH.P.K.3.-Doroshevc -Gllo	\N
1058	2479	2	NUNO LOUNGE L.L.C. Njesia 2 -Prishtinë	\N
1064	2504	5	OLTI MARKET FH SH.P.K.5	\N
1061	2504	2	OLTI MARKET FH SH.P.K 2 .-Gllogoc	\N
1065	2504	6	OLTI MARKET FH SH.P.K.6	\N
1063	2504	4	OLTI MARKET FH SH.P.K.4-Skenderaj	\N
1066	2504	1	OLTI MARKET FH SH.P.K.-Gllogoc	\N
1067	2506	1	OLYMP  PP -  Graqanice	\N
1069	2534	3	ORCHIDEA Cosmetics SH.P.K 3 Pejë	\N
1068	2534	2	ORCHIDEA Cosmetics SH.P.K 2.-Pejë	\N
1070	2534	1	ORCHIDEA Cosmetics SH.P.K.-Pejë	\N
1184	2767	4	RETAIL KOSOVA SH.P.K. 1- Fushe Kosove	\N
1185	2767	2	RETAIL KOSOVA SH.P.K. 2- Fushe Kosove	\N
1186	2767	3	RETAIL KOSOVA SH.P.K. 3-Prizren	\N
1187	2792	3	RINA COMERC SHPK 3 -Banje	\N
1188	2792	4	RINA COMERC SHPK 4 -Vrelle	\N
1189	2792	2	RINA COMERC SHPK-Gurakoc Istog	\N
1190	2792	1	RINA COMERC SHPK-Zallc Istog	\N
1191	2814	1	ROGO'S SH.P.K.-Prishtinë	\N
1193	2833	2	RUBIN COMPANY SHPK(Shega Fresh)-Prizren	\N
1194	2844	2	Sa Ëmbël Group  2 SH.P.K.-Prishtinë	\N
1195	2844	1	Sa Ëmbël Group SH.P.K.-Prishtinë	\N
1196	2845	2	SA ëmbël SH.P.K 2.-Prishtinë	\N
1197	2845	1	SA ëmbël SH.P.K.-Prishtinë	\N
1198	2862	1	Sarajeva Steak House Sh.P.K	\N
1199	2862	4	Sarajeva Steak House Sh.P.K -Njesia 5	\N
1200	2862	5	Sarajeva Steak House Sh.P.K -Njesia 7	\N
1201	2863	2	Saray Sweets SH.P.K.2 -Prishtine	\N
1202	2883	1	Seven Market L.L.C.-Graçanicë	\N
1203	2897	1	SHARRI QT SHPK Center-Komoran	\N
1204	2897	2	SHARRI QT SHPK DEPO-Komoran	\N
1205	2897	3	SHARRI QT SHPK Market -Komoran	\N
1206	2902	2	SHERIF 2 SH.P.K.-Kastriot	\N
1208	2903	1	SHERIFI PETROL  - Millosheve-  Obiliq	\N
1209	2903	2	SHERIFI PETROL 2 - Millosheve - Obiliq	\N
1210	2908	1	SHKENDIA NTSH - KAÇANIK	\N
1211	2908	2	SHKENDIA NTSH 2 - Dubrave	\N
1212	2962	2	SPAHIA MARKET - PRIZREN	\N
1213	2962	3	SPAHIA PETROL - Prizren	\N
1214	2962	5	SPAHIA PETROL - Prizren (Arban)	\N
1215	2962	4	SPAHIA PETROL - Te Spitali - Prizren	\N
1216	2962	1	SPAHIA PETROL NT- THERANDE	\N
1217	2963	2	SPAHIU-Petrol SHPK-Mazgit	\N
1218	2963	1	SPAHIU-Petrol SHPK-Prizeren	\N
1219	2965	7	SPAR KOSOVA J.S.C .-Arberi nr.140	\N
1220	2965	6	SPAR KOSOVA J.S.C .-Depo Qendrore	\N
1222	2965	5	SPAR KOSOVA J.S.C .-Ferizaj	\N
1223	2965	13	SPAR KOSOVA J.S.C .-Lagjia Dardania F.K.	\N
1224	2965	14	SPAR KOSOVA J.S.C .-Muharrem Fejza	\N
1221	2965	11	SPAR KOSOVA J.S.C .-Depo Qendrore	\N
1226	2965	9	SPAR KOSOVA J.S.C .-Prishtine	\N
1228	2965	12	SPAR KOSOVA J.S.C .-Te Qafa Prishtine	\N
1229	2965	4	SPAR KOSOVA J.S.C 3.-SwissMall Prishtine	\N
1227	2965	8	SPAR KOSOVA J.S.C .-Rruga B	\N
1232	2965	1	SPAR KOSOVA J.S.C.-Prishtine	\N
1230	2965	2	SPAR KOSOVA J.S.C.-Prishtine	\N
1231	2965	3	SPAR KOSOVA J.S.C.-Prishtine	\N
1233	2968	2	SPEKTAR 2 PP - Gracanice	\N
1235	2968	1	SPEKTAR PP- Gracanice- Prishtine	\N
1236	2977	2	STAR MARKET 2 SHPK-Ferizaj	\N
1237	2977	3	STAR MARKET 3 SHPK-Bibaj Ferizaj	\N
1234	2968	3	SPEKTAR 3 PP - Gracanice	\N
1239	2977	1	STAR MARKET SHPK-Ferizaj	\N
1241	3002	2	Super Market TINA SH.P.K.2 - Gjilan	\N
1240	3002	1	Super Market TINA SH.P.K.	\N
1243	3004	1	SUPER STORE SHPK-Dragodan	\N
1244	3005	35	POMO Restaurant 10-Varosh Ferizaj	\N
1246	3005	26	POMO Restaurant 1-Lypjan	\N
1248	3005	27	POMO Restaurant 2-Ferizaj 13	\N
1238	2977	4	STAR MARKET 4 SHPK-Ferizaj	\N
1242	3004	2	SUPER STORE SHPK 2-Shkabaj	\N
1249	3005	30	POMO Restaurant 5-Ferizaj(rr.varoshit)10	\N
1245	3005	36	POMO Restaurant 11-Xerxe	\N
1250	3005	32	POMO Restaurant -Prizeren Fatoni	\N
1252	3005	39	SUPER VIVA 21 LAGJE C - Prishtine	\N
1254	3005	45	SUPER VIVA 23-Gjakove	\N
1255	3005	47	Super Viva 25(HORECA 2)-Ferizaj	\N
1253	3005	42	SUPER VIVA 22-Kolovice Prishtine	\N
1251	3005	23	S.VIVA DEPO QENDRORE-Prishtine	\N
1256	3005	49	Super Viva 26 FK B	\N
1258	3005	43	SUPER VIVA Peje(Banacol)	\N
1259	3005	50	Super Viva SH.P.K. 27-Gjilan	\N
1261	3005	12	SUPER VIVA SHPK 12- Te Aleanca-Ulpijane	\N
1257	3005	41	SUPER VIVA 3-Prishtine	\N
1263	3005	18	SUPER VIVA SHPK 14 -Bazhderhane-Prizren	\N
1262	3005	13	SUPER VIVA SHPK 13 - Ferizaj	\N
1260	3005	22	SUPER VIVA SHPK 10-Ferizaj 4	\N
1152	2683	2	Proex Sh.p.k 18-Peje	\N
1153	2683	3	Proex Sh.p.k 19-Podujeve	\N
1154	2683	7	Proex Sh.p.k 1-Vushtrri	\N
1155	2683	4	Proex Sh.p.k 20-Prishtine	\N
1157	2683	26	Proex Sh.p.k 22-Vushtrri	\N
1158	2683	27	Proex Sh.p.k 23-Viti	\N
1159	2683	28	Proex Sh.p.k 24-Suhareke	\N
1160	2683	29	Proex Sh.p.k 25-Gjilan 3	\N
1161	2683	30	Proex Sh.p.k 26- Decan	\N
1162	2683	31	Proex Sh.p.k 27- Germi	\N
1163	2683	8	Proex Sh.p.k 2-Mitrovice	\N
1164	2683	10	Proex Sh.p.k 3-Prishtine	\N
1165	2683	11	Proex Sh.p.k 4-Prishtine	\N
1166	2683	12	Proex Sh.p.k 5-Vushtrri	\N
1167	2683	6	Proex Sh.p.k 6-Skenderaj	\N
1168	2683	13	Proex Sh.p.k 7-Prishtine	\N
1169	2683	14	Proex Sh.p.k 8-Mitrovice	\N
1170	2683	16	Proex Sh.p.k 9-Korishe	\N
1171	2683	15	Proex Sh.p.k DEPO	\N
1172	2683	32	Proex Sh.p.k -Kaqanik	\N
1174	2683	44	Proex SH.P.K. 2-Peje	\N
1175	2688	4	PUNTO CAFFE - The Village Caffe Ferizaj	\N
1176	2688	1	PUNTO CAFFE SHPK-Ferizaj	\N
1177	2689	1	PURE PHARM SH.P.K.-Fushë Kosovë	\N
1178	2698	1	Qendrim Bytyqi B.I. Njesi 1	\N
1179	2698	2	Qendrim Bytyqi B.I. Njesi 2	\N
1180	2734	2	Market LONI - Drenas	\N
1181	2753	1	RESTAURANT TE SYLA & FATONI PREVALL	\N
1182	2753	2	RESTAURANT TE SYLA & FATONI- Prizren	\N
1183	2767	1	RETAIL KOSOVA SH.P.K.	\N
1298	3145	3	TONI MARKET SHPK 3- Prishtine	\N
1299	3149	1	TOP MARKET GROUP TMG SHPK- Njesia 1	\N
1300	3149	2	TOP MARKET GROUP TMG SHPK-Njesia 2	\N
1301	3159	2	Tregu ditor 2025 2	\N
1302	3162	8	N'MOLLE 1- Ulpiane Prishtine	\N
1303	3162	9	N'MOLLE 2- Breg te diellit Prishtine	\N
1304	3162	2	TREGU GROUP SHPK Emshir Prishtine	\N
1305	3162	19	TREGU GROUP SHPK- Muharrem Fejza	\N
1306	3162	18	TREGU GROUP SHPK- Prishtine	\N
1307	3162	1	TREGU GROUP SHPK -Prishtine	\N
1309	3162	20	Tregu Group SHPK-Dragodan	\N
1310	3162	4	TREGU GROUP SHPK-Ish Benfi Ulpiane	\N
1311	3162	3	TREGU GROUP SHPK-Ish tregu i ri B.G.	\N
1312	3162	7	TREGU GROUP SHPK-Pejton	\N
1313	3162	15	TREGU GROUP SHPK-Prishtine	\N
1314	3162	16	TREGU GROUP SHPK-Rruga B	\N
1315	3162	14	TREGU GROUP SHPK-Rruga C	\N
1316	3173	1	TRIOSS GROUP SHPK-Mondo Prizeren	\N
1317	3185	1	TROPIKAL 1 NPT-DEÇAN	\N
1318	3185	2	TROPIKAL 2  NPT - Isniq	\N
1319	3185	3	TROPIKAL DEPO - DEÇAN	\N
1320	3205	2	UNION TRADITA U T SH.P.K.-2-Preoc	\N
1321	3209	1	UNIVERSI PN SH.P.K.(Kfor)- PRISHTINË	\N
1322	3249	1	VALONI PETROL  SHPK-Prishtine	\N
1323	3249	2	VALONI PETROL 1  SHPK-Prishtine	\N
1324	3252	1	VAMP COSMETICS SH.P.K.-Gjakove	\N
1326	3260	12	Veda -2-Petroll SH.P.K.- Ferizaj Sojeve	\N
1327	3260	4	Veda -2-Petroll SH.P.K.- Malishev Kijev	\N
1328	3260	20	Veda -2-Petroll SH.P.K.- Rr.Fusha e Peje	\N
1329	3260	21	Veda -2-Petroll SH.P.K.- Sllatine	\N
1330	3260	18	Veda -2-Petroll SH.P.K.- Stankovc Drenas	\N
1331	3260	2	Veda -2-Petroll SH.P.K.-Mitrovice	\N
1332	3276	1	Verona Tullari B.I.(FSH Troi)-Prishtinë	\N
1333	3294	1	VIPROS SH.P.K. - Prishtine	\N
1334	3294	2	VIPROS SH.P.K.-Bregu i Diellit-Prishtine	\N
1335	3294	3	VIPROS SH.P.K.-Njesia 3 Lagja Spitalit	\N
1336	3294	4	VIPROS SH.P.K.-Njesia 4 Mati 1	\N
1337	3294	5	VIPROS SH.P.K.-Njesia 5	\N
1338	3294	6	VIPROS SH.P.K.-Njesia 6 Shaqir Igrishta	\N
1339	3303	120	VIVA FRESH SHPK 100- Drenas	\N
1340	3303	98	VIVA FRESH SHPK 101-Obranqë	\N
1341	3303	99	VIVA FRESH SHPK 102-Rogane	\N
1342	3303	102	VIVA FRESH SHPK 103-Ferizaj	\N
1343	3303	104	VIVA FRESH SHPK 104-Sopi SUHAREKE	\N
1344	3303	103	VIVA FRESH SHPK 105-Dragash	\N
1345	3303	105	VIVA FRESH SHPK 106-Kllokot	\N
1347	3303	107	VIVA FRESH SHPK 108-Zhur	\N
1348	3303	109	VIVA FRESH SHPK 109-Ferizaj	\N
1349	3303	108	VIVA FRESH SHPK 110-Gjilan	\N
1350	3303	111	VIVA FRESH SHPK 111-Magure Lipjan	\N
1351	3303	110	VIVA FRESH SHPK 112-Hajvali	\N
1352	3303	112	VIVA FRESH SHPK 113-Prishtine	\N
1353	3303	113	VIVA FRESH SHPK 114-Prishtine	\N
1354	3303	114	VIVA FRESH SHPK 115-Gjakove	\N
1355	3303	115	VIVA FRESH SHPK 116-Noveberd	\N
1356	3303	116	VIVA FRESH SHPK 117-Davidofc	\N
1357	3303	117	VIVA FRESH SHPK 118-Koshare	\N
1358	3303	119	VIVA FRESH SHPK 119 - Gadime e poshtme	\N
1359	3303	118	VIVA FRESH SHPK 120-Prizren	\N
1360	3303	121	VIVA FRESH SHPK 121-Xërxë	\N
1361	3303	122	VIVA FRESH SHPK 122-Millosheve	\N
1362	3303	124	VIVA FRESH SHPK 123-Gjilan	\N
1363	3303	123	VIVA FRESH SHPK 124-Gjilan	\N
1364	3303	15	VIVA FRESH SHPK 14 - LYPJAN	\N
1366	3303	17	VIVA FRESH SHPK 16- GJAKOVE	\N
1367	3303	18	VIVA FRESH SHPK 17 - PEJE	\N
1368	3303	19	VIVA FRESH SHPK 18- PRISHTINE	\N
1369	3303	20	VIVA FRESH SHPK 19 - PRISHTINE	\N
1370	3303	3	VIVA FRESH SHPK 1-Ferizaj	\N
1371	3303	21	VIVA FRESH SHPK 20 - MALISHEVE	\N
1372	3303	22	VIVA FRESH SHPK 21 - VUSHTRRI	\N
1373	3303	23	VIVA FRESH SHPK 22 -  Prishtinë	\N
1374	3303	24	VIVA FRESH SHPK 23 - Fushe Kosove	\N
1375	3303	81	VIVA FRESH SHPK 24- Gjilan	\N
1376	3303	28	VIVA FRESH SHPK 25- Prishtine	\N
1266	3005	20	SUPER VIVA SHPK 17-Ferizaj B	\N
1268	3005	25	SUPER VIVA SHPK- 19 C Ferizaj	\N
1269	3005	1	SUPER VIVA SHPK- 2 - F.Kosove Sh.P.K	\N
1270	3005	24	SUPER VIVA SHPK 20-Therande	\N
1271	3005	7	SUPER VIVA SHPK- 4- BIG BROTHER- Pz	\N
1272	3005	6	SUPER VIVA SHPK- 5 - te Fatoni- Prizren	\N
1273	3005	5	SUPER VIVA SHPK- 6 - Rahovec	\N
1274	3005	8	SUPER VIVA SHPK- 8- Germi	\N
1275	3005	17	SUPER VIVA SHPK 9 - F.Kosove te Rrethi	\N
1276	3005	2	SUPER VIVA SHPK-1 - Lypjan Sh.P.K	\N
1277	3005	11	SUPER VIVA SHPK-11- L.Spitalit-Prishtine	\N
1278	3005	4	SUPER VIVA SHPK-7 - Xerxe-Prizren Sh.P.K	\N
1279	3005	46	SUPER VIVA-Administrate	\N
1280	3009	2	SUSHICO KOSOVA 2 SHPK-Prishtinë	\N
1281	3009	1	SUSHICO KOSOVA SHPK-Prishtinë	\N
1282	3031	1	TAHIRSYLAJ OIL SHPK-Peje	\N
1283	3031	2	T-EXPRESS MARKET SHPK-Peje	\N
1284	3058	3	TDM GLOBAL L.L.C.-Peje	\N
1285	3069	1	N.T.SH TE DERGUTI 1 -Studenqan -Therande	\N
1286	3069	2	N.T.SH TE DERGUTI 2-Studenqan- Therande	\N
1287	3082	2	TE NONA SH.P.K. 2-Pejë	\N
1288	3082	1	TE NONA SH.P.K.-Pejë	\N
1289	3088	1	TE RONI - Gjakove Sh.P.K	\N
1290	3088	2	TE RONI 2- GJAKOVE	\N
1291	3088	3	TE RONI 3 - GJAKOVE	\N
1293	3101	2	Terra Eatery SH.P.K. Njesia 2	\N
1294	3123	1	TINA 1 - Gjilan	\N
1295	3123	2	TINA MARKET NT- Gjilan	\N
1296	3145	1	TONI MARKET SHPK - Kolovice - Prishtine	\N
1297	3145	2	TONI MARKET SHPK 2- Prishtine	\N
1410	3303	71	VIVA FRESH SHPK 74 - Prishtine	\N
1411	3303	84	VIVA FRESH SHPK 75- Suhareke	\N
1412	3303	73	VIVA FRESH SHPK 76 - Prishtine	\N
1413	3303	75	VIVA FRESH SHPK 77 - Gjakove	\N
1414	3303	76	VIVA FRESH SHPK 78 - Prizeren	\N
1415	3303	78	VIVA FRESH SHPK 79- Kline	\N
1416	3303	5	VIVA FRESH SHPK 7-Prizeren	\N
1417	3303	77	VIVA FRESH SHPK 80 - Prishtine	\N
1418	3303	79	VIVA FRESH SHPK 81- Ratkoc	\N
1419	3303	80	VIVA FRESH SHPK 82-  Kamenice	\N
1420	3303	82	VIVA FRESH SHPK 83- Peja	\N
1422	3303	85	VIVA FRESH SHPK 85-Prishtine	\N
1423	3303	86	VIVA FRESH SHPK 86-Prishtine	\N
1424	3303	87	VIVA FRESH SHPK 87-Mitrovice	\N
1425	3303	89	VIVA FRESH SHPK 88-Ferizaj	\N
1426	3303	88	VIVA FRESH SHPK 89-Vitomericë	\N
1427	3303	9	VIVA FRESH SHPK 8-Mitrovice	\N
1428	3303	90	VIVA FRESH SHPK 90-Opoje	\N
1429	3303	91	VIVA FRESH SHPK 91-Krushë	\N
1430	3303	92	VIVA FRESH SHPK 92-Lluzhan	\N
1431	3303	93	VIVA FRESH SHPK 93-Viti III	\N
1432	3303	94	VIVA FRESH SHPK 94-Prizeren	\N
1433	3303	95	VIVA FRESH SHPK 95-Podujeve	\N
1434	3303	96	VIVA FRESH SHPK 96-Gjilan	\N
1435	3303	100	VIVA FRESH SHPK 97-Shiroke	\N
1436	3303	97	VIVA FRESH SHPK 98-Prishtine	\N
1437	3303	101	VIVA FRESH SHPK 99-Istog	\N
1438	3303	10	VIVA FRESH SHPK 9-Prishtine	\N
1439	3303	1	VIVA FRESH SHPK LOGISTIC	\N
1440	3303	40	VIVA FRESH SHPK-42 Deqan	\N
1442	3303	42	VIVA FRESH SHPK-44 Prishtine	\N
1443	3303	43	VIVA FRESH SHPK-45 Bardhosh	\N
1444	3303	44	VIVA FRESH SHPK-46-Prishtine	\N
1445	3303	45	VIVA FRESH SHPK-47-Prishtine	\N
1446	3303	47	VIVA FRESH SHPK-49 - Prishtine	\N
1447	3303	48	VIVA FRESH SHPK-50 -Prishtine	\N
1448	3303	51	VIVA FRESH SHPK-51- Obiliq	\N
1450	3303	49	VIVA FRESH SHPK-53 -Prishtine	\N
1451	3303	52	VIVA FRESH SHPK-56- Korishe Prizeren	\N
1452	3303	58	VIVA FRESH SHPK59-Prishtine	\N
1453	3303	59	VIVA FRESH SHPK60-Prishtine	\N
1454	3303	60	VIVA FRESH SHPK61-Hani Elezit	\N
1455	3303	61	VIVA FRESH SHPK62-Skenderaj	\N
1457	3303	12	VIVA FRESH STORE SHPK 11-Shtime	\N
1458	3303	13	VIVA FRESH STORE SHPK 12-Viti	\N
1459	3303	14	VIVA FRESH STORE SHPK 13-Kamenice	\N
1460	3310	1	VLL. MJEKU NTP - Kastriot- Obiliq	\N
1461	3310	3	VLL. MJEKU NTP 4 - Plemetin	\N
1462	3310	2	VLL. MJEKU NTP 4 - Qender Kastriot	\N
1463	3328	5	WALKER S - Prizeren	\N
1464	3333	2	Wonder Store SH.P.K.1 -Prishtinë	\N
1465	3333	1	Wonder Store SH.P.K.-Prishtinë	\N
1466	3339	1	XENI COMMERCE - Xerxe- Rahovec Sh.P.K	\N
1467	3339	2	XENI COMMERCE 2 - Xerxe- Rahovec Sh.P.K	\N
1468	3342	2	XHELA Market SHPK- 2Fushe Kosove	\N
1469	3342	3	XHELA Market SHPK-3 Fushe Kosove	\N
1470	3342	1	XHELA Market SHPK-Fushe Kosove	\N
1471	3349	3	Y & Y Cosmetics - Fushe Kosove	\N
1472	3349	4	Y & Y Cosmetics - Gjilan	\N
1473	3349	7	Y & Y Cosmetics - Grande Mall	\N
1474	3349	6	Y & Y Cosmetics - Lux Mall	\N
1476	3349	2	Y & Y Cosmetics - Te lesna Prishtinë	\N
1477	3349	1	Y & Y Cosmetics - Te qafa Prishtinë	\N
1478	3373	1	ZEM ZEM N.T. 1- Junik	\N
1479	3373	2	ZEM ZEM N.T. 2- Junik	\N
1480	3385	3	Zymer Miftari B.I.-VEDA 3- Stankovc	\N
1482	3385	1	Zymer Miftari B.I.-VEDA 3-Shupkovc Mitro	\N
32	232	16	Al Petrol SHPK-Ferizaj 2	\N
1481	3385	4	Zymer Miftari B.I.-VEDA 3-Shupkovc Mitro	\N
49	232	43	Al Petrol SHPK-Malisheva 2	\N
66	232	4	Al Petrol SHPK-Prizeren 1	\N
98	256	30	ALBI  MARKET 20 SHPK-Prishtine	\N
117	256	49	ALBI  MARKET 39-SHPK-Kastriot	\N
83	232	39	Al Petrol SHPK-Vushtrri 2	\N
118	256	50	ALBI  MARKET 40-SHPK-Kline	\N
120	256	60	ALBI  MARKET 49-SHPK-Dragodan	\N
1378	3303	30	VIVA FRESH SHPK 27- Prishtine	\N
1380	3303	32	VIVA FRESH SHPK 29- Fushe Kosove	\N
1379	3303	31	VIVA FRESH SHPK 28-Prizeren	\N
1381	3303	4	VIVA FRESH SHPK 2-Gjilan	\N
1384	3303	26	VIVA FRESH SHPK 35 -Prishtine	\N
1383	3303	25	VIVA FRESH SHPK 34 - Prishtine	\N
1385	3303	34	VIVA FRESH SHPK 36-Prishtine	\N
1386	3303	35	VIVA FRESH SHPK 37-Ferizaj	\N
1387	3303	37	VIVA FRESH SHPK 38-Ferizaj	\N
1389	3303	8	VIVA FRESH SHPK 3-Ferizaj	\N
1388	3303	36	VIVA FRESH SHPK 39-Ferizaj	\N
1390	3303	38	VIVA FRESH SHPK 40-Kaqanik	\N
1391	3303	39	VIVA FRESH SHPK 41-Rahovec	\N
1393	3303	2	VIVA FRESH SHPK 5 -Prishtine	\N
1392	3303	7	VIVA FRESH SHPK 4-Prishtine	\N
1394	3303	55	VIVA FRESH SHPK 54-Istog	\N
1396	3303	56	VIVA FRESH SHPK 57-Prishtine	\N
1397	3303	57	VIVA FRESH SHPK 58-Pozhoran	\N
1398	3303	62	VIVA FRESH SHPK 63-Prishtine	\N
1395	3303	53	VIVA FRESH SHPK 55-Gjakove	\N
1399	3303	63	VIVA FRESH SHPK 64 - Prizren	\N
1400	3303	64	VIVA FRESH SHPK 65 - PRISHTINE	\N
1402	3303	66	VIVA FRESH SHPK 67 - Prizeren	\N
1403	3303	67	VIVA FRESH SHPK 68 - Prishtine	\N
1404	3303	68	VIVA FRESH SHPK 69 - Prishtine	\N
1405	3303	6	VIVA FRESH SHPK 6-Gjilan	\N
1406	3303	69	VIVA FRESH SHPK 70 - Vushtrri	\N
1407	3303	70	VIVA FRESH SHPK 71 - Prishtine	\N
1408	3303	74	VIVA FRESH SHPK 72 - Mamushe	\N
1409	3303	72	VIVA FRESH SHPK 73 - Komoran	\N
821	1798	6	Kipper 6- Greme	\N
836	1878	8	LAB-OIL Restaurant-Hajvali	\N
10793	1201	13	ETC  - Ferizaj Sh.P.K	\N
10794	1201	12	ETC  - Peje Sh.P.K	\N
851	1902	1	LEAR MARKET SH.P.K.-Gjilan	\N
866	1932	4	LIDER MARKET SH.P.K 4.-Skenderaj	\N
889	2017	1	LULI SHPK PRISHTINE	\N
900	2086	1	MANI 2 - Te stac.policor Malisheve NTP	\N
923	2181	4	MATISSE - Sheshi Zahir Pajaziti	\N
930	2225	66	Merdian Express SHPK PZ  Haxhi Zeka 21	\N
934	2225	9	MERIDIAN EXPRES 009-Rr.Germise-Prishtine	\N
953	2225	17	MERIDIAN EXPRESS 018-L.SHKRELI-Mitrovice	\N
975	2225	28	MERIDIAN EXPRESS- PEJTON-PRISHTINE	\N
993	2231	3	Mess market Sh.p.k.-Ferizaj -Objekti 3	\N
1018	2409	1	NERTILI - Gjakove Sh.P.K	\N
1032	2456	25	NORWEGIAN PX  MAXI E-Lagje Muhaxhere	\N
1038	2456	15	NORWEGIAN PX 13-Te Qafa Prishtine	\N
1042	2456	18	NORWEGIAN PX 16-Prishtine Lagja Nic	\N
1059	2491	2	OKI'S CANDY CORNER SHPK-Galeria Shoppin	\N
1083	2600	27	PETROL COMPANY SHPK - Mbrapa ETC - Prish	\N
1101	2600	3	PETROL COMPANY SHPK- DRAGODAN - PRISHTIN	\N
1127	2669	2	PRIME MARKET SH.P.K. 2	\N
1142	2683	38	Proex Prishtinë 35- Prishtina Mall	\N
1151	2683	1	Proex Sh.p.k 17-Gjilan	\N
1156	2683	25	Proex Sh.p.k 21-Gjilan 2	\N
1173	2683	45	Proex SH.P.K.  43 Ish QTX Xerxe	\N
1192	2825	1	Merket Solutions SH.p.k	\N
1207	2902	1	SHERIF SH.P.K.-Llazareve Kastriot	\N
1247	3005	48	POMO Restaurant 21-Lagjia e Spitalit-PR	\N
1264	3005	19	SUPER VIVA SHPK 15- Ortakoll - Prizren	\N
1265	3005	16	SUPER VIVA SHPK 16 - Ferizaj	\N
1267	3005	21	SUPER VIVA SHPK 18-Grand Store Prishtine	\N
1292	3101	1	Terra Eatery SH.P.K. Njesia 1	\N
1308	3162	6	TREGU GROUP SHPK-Bregu i Diellit	\N
1325	3252	2	VAMP COSMETICS SH.P.K.-Prishtinë	\N
1346	3303	106	VIVA FRESH SHPK 107-Llapnaselle	\N
1365	3303	16	VIVA FRESH SHPK 15 - THERANDE	\N
1377	3303	29	VIVA FRESH SHPK 26- Prishtine	\N
1382	3303	33	VIVA FRESH SHPK 30- Prishtine	\N
1421	3303	83	VIVA FRESH SHPK 84- Prishtine	\N
1441	3303	41	VIVA FRESH SHPK-43 Podujeve	\N
1449	3303	50	VIVA FRESH SHPK-52 -Landovice Prizeren	\N
1456	3303	11	VIVA FRESH STORE SHPK 10 -Gjilan	\N
1475	3349	5	Y & Y Cosmetics - Prishtina Mall	\N
121	256	52	ALBI  MARKET 8-SHPK-Prishtine	\N
140	256	59	ALBI MARKET 48-SHPK Marigona Hill	\N
157	305	2	AMPM 24 H MARKET SH.P.K.- Sheshi Ferizaj	\N
180	385	2	AROMA SHPK 2-Prishtine	\N
193	474	3	Ballkan Petrol 3 SH.P.K - Prelez Ferizaj	\N
218	510	1	DIELLI SUPERMARKET NTP- Mitrovice	\N
233	553	3	BENI DONA- Zona industriale Pr -F Kosove	\N
249	604	1	Besniku Cake & Coffe Shop SHPK-Prizeren	\N
272	701	2	BOTTEGA MARKET SH.P.K.-2-Gjilan	\N
291	797	1	CHE BAR BISTRO SHPK -Prishtine	\N
311	942	14	DHF COMPANY SHPK , Malisheve	\N
328	964	1	DINI SHPK-Pograxhe - Gjilan	\N
341	1045	12	Durmart L.L.C.- 11 Mitrovice Rr.Xh.Isufi	\N
346	1045	6	Durmart L.L.C.- 5  Mitrovicë	\N
349	1045	9	Durmart L.L.C.- 8 Prishtine	\N
364	1067	7	EBC Company SHPK-07 Royal Mall	\N
385	1121	4	ELI AB SHPK - PRISHTINE	\N
402	1143	5	EMONA CENTER SHPK - Bregu i Diellit - Pr	\N
420	1157	2	ENDRITI BUS SH.P.K.-2-YOur charm cosmet.	\N
10786	1201	29	ELKOS DEPO - Ferizaje Sh.P.K	\N
10787	1201	31	ELKOS DEPO - Gjilane Sh.P.K	\N
10788	1201	32	ELKOS DEPO - Mitrovice Sh.P.K	\N
10789	1201	33	ELKOS DEPO - Peje Sh.P.K	\N
10790	1201	34	ELKOS DEPO - Prishtine Sh.P.K	\N
10791	1201	35	ELKOS DEPO - Prizren Sh.P.K	\N
10792	1201	37	ELKOS DEPO Logjistika- Peje Sh.P.K	\N
10795	1201	14	ETC  - Prishtine Sh.P.K	\N
10796	1201	1	ETC - Besiane Sh.P.K	\N
10797	1201	2	ETC - Burim Sh.P.K	\N
464	1207	3	EURO FOOD- 50 - Prizren	\N
468	1207	7	EURO FOOD 54 - Prizren	\N
485	1207	19	EUROFOOD 71-Gjakove 2	\N
486	1214	2	Euro Max Plus SH.P.K.-Prishtine	\N
500	1233	24	EX FIS SHPK - Ferizaj 2 ( Rr. Reqaku )	\N
522	1233	8	EX FIS SHPK - Shakovice Podujeve	\N
539	1237	4	Express Store 1 SH.P.K.-Emshir Prishtine	\N
561	1248	2	FABS INTERNATIONAL L.L.C.  Njesia 2	\N
579	1339	1	FLEX GYM SH.P.K.-Prishtinë	\N
588	1393	3	FRESH MARKET 2 SH.P.K.3-PEJE	\N
604	1413	7	FRUTARIA SHPK-Mati 1 Prishtine 5	\N
624	1522	3	GNTC Group  SH A -Prizeren	\N
1225	2965	10	SPAR KOSOVA J.S.C .-Prishtine	\N
1401	3303	65	VIVA FRESH SHPK 66 - PRISHTINE	\N
640	1522	20	GNTC Group SH A -Magure(Lipjan te ETC)	\N
659	1563	2	GRESA LOUNGE RESTAURANT  SHPK - Njesi 2	\N
679	1622	7	HIB Petrol Corporation SH.P.K.-Podujeve	\N
695	1623	20	HIB PETROL 2-Prizeren	\N
704	1624	23	HIB Restaurantet SH.P.K.-Fabrika	\N
718	1633	13	HOFFMAN Stores SH.P.K. 13-Sheshi I.R.-Pr	\N
719	1633	15	HOFFMAN Stores SH.P.K. 14-Fushe Kosove	\N
742	1694	33	IP KOS PETROL SHPK - Dragodan	\N
759	1694	11	IP KOS PETROL SHPK - Zahaq, Peje	\N
776	1694	21	IP KOS PETROL SHPK-Te Parku Prishtine	\N
803	1798	23	Kipper 23-Prizren	\N
811	1798	32	Kipper 32-Mitrovice	\N
10812	1201	39	ETC -Kaqanik	\N
10813	1201	15	ETC -Mitrovice	\N
10814	1201	42	ETC SHPK-Elez Han	\N
10815	1201	44	ETC SHPK-Komoran	\N
10816	1201	43	ETC SHPK-Skenderaj	\N
10817	1201	16	ETC-Graqanice	\N
10818	1201	38	Express Store -6(e market)	\N
10819	1201	40	Express Store 7 Peje	\N
10820	1201	28	Express Store -Istog	\N
10821	1201	24	Express Store -Te ura e Gurit Peje	\N
10822	1201	25	Express Store-4(ish maxi)	\N
564	1275	3	FATI-G N.T 3 .-Peje	\N
568	1292	3	Femis Cosmetics Sh.P.K Prishtinë	\N
569	1292	5	Femis Cosmetics Sh.P.K Suhareke	\N
570	1292	1	FEMIS COSMETICS SH.P.K.-Fushë Kosovë	\N
10798	1201	3	ETC - Gjakove Sh.P.K	\N
10799	1201	4	ETC - Gjilan Sh.P.K	\N
10800	1201	18	ETC - Junik	\N
10801	1201	5	ETC - Kamenic Sh.P.K	\N
10802	1201	6	ETC - Kline Sh.P.K	\N
10803	1201	7	ETC - Lypjan Sh.P.K	\N
10804	1201	8	ETC - Prizren Sh.P.K	\N
10805	1201	9	ETC - Rahovec Sh.P.K	\N
10806	1201	21	ETC - Therande	\N
10807	1201	10	ETC - Viti Sh.P.K	\N
10808	1201	20	ETC - Vranjevc - Prishtine	\N
10809	1201	11	ETC - Vushtrri Sh.P.K	\N
10810	1201	19	ETC 2 - Peje	\N
10811	1201	17	ETC 2 -Gjilan	\N
\.


--
-- Data for Name: buyers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buyers (id, code, name, pb_sifra_kup) FROM stdin;
33	001649	**BENI IMPEX - Smire- Viti	\N
34	005470	**BEREQETI DPT - MALISHEVE	\N
35	001665	**BERISHA PETROL NTP - Ferizaj	\N
36	001703	**BESNIKU - Kovrag - Burim	\N
37	001726	**BINGO - Prizren	\N
38	001738	**BLENDA 2 - Gjilane	\N
39	001820	**BUTRINTI - Drenas	\N
41	001822	**BUTRINTI SHPK - Cagllavice	\N
48	003555	**DURIMI DPT - HAJVALI	\N
49	004513	**DUSHI DPT - PRISHTINE	\N
50	006722	**EGZOLINDA 2 - Prishtine	\N
51	002097	**EGZONITA - Besiane Sh.P.K	\N
52	003508	**EJA NTP - HAJVALI - PRISHTINE	\N
53	002120	**ELI AB SHPK - Prishtine	\N
55	005306	**ENDRITI G.F. NTP - VITI	\N
56	002281	**FESI DEPO - Mitrovice	\N
57	005347	**FRESH MARKET NPT - DARDANE	\N
58	002355	**FRUCTAL - Ferizaj	\N
115	002367	**FTONI NTP - Peje	\N
116	000877	**G ARBERI NTP - Peje	\N
117	005047	**GETI - NOVOSELL -  GJILAN	\N
118	002420	**GETI SHPK - Gjilan	\N
119	006113	**Green Salad Shpk - Prishtine	\N
120	000916	**HOLLYWOOD - Gjilan	\N
121	000963	**INTER DISKONT Sh.P.K- Koretin-Kamenic	\N
122	001043	**KASTRATI Petrol SHPK - Peje	\N
123	005771	**L & D NTP - TRANZIT - PRIZREN	\N
124	001139	**LANDI - Rahovec	\N
125	001197	**LINDI - Therande	\N
126	004065	**LINDI PHARM - LYPJAN	\N
127	001227	**LIRIDONI  Z  - Deqan	\N
128	001228	**LIRIDONI DPT - Rahovec	\N
130	005191	**MOZART SHPK - PRISHTINE	\N
131	000132	**NTP TE GEZIMI - Skenderaj	\N
132	000167	**ORHAN MARKET - Prizren	\N
133	002548	**P.P Popovic- Shterpce	\N
134	000249	**PRIZMA 2 - Plemetin- Obiliq	\N
135	009774	**QENDRESA Barnatore Shpk-Obiliq	\N
136	000274	**RE HA-Prizren	\N
137	000347	**RINA MARKET NTP - Zallc- Istog	\N
138	000363	**RITA -  NTP Gjilan	\N
139	003583	**SHENDETI  - LYPJAN	\N
140	008891	**SUNNY HILL D.P.H	\N
141	000506	**TASIMI D.P.T.-Vushtrri	\N
142	000568	**TINA 2 Sh.P.K- Gjilan	\N
143	000590	**TONI MARKET- Mitrovice	\N
144	005724	**TROFTA SHPK - ISTOG	\N
145	000665	**VALBONA DPT - Velani - Prishtine	\N
146	000669	**VALDRINI Sh.P.K  - Peje	\N
147	005782	**VALONI MARKET DPT - OBILIQ	\N
149	008179	**VISI - Kolovice - Prishtine	\N
150	000815	**ZEM ZEM Sh.P.K- Junik- Deqan	\N
151	001886	*DADINI SHPK- Kaqanik	\N
152	001106	*KRONI COMMERC  2  - Drenas Sh.P.K	\N
153	002630	*MINATORI DPT- Matiqan - Prishtine	\N
154	000726	*VILLA PARK - Specke - Prizren	\N
155	008352	€URO MARKET NTP-Ferizaj	\N
156	126245	01 PIZZA SH.P.K.	\N
157	007450	1 MAJI - X NTP-Gjilan	\N
158	126362	1 MAJII SH.P.K.	\N
159	012978	124 Group SH.P.K.-Prishtinë	\N
160	009886	2 BB SHPK-Obiliq	\N
161	126299	24 MARKET  SH.P.K.	\N
162	013641	3DMARKET SH.P.K.-Fushë Kosovë	\N
163	013100	4VD SH.P.K.-Prizren	\N
164	013043	53 BAR SH.P.K.(KU ZINE)-Gjakovë	\N
165	003654	7 VELLEZERITSHPK-KOSHARE	\N
167	010181	A & D BRANDS-Mitrovicë(A.Karakashi)	\N
168	012459	A L D COMERCE SH.P.K.	\N
169	009170	A&B SH.P.K.-Ferizaj	\N
170	008417	A2 Market SH.P.K. - Prishtine	\N
171	126111	AB01 Market SH.P.K.	\N
289	011203	AMAZONA SH.P.K.-Prishtinë	\N
3	000052	***NATYRA 2  NTP - Shtime	\N
4	022096	**BELTI DPT - Matiqan	\N
5	995548	**BISERI DPT - GJAKOVE	\N
6	005550	**DUKAGJINI HOTEL SHPK - Peje	\N
7	001041	**KASTRATI MARKET - Prizren Sh.P.K	\N
8	002756	**LABI DPT - F.Kosove	\N
9	003579	**LABI DPT - LYPJAN	\N
10	005070	**MALI DPT - SHTIME	\N
11	000129	**MARKET FRESHI 2 N.T- Peje	\N
12	002542	**MARSI - Prishtine	\N
13	002566	**MEDITERAN  NTP - Viti	\N
14	002030	**N.P.T. " Drita "	\N
15	001253	*ABI MARKET - Prizren	\N
16	005155	*GRESA -V MARKET - PEJE	\N
17	000311	*  *RESTORANT FRESKIA  - Prishtine	\N
18	004205	**MARKET DIMI-PRIZREN	\N
19	006453	**NAIMI -SHM -RAUSHIQ - Peje	\N
20	010040	DPT Learti B.I.-Zahaq, ,	\N
21	009478	EKO BRIKET - MOLIKA N.P.T(panorama )	\N
22	008284	V.MUSLIJA-PETROL - Gjakove	\N
23	007578	"BP BALA-PETROL"	\N
24	009224	(Ch.Express)Aferdita Morina B.I.Prizeren	\N
25	005625	***CHE BAR LOUNGE SH.P.K.	\N
26	006984	**ABI MARKET DT-Malishevë	\N
27	001261	**ADA  COMMERCE - Prizren	\N
28	004877	**ALBERTI MARKET NTP - BELINCË - SHTIME	\N
29	002697	**ALFA L - Hajvali	\N
30	001491	**ARMENDI COM - Ferizaj	\N
31	005232	**AS COM  NTP - Drenas	\N
32	005564	**BANANA S.H - NTSH - Istog	\N
54	002156	**ENDI DISKONT - Drenas	\N
206	002981	AGNESA MARKET SHPK -Besiane	\N
207	011336	Agnesa Thaqi Kurejshi B.I.-Prizren	\N
203	001295	AGIMI NTP - Gllamnik-Besiane	\N
209	013779	AgorA Food & Coffe SH.P.K.-Prishtinë	\N
210	125788	Agora Food & Drinks Gjilan SH.P.K.	\N
211	007127	AGORA PIZZERIA NPH-Fushe Kosove	\N
212	125809	Agrigento SH.P.K.	\N
208	001301	AGONI DPT - Bresane - Opoje	\N
215	001310	AGRO MARKET NTP - Rahovec	\N
213	001303	AGRO BESI - Velekinc-Gjilan	\N
217	001312	AGRO PERANI (D.Emini)- Besiane	\N
216	005525	AGRO MARKET NTP - SADOVINË	\N
218	003426	AGRONI DPT - GJAKOVE	\N
219	001317	AGRONI DPT - Gjilan	\N
220	001315	AGRONI DPT - Godanc -Shtime	\N
221	001316	AGRONI DPT - Prizren	\N
222	004707	AGRONI DPT -GJAKOVE	\N
223	001319	AGROS - Prelluzh- Kastriot	\N
224	006428	AGRO-TONI NTP - Podujeve	\N
225	126316	Agroturizëm Foleja e Zanave SH.P.K.	\N
226	126035	Agroturizëm Rrush e Verë	\N
227	009971	Agrounion - Barileva K.B.-Prishtinë	\N
228	001320	AGRUM - Millosheve -Kastriot	\N
229	125806	Air Group SH.P.K.	\N
230	013003	Ajet Kelmendi B.I.(DONI FE)-Pejë	\N
231	007049	AKTIV  SHPK-Drenas	\N
232	003029	AL PETROL SHPK(SHELL)-Fushe Kosove	\N
233	001332	ALB ARI - Ulpiane - Prishtine	\N
234	126409	Alb Capital Sh.p.k.-Premium Bakery	\N
235	009881	ALBA & ALBA SHPK-Podujeve	\N
237	001338	ALBA PHARM - Bresana - Prizren	\N
238	125728	Alban Gavazaj B.I.-Prizren	\N
239	126090	Alban Karaliti B.I.	\N
240	001342	ALBANA  MARKET - Sllatine - F.Kosove	\N
241	001345	ALBANA DPT - Prishtine	\N
242	001344	ALBANA MARKET NTP- Ferizaj	\N
243	011058	Albani B a u Market SH.P.K.	\N
244	006522	ALBANI NTP - Banull- Lipjan	\N
245	125832	Albans Food and Drinks SH.P.K.	\N
246	010607	Albapetrol Group SH.P.K.-Viti	\N
247	001352	ALBATRINTI DEPO NTP- Shtime	\N
248	013826	Albert Ga. Gashi B.I.-Magj.Prishtine-Pej	\N
249	006867	Alberti Market-Brelnic -SHTIME	\N
250	005413	ALBI - A DPT - Atmaxhe - Prizren	\N
251	001355	ALBI - Dardane	\N
252	001358	ALBI - Prelez Ferizaj	\N
253	001366	ALBI H - Hereq- Gjakove	\N
255	001368	ALBI MARKET - Mirash- Ferizaj	\N
256	000003	ALBI SHOPING SHPK	\N
257	126456	Albin Gigollaj B.I.	\N
258	001369	ALBINI - Kline	\N
259	001372	ALDI  DEPO(S.Dervishi) - Baba i Bokes	\N
260	006373	ALDI - EDONA DPT-Endrit Ramadani B.I.	\N
261	004772	ALE NTP - RAHOVEC	\N
262	010251	ALEA Supermarket SHPK-Lipjan	\N
263	009970	ALFA GLOBE SHPK-Prishtine	\N
264	001377	ALFA MARKET - Br.Diellit- Prishtine	\N
265	003277	ALFA MARKET- Ulpiane-Prishtine	\N
266	001378	ALFA PLUS NT - Prishtine	\N
267	009178	ALFA PLUS SHPK-Prishtine	\N
268	126503	Alfa Shpk	\N
269	003550	ALFA-L DPT - HAJVALI - PRISHTINE	\N
270	013674	Alfa-Product SH.P.K.-Prishtinë	\N
271	126478	ALI BABA SH.P.K.	\N
272	007375	ALIA SHPK-Bresalc Gjilan	\N
273	001381	ALISA PROM SHPK-Nebregoshte Prizren	\N
274	005667	ALIU MARKET D.P.T - DRENAS	\N
276	008944	ALOE VERA SHPK Rogoqice	\N
277	005759	ALORA PHARM - KAMENICE	\N
278	005963	ALPEG SHPK - DRAGODAN-PRISHTINE	\N
279	001392	ALPINA - Miresh - Gjilan	\N
280	004147	ALTEX SHPK - MAGURE	\N
281	001394	ALTHAEA BARNAT - Malisheve	\N
282	001397	ALTINI DPT - Prishtine	\N
283	009261	AM KETI NTP-(Relax cafe)Ferizaj	\N
284	125987	AMAR MARKET SH.P.K.	\N
285	125706	Amarket Store SH.P.K.-Prizren	\N
286	126339	AMA'S CAFFE	\N
287	126072	AMAZON FRUITS SH.P.K.	\N
288	008454	AMAZONA HOTEL  SH.P.K.	\N
173	008218	ABB 2 SHPK - Kastriot	\N
174	008258	ABEA-A  SH.P.K. - Gjilan	\N
175	006644	ABI - MARKET  Malisheve - Gjilan	\N
176	125838	Abi Market Sh.G	\N
177	000126	ABI N.T.H. - Vushtrri	\N
178	001251	ABI SHPK - Prizren	\N
180	004037	ADA COMERCE T.P. Afija Sagdati B.I.- REQ	\N
181	013400	Ada Pharm SH.P.K.-Kaçanik	\N
182	001269	ADI MARKET - Besiane	\N
183	001270	ADI MARKET NTP - Prishtine	\N
184	012731	ADRIANA MARKET SH.P.K.-Prishtinë	\N
186	009265	ADRIATIKU DPT-Gjilan	\N
187	001284	AEGU - Prishtine	\N
185	012732	ADRIANA MARKET SH.P.K.-Prishtinë	\N
189	004904	AFB DPT- ROGOVË	\N
190	126174	Aferdita Kroni B.I.-Suharekë	\N
188	013381	AF Market SH.P.K.-Prishtinë	\N
192	008025	AFRIM BYTYQI B.I.-Prishtinë	\N
191	007995	AFRIM BERISH B.I.(Market Rrezi)-Drenas	\N
194	001286	AFRIMI DPT - Korenicë - Gjakove	\N
193	126296	Afrim L. Osmani I.B.-GRAÇANICË	\N
196	125986	AG ECO MARKET	\N
198	007892	AGA COM NTSH	\N
200	126304	Agbar-C-A N.Sh	\N
195	012994	AG Depo SH.P.K.-Peje	\N
201	007000	AGED D.P.T - VUSHTRRI	\N
202	125761	Agim Al. Morina B.I.-S.Market-Kamenicë	\N
204	001298	AGMIA CENTER - Gjilan	\N
205	000002	AGNESA DEPO - Besiane	\N
333	010015	APOLLONIA 1991 1 SHPK-Brezovice	\N
334	004689	APOLONIA RESTAURANT 1991 SHPK - FERIZAJ	\N
335	010507	Aqua Park Lin Projekt SH.P.K.-Mitrovicë	\N
336	126410	AR7DRENI SH.P.K.-Prishtine	\N
337	002957	ARAL PETROL N.T - SHTIME	\N
338	004949	ARBANA NTP - PRIZREN	\N
340	009075	Arbeni Supermarket SHPK-Rahovec	\N
341	007158	ARBËR GROUP  SH.P.K.-Peje	\N
342	013722	ARBER H SH.P.K-Podujevë	\N
343	126211	ARBER MARKET GROUP SH.P.K.	\N
344	007067	ARBËR TOQANI B.I.-Peje	\N
345	000043	ARBERI 1 NTP - Ferizaj	\N
346	005022	ARBERI DPT - PONOSHEC-GJAKOVE	\N
347	009809	ARBËRI MFKG SH.P.K.-Ferizaj	\N
348	100342	ARBERIA SH.P.K.	\N
349	006494	ARBËRIA TURIST SH.P.K -Prizren(tranzit)	\N
350	001444	ARBEX - Prizren	\N
351	007905	ARBINI SHPK RAHOVEC	\N
352	008117	Arbios Çoçaj B.I.	\N
353	011147	Arbnore Mema B.I.(BEAUTY COS)-Viti	\N
354	001448	ARBRI FT - Peje	\N
355	001449	ARBRI MN - Peje	\N
356	001452	ARDHMERIA  NTP - Lypjan	\N
357	001455	ARDI - Begrac- Viti	\N
358	001457	ARDI - Junik-Deqan	\N
359	001458	ARDI - Mazgit-Kastriot	\N
361	126022	Ardi Cavaliero Group SH.P.K.	\N
362	001463	ARDI DPT - Rahovec	\N
363	007939	ARDI DT-Baice Drenas	\N
364	013495	ARDI J SH.P.K.-Junik	\N
365	001467	ARDIANI DPT - Pejton - Prishtine	\N
366	009453	Ardit Makica B.I.	\N
367	001456	ARDI-T -SHPK Br.Diellit Prishtine	\N
368	012689	Ardite Hajdari B.I.	\N
369	008674	Arfije Gashi & Sylejman Gashi O.P.-Pejë	\N
370	003462	ARI NTSH(M.Shaqiri) - FERIZAJ	\N
371	009761	ARIAN KADRIU B.I.-(ANI)-Prishtine	\N
372	126468	Ariana Brada B.I.	\N
373	007997	ARIFE MORINA B.I PRIZREN	\N
374	004574	ARJANI DPT - PRUGOFC- BESIANE	\N
375	001487	ARJETA  GROUP - Skenderaj	\N
377	001489	ARLENA DPT - Rahovec	\N
378	004755	ARLLATI MINI MARKET - GJAKOVE	\N
379	013853	Armend Hapçiu B.I.-Prizren	\N
380	001492	ARMENDI NTP - Ferizaj	\N
381	004330	ARMENDI NTP-Vragoli	\N
382	126496	Armir Makica B.I.-Suhareke	\N
383	012649	ARNISI & LIBI SH.P.K.-Podujevë	\N
384	013790	AROMA BB SH.P.K.-Prishtinë	\N
385	004952	AROMA SHPK - Llapnaselle - Prishtine	\N
386	126505	Aroni L Store SH.P.K.-Kacanik	\N
387	012704	Arrbi SH.P.K.	\N
388	126214	Arsim Fetahi B.I.	\N
389	013407	ARSIMI DEPO SH.P.K.-Mitrovicë Veriore	\N
390	010666	Art Ari SH.P.K.-Vushtrri	\N
391	001496	ART CAFFE SHPK - Prishtine	\N
392	125772	ART GRILL SH.P.K.-\tGraçanicë	\N
393	009284	ART MARKET DPT -Gjakove	\N
394	125811	ART ORELA SH.P.K.	\N
396	001502	ARTA MARKET - Gjilan	\N
397	013807	Arta R. Krasniqi B.I.-Prizren	\N
398	010572	Arta Vitia Gashi B.I.-Prishtinë	\N
399	007277	ARTANI DPT - Slivove Prishtine	\N
400	125858	ARTEFORM SH.P.K.	\N
401	008192	ARTI-B SHPK-Dobraje Lipjan	\N
402	009455	ARTIDA LD SHPK-DEÇAN	\N
403	012591	Arting SH.P.K.(Derand hotel)-Prishtinë	\N
404	126337	Artist Ahmetaj B.I.	\N
405	008857	ARTIZAN SHPK-Prishtine	\N
406	010542	Artizzan Bakery SH.P.K.-Prishtinë	\N
407	003288	ARTMOTION  N.P.SH	\N
291	126401	Ambient D.p.h.	\N
292	004764	AMBIENT PIZZA - PRISHTINE	\N
293	005848	AMBIENTI D.P.H. - PRIZREN	\N
294	009296	AMBIENTT PIZZA SHPK-Prishtine	\N
295	010524	AMELA2017 SH.P.K.-Rahovec	\N
296	012846	American Burger KOS L.L.C.-Ferizaj	\N
297	006521	AMI SWEET'S -  PRISHTINE	\N
298	126144	Amici Lounge SH.P.K.	\N
299	006791	AMIN DPT - Peje	\N
300	001408	AMINA - Nebregosht - Prizren	\N
301	002715	AMIRI - Prishtine	\N
302	001410	AMIRI - Zheger- Gjilan	\N
304	007913	AMIRI SHPK-Prishtine	\N
305	012450	AMPM 24 H MARKET SH.P.K.-Ferizaj	\N
306	013717	ampm shop Pishtinë SH.P.K.-Prishtinë	\N
307	007198	AMV HOLDING Shpk-Banje Vushtrri	\N
318	001422	ANESA - Rahovec	\N
319	001423	ANI MARKET - B.Diellit - Prishtine	\N
321	012457	Anik & Jusra SH.P.K.-Lipjan	\N
322	022171	ANIKU DPT - Emshir - Prishtine	\N
323	006260	ANIKU MARKET DPT- Prishtine	\N
324	126162	ANILA FREESHOP SH.P.K.	\N
325	013640	AniMates SH.P.K.-Graçanicë	\N
326	012353	Anina Pharm SH.P.K.	\N
327	010244	Anna Market - Fushë Kosovë	\N
328	009734	ANNA Market SHPK-Banje Istog	\N
329	006994	ANNEX OIL SHPK-PRIZREN	\N
330	001429	ANTIKA - Gjilan	\N
331	125934	ANTIKA 3B N.T.H	\N
332	008160	Apartment 197 Group LL.C.-Prishtine	\N
441	010479	Avni Haliti-Dumnice  e poshtme	\N
440	005698	AVNI DPT - BESIANE	\N
443	126278	Azem H. Bejta B.I.-SKENDERAJ	\N
442	013645	Avni Hysniu B.I.-Suharekë	\N
444	126091	B & Z Group L.L.C.	\N
447	001546	B MARKET -  Shterpc	\N
448	008779	B MARKET SH.P.K.	\N
449	010097	B&M Group LLC-Fushe Kosove	\N
450	012924	B.V. D. ING SH.P.K.-Vushtrri	\N
446	012641	B G FREESHOP-Fushë Kosovë	\N
451	013472	B1 Coffee & More SH.P.K.-Prishtinë	\N
453	126307	B2Code  D.O.O.	\N
454	125964	B7 GAMING CENTER L.L.C.	\N
455	001548	BACI MARKET - Ferizaj	\N
452	007647	B2 LOUNGE BAR DPH-Prishtine	\N
456	013529	BACI PETROL SH.P.K.-Klinë	\N
458	125725	Bagolina Ak 2021 SH.P.K.-Prishtinë	\N
459	126369	Bagolina BD SH.P.K.	\N
457	001551	BADEM - Besiane SHPK	\N
461	012913	BAI SH.P.K.-Pejë	\N
460	012577	Bagolina Co L.L.C.	\N
462	001554	BAJRA - Rahovec	\N
465	007359	BAKE CAKE SHPK-Prishtine	\N
464	125977	BAJRON FERIZAJ SH.P.K.	\N
467	126472	Bakery Qerimi SH.P.K.	\N
466	013103	Bakery Evropa 2021-Prizren	\N
469	007614	BALCONY Shpk - Prishtinë	\N
470	007335	BALECI 2 TREG-Prishtine	\N
468	008558	BALA MARKET SH.P.K.	\N
471	001562	BALI COMPANY - Besiane	\N
472	001560	BALI DPT- Nakarade Fushe Kosove	\N
473	011067	Balinca Group SH.P.K.-Malishevë	\N
474	008211	Ballkan Petrol SH.P.K.	\N
475	009919	BAMBO Lounge SHPK-Vushtri	\N
476	001569	BAMEX MARKET - Mitrovice	\N
477	008456	Banana - S. H SHPK- ISTOG	\N
478	008123	BANANA A.D.-SHPK Prishtine	\N
479	003940	BANANA CENTER OP - ISTOG	\N
480	125979	BANANA FRUITS SH.P.K.	\N
481	010984	Banana Group SH.P.K.-Graçanicë	\N
482	001573	BANANA MARKET NTP- Deçan	\N
483	012032	BANANA STORE SH.P.K.-Istog	\N
485	001578	BANJA E KLLOKOTIT - Kllokot- Gjilan Sh.P	\N
486	001557	BANJSKA DPT - Mitrovice	\N
487	005742	BANKAI FURRA NTP - DARDANI -POZHORAN	\N
488	010531	Bar Lounge DeRada SH.P.K.-Prishtinë	\N
489	126534	BAR TERRACE L.L.C.	\N
490	012540	Baraka Eatery SH.P.K.-Prishtinë	\N
491	011084	BARBARY SH.P.K.-Prishtinë	\N
492	005547	BARDHI - R DPT- Gjakove	\N
493	009909	BARDHI NTSH(A.Çadraku)-Rahovec	\N
494	126551	Bardhyl N. Rexhepaj B.I	\N
495	008930	BARISTAS-FOOD&SWEETS SHPK	\N
496	012640	Barnatore Joni L.L.C.-Fushë Kosovë	\N
497	013742	Barnatore LUNA SH.P.K.-Prishtinë	\N
498	001601	BARNATORE VRELLA-Vrella-Istog	\N
499	012426	BARNATORJA PRANVERA PH SHPK.-Gjilan	\N
500	003773	BARON RESTAURANT DPH- GJILAN	\N
502	126536	Baroque SH.P.K.	\N
503	009040	BAS SHPK-Ferizaj	\N
504	006557	BASHKIMI - RAHOVEC	\N
505	001606	BASHKIMI - Sllatine Viti	\N
506	012521	BASHKIMI ALBI SH.P.K.-Viti	\N
507	007414	BASHKIMI NTT-RAHOVEC	\N
508	003322	BASILICO SHPK - Fushe Kosove	\N
509	126308	BASIS GROUP SH.P.K.	\N
510	001940	BASRI IMERI B.I. DIELLI SUPERMARKET NTP	\N
511	012505	BATA COMPANY L.L.C.	\N
512	001608	BBC TRADE (Hamit Rushiti)- Prishtine	\N
513	011275	BBD CREPES SH.P.K.-Prishtinë	\N
514	012718	BBK FREESHOP SH.P.K.-Prishtinë	\N
515	125924	BD CONSTRUCTION SH.P.K.	\N
516	002689	BE & SA TRADE TREG(B.Kyqyku)- Prizren	\N
517	012346	BE ALL PADEL L.L.C-Prishtinë	\N
518	126106	BEDI MARKET GROUP SH.P.K.	\N
519	010513	Bedi Market-Podujevë	\N
520	126562	Bedi's Bar D.p.h.	\N
521	012715	Bedrie Sokoli B.I.	\N
523	126083	BEEGONIA	\N
524	010982	BEG LOUNGE BAR SH.P.K.-Prishtinë	\N
525	005337	BEGLER SH.P.K.	\N
408	008338	Artmotion Sh.P.K	\N
410	001508	ARVIS NTP - Gjakove	\N
411	001510	AS COM NTP (Agim Demaku B.I.)- Drenas	\N
412	010989	Asllan Ramadanaj B.I.-Suharekë	\N
413	125718	Asllani 74 SH.P.K.-Ferizaj	\N
414	003588	ASPERIN+C - LYPJAN	\N
415	126265	Asrije Azemi B.I.	\N
416	009691	ASTOR MARKET SHPK-Prishtine	\N
417	008512	ATC SHPK-Drenas	\N
418	001529	ATDHE COMMERC - Gjakove	\N
419	126407	ATRIUM GROUP SH.P.K.	\N
420	001534	ATROPA  SHPK - Lypjan	\N
421	001536	AULONA - Lypjan	\N
422	126122	AULONA 1 SH.P.K.	\N
423	003423	AURORA CAFFE NH - DEQAN	\N
424	125853	AURORA EXLUSIVE SH.P.K.	\N
426	126114	Aurora Shoes SH.P.K.	\N
427	126514	AURORA STAJKI SH.P.K.	\N
428	013465	Auto Klubi Eurogoma Racing Team- Prishti	\N
429	013614	AUTO LABI SH.P.K.-Pejë	\N
430	012419	AUTO RENTAL SH.P.K.-Prishtinë	\N
431	126074	Auto Sallon & Rent a car KENA	\N
432	012808	Auto Star Xharra SH.P.K.	\N
433	006157	Auto Taxi Luan Valla-Pejë	\N
434	008900	AUTOMEM KOSOVA NTP-Prishtine	\N
435	011149	AVAS S SH.P.K.-Shtime	\N
436	009593	AVAV GROUP SHPK-Prishtine	\N
437	011049	Avdi N. Misini B.I.(Missini)-Viti	\N
438	004141	Avdi N. Misini B.I.(Missini)-Viti	\N
439	009616	AVIA CENTER SHPK-Fushe Kosove	\N
559	001658	BENITA COMANY SHPK- Gremnik	\N
560	012389	BENITA CORPORATION SH.P.K.-Kline	\N
561	013661	Berat Rr. Pllana B.I.-Toplica Top Market	\N
562	001663	BERISHA - Ferizaj	\N
563	012586	Berisha Center SH.P.K.	\N
564	006985	BERISHA MARKET-SHPK -Metoc Gjilan	\N
565	007231	BERISHA PETROL SHPK-Ferizaj	\N
566	012304	Berisha Restaurant SH.P.K.	\N
567	013725	Berliner Döner Foods SH.P.K.-Prishtinë	\N
568	013000	Beruno Restaurant SH.P.K.-Ferizaj	\N
569	001666	BES COM - Ferizaj	\N
570	008415	BES- COM SH.P.K. - Ferizaj	\N
572	001668	BESA - Dardane- Kamenice	\N
573	007900	BESA 3 - Kaqanik	\N
574	013752	BESA asv SH.P.K.-Prishtinë	\N
575	012760	BESA CENTER SH.P.K.-Kamenicë	\N
576	012935	BESA NJË SH.P.K.-Kaçanik	\N
577	001674	BESA SH - Kaqanik	\N
578	001675	BESA TONI - Ulpiane - Prishtine	\N
579	126527	Besarhaskaj Videographer Shpk	\N
580	008370	BESART ARLLATI B.I.-Gjakove	\N
581	126573	Besart Shefiti B.I.	\N
582	006862	BESARTA SHABANAJ B.I.	\N
583	001679	BESARTI NTP - Ferizaj	\N
584	001236	BESI - B DPT-LLAPUSHNIK Gllogoc	\N
585	003540	BESI BARNATORE NTP - KLINE	\N
586	001689	BESI COM - Lluga- Besiane	\N
587	006468	BESI MARKET - THERANDË	\N
588	001692	BESI MARKET DPT - Gjakove	\N
589	010047	BESI Restaurant pizzeria DPH-Kamenice	\N
590	005727	BESI SUPERMARKET NTSH(H.Rrahman)SMOLICE	\N
591	006489	BESIANI SHPK -VELANI	\N
592	013670	Besim Ba. Berisha B.I.-Podujevë	\N
593	126393	Besim Group  SH.P.K.	\N
594	001696	BESIM MARKET Prizren	\N
596	126377	Besimi  Commerc BIG SH.P.K.	\N
597	009704	BESIMI Commerce SHPK-Shtime	\N
598	011054	BESIMI GROUP SH.P.K.	\N
599	001698	BESIMI MARKET - Prizren	\N
600	001694	BESJANI NT - Kaqanik	\N
601	013587	Besnik Alija B.I.- QERSHIJA 1-Prishtinë	\N
602	007068	Besnik N.t.p - RZ	\N
603	007183	BESNIKU - Kovrag - Burim	\N
604	009249	Besniku Cake & Coffe Shop SHPK-Prizeren	\N
605	001704	BESNIKU MARKET - Livoq i Eperm- Gjilan	\N
606	001705	BESNIKU NPT - Shtime	\N
608	011141	BEST MARKET(Blendi Hoti B.I.)-Rogovë	\N
609	013631	BEST PETROL SH.P.K.-Prizren	\N
607	011193	BEST MARKET(Blendi Hoti B.I.)-Rogovë	\N
611	007914	BETA GROUP SHPK-Rogoqice	\N
610	005981	BESURI DPT - FUSHE KOSOVE	\N
613	001716	BETI - Vushtrri	\N
614	001718	BETIMI - Hajvali-Prishtine	\N
615	006695	BETIMI DPT -  Vushtrri	\N
616	003554	BETIMI DPT (Sahit Latifi B.I.)- HAJVALI	\N
618	009243	Bifurkacioni SHPK-Ferizaj	\N
619	008722	BIG MARKET SHPK-Mitrovice	\N
617	125916	Betonika SH.P.K.	\N
620	126268	Big Oli SH.P.K.	\N
622	009399	BIG SCOOP NTP(Kreshnik Shala)Prishtine	\N
623	126028	BII RESTAURANT PINES SH.P.K.	\N
624	009291	BIKE FRIENDLY CAFE SHPK-Prishtine	\N
625	001724	BIMI - Peje	\N
621	007630	BIG SCOOP N.T.P.-Pristine	\N
627	006664	BINGO - 2 - NTP - Prizren	\N
626	005762	Binak M.Çoçaj B.I.-OREX - FERIZAJ	\N
629	010453	BINI MARKET-Hani i Elezit	\N
630	010750	Binjakët Group SH.P.K.-Vushtrri	\N
632	126039	BINO J	\N
633	013504	Bio Tregu Dy SH.P.K.-Suharekë	\N
628	002653	BINGO MARKET - Prizren	\N
634	006519	BISERI DPT - Gjakove	\N
635	126403	Bislimaj Sh.p.k.	\N
636	126109	Bistro Jardin L.L.C.	\N
637	007890	BKM MARKET SHPK-KRUSHE E MADHE	\N
638	004943	BLACK AND RED  L.L.C. - VRELLË	\N
640	008074	Bled" Sh.p.k.	\N
639	126110	Bled & Co. SH.P.K.	\N
641	001735	BLEFO BLERI - Gerlic- Ferizaj	\N
642	126092	Blej Group L.L.C.	\N
527	126128	BEHARI MARKET PREMIUM SH.P.K.	\N
528	006228	BEHARI-IM MALISHEVE	\N
529	010218	BEKA AG COMPANY L.L.C.-Prishtinë	\N
530	004146	BEKA TRADE SHPK 2-  KOLOVICE	\N
531	008210	BEKA TRADE-1 " SH.P.K."	\N
532	010576	Bekim R. Sllamniku B.I.-Fushë Kosovë	\N
533	003403	BEKIMI COMMERC D.P.T- TRESTENIK	\N
534	002913	BEKIMI NTP -  Vrelle - ISTOG	\N
535	001627	BEKTASHI - Prizren	\N
536	011175	BELI CENTER SH.P.K.-Prizren	\N
537	001420	BELI DPT - PRISHTINE	\N
538	001630	BELI DPT - Prizren	\N
539	005864	BELI DPT - THERANDE	\N
540	001632	BELI -Prishtine	\N
542	012960	Belle Home SH.P.K.-PRISHTINË	\N
543	009288	BELMUNDO L.L.C.-Prishtine	\N
544	001635	BELTI  DPT - Matiqan - Prishtine	\N
545	011295	Ben Center SH.P.K.-SUHAREKË	\N
546	003725	BENI - BUKOSH - THERANDE	\N
547	001639	BENI - F.Kosove	\N
548	001640	BENI - Gjakove	\N
549	001644	BENI - Te Radio Kosova -Prishtine	\N
550	005484	BENI 5 NTSH - LUBIZHDË- MALISHEVE	\N
551	013581	BENI ABB SH.P.K.-Komogllave-Ferizaj	\N
552	010117	Beni Dona DPH(Arben Vitija)-Prishtinë	\N
553	001648	BENI DONA SHPK - Prishtine	\N
554	005542	BENI DPT - Ferizaj	\N
555	126477	BENI IMPEX Group SH.P.K.	\N
556	007912	BENI IMPEX NPSH-Viti	\N
558	000221	BENI SHPK(Planet) Shiroke - Therande	\N
676	009644	BLUE PHARM SHPK-Podujevë	\N
677	126321	BlueSphere L.L.C.-Prishtine	\N
678	010339	BO Enterprise SH.P.K.-Prishtinë	\N
679	125708	Bob Stop Shop SH.P.K.-Prishtinë	\N
680	010467	Bojan Bojkovicë-Prelluzh Vushtrri	\N
681	009415	Bon Ami Lounge Bar SH.P.K.	\N
682	125776	Bon Appetit Bakery Caffee SH.P.K.-Prisht	\N
683	009795	BON Bouquet SHPK-Prishtine	\N
684	126048	Bon Marche Market L.L.C.	\N
685	013782	BON PRIX DPH-Peje	\N
686	012918	Bon'Ami Bar SH.P.K.-Gjilan	\N
687	125855	Boni S Pizza Sh.p.k.	\N
688	001773	BONINI - Duhel- Therande	\N
689	009207	BONNARD L.L.C.	\N
690	126346	BONTE  SH.P.K.	\N
691	002654	BONUS MARKET - Prizren	\N
692	013005	Booka Lounge Bar SH.P.K.-Fushë Kosovë	\N
693	010537	Bora Lounge SH.P.K.-Vushtrri	\N
694	001779	BORA NTP - Fushe Kosove	\N
695	012493	Borne 1 SH.P.K.	\N
696	012929	Bosna 1 SH.P.K.-Prishtinë	\N
698	001785	BOSS MARKET- Fushe Kosove	\N
699	010720	BOSS Market SH.P.K.-Prishtinë	\N
700	012073	Bossi N.T.P. Market -Fushë Kosovë	\N
701	007253	BOTTEGA MARKET SH.P.K.	\N
702	995542	BOTTLE KAFITERIA DPH - FERIZAJ	\N
703	126495	BOURBON  L.L.C.	\N
704	012675	Boutique Hotel ETNOMANIA SH.P.K.	\N
705	007083	BP - Bala Petrol - Istog	\N
706	010693	Bp Bio Tregu SH.P.K.	\N
707	001788	BRAHIMI MARKET -  VUSHTRRI	\N
708	011207	Brasserie Le Village SH.P.K.-Ferizaj	\N
709	012631	Bratislav Igic B.I.(P.P. " MVS ")-Obiliq	\N
710	004999	BRAVO PP - DOBROTIN - LIPJAN	\N
711	001790	BRENDONI DPT(Bekim Nikoliqi ) - Gjakove	\N
712	002719	BRESANA - Prizren	\N
713	010360	BREZOVICA HOTEL SPA SH.P.K.-Brezovica	\N
714	012394	BREZOVICA SKI ADVENTURE SH.P.K.	\N
715	012360	BRICO KOSOVA SH.P.K.	\N
716	013738	Brilanda Ballata B.I.-Gjakovë	\N
717	126512	Brilant N.H	\N
718	126134	BROKET eatery SH.P.K	\N
720	007572	BROVING-SA SH.P.K	\N
721	010387	BRUNI SH.P.K.-Prishtinë	\N
722	008173	BS-COM N.T.- Peje	\N
723	012024	BSG MARKET-Malishevë	\N
724	011068	BTP Construction SH.P.K.-Mitrovicë	\N
725	125721	BTP Corporation L.L.C.-Vushtrri	\N
726	006076	BUBLI - R NTP - MALISHEVE	\N
727	012791	BUÇAJ Retail SH.P.K.	\N
728	007616	BUDURA P.P.-Shterpce	\N
729	126453	BUJANA PRODUKT SH.P.K.	\N
730	126451	BUJANA Sweets & Lunch SH.P.K.	\N
731	009148	Bujar Dapko B.I	\N
732	000828	Bujar Morina B.I. - Gllareve-Kline	\N
733	125741	Bujar Shulemaja B.I.-Fushe Kosove	\N
734	001795	BUJARI - Junik-Deqan	\N
736	006335	BUKATORE SHPK - Prishtine	\N
737	126320	BUKI FOOD'S SH.P.K.	\N
738	001802	BUKI MARKET DPT - Besiane	\N
739	126275	Bukpjekes RONA SH.P.K.	\N
740	005379	BULI NTP - Ramjan - Pozhoran	\N
742	001805	BUM MARKET SHPK - Gjilan	\N
743	009539	BURBUQE TERNAVA B.I.-Fushe Kosove	\N
744	013370	Burger LINDI SH.P.K.-Prishtinë	\N
745	126465	Burger Time & Grill  Pejë SH.P.K.	\N
746	011299	Burger Time & Grill House SH.P.K.-Deçan	\N
747	125759	Burger Time 01 SH.P.K.-Prishtinë	\N
748	010754	Burim Peci B.I.-Mitrovicë	\N
749	012733	BURIMI CORPORATION SH.P.K.-Prishtinë	\N
750	001817	BURIMI NTSH - Runik- Skenderaj	\N
751	006320	BURIMI VDD N.T - Ferizaj	\N
752	013440	BURIMI VDD SH.P.K.- Ferizaj	\N
754	013634	BUSHI 2024 SH.P.K.-Suharekë	\N
755	006102	BUTRINTI - V  NTP - Çagllavice	\N
756	007380	BUTRINTI DPT-Drenas	\N
757	001824	BYQMA DPT - Hajvali- Prishtine	\N
758	013436	BYTYQI 2024 SH.P.K.-Suharekë	\N
644	001736	BLENDA - Gjilan	\N
645	001737	BLENDA DPT - Prishtine	\N
646	001745	BLENDI - Prizren	\N
647	009429	Blendi & LB SH.P.K.-Skenderaj	\N
648	005504	BLENDI NTP CENTER - Magure	\N
649	001750	BLEONI (Bujar Rrustem-)Banulle - Lypjane	\N
650	001751	BLERCOM - KIEVE	\N
651	001753	BLERI-COMMERCE - Mitrovice	\N
652	007212	BLERIM KUBOVA B.I.-Topanice Kamenice	\N
653	020001	BLERIMI BLERI SH.P.K.	\N
654	009972	Blerona Market SH.P.K.-Prishtinë	\N
655	004520	BLERTA - Ferizaj	\N
657	013690	Blerta I. Shala B.I.-Rugove	\N
658	013691	Blerta Market SH.P.K.-Prishtinë	\N
659	001760	BLERTOS DPT- Besi - Besiane	\N
660	001761	BLETA  - Ferizaj	\N
661	126079	BLETA MARKET SH.P.K.	\N
662	009969	Bleta Pharm SHPK-Suhareke	\N
663	012817	BLETA STORE SH.P.K.-Ferizaj	\N
664	001765	BLINI B NTSH - Gjakove	\N
665	001764	BLINI DPT- Prishtine	\N
666	009698	BLINI MARKET B.I.-Rogove	\N
667	009778	Blini-MB N.T.(M.Bajraj)-Vitomerice	\N
668	010986	BLISS MARKET SH.P.K.-Prishtinë	\N
669	005317	BLISS SHPK - PRIZREN	\N
670	012466	BLISS STUDIO SH.P.K.-Fushë Kosovë	\N
671	012599	Blitz CineStar L.L.C.-Prishtinë	\N
672	013781	Blondin Rrahmani B.I.-Prishtinë	\N
674	008951	BLUE MARKET SHPK-Prizeren	\N
675	126506	Blue market SM Sejdullah Murseli BI	\N
792	013637	CENTRUM LOUNGE BAR L.L.C.-Prishtinë	\N
793	009533	CENTRUM SHPK-Lipjan	\N
794	125780	Çerçiz AEÇ L.L.C.-Fushë Kosovë	\N
795	009548	CFO PHARMA SH.P.K.	\N
796	013409	Chaplin Home L.L.C.-Prishtinë	\N
797	007460	CHE BAR BISTRO SHPK -Prishtine	\N
798	009537	CHE BAR LOUNGE REZIDENCE SH.P.K. -Graça	\N
799	006533	CHE BAR LOUNGE SHPK - Prishtine	\N
800	009269	CHE BAR PZ SHPK-Prizeren	\N
801	012680	Chef's Bakery SH.P.K.	\N
802	010232	CHERRY LOUNGE Bar SHPK-Ferizaj	\N
803	013474	CHICKANO L.L.C.-Ferizaj	\N
805	013695	Chill Zone KFN SH.P.K.-Gjakovë	\N
806	008131	CHOCOLATE CORNER  N.T.SH	\N
807	010916	CHOP SH.P.K.-Prishtinë	\N
808	012814	Churchill SH.P.K.-Prishtinë	\N
809	001864	CIMA DPT - Drenas	\N
810	125922	CIMI ZH SH.P.K.	\N
811	007476	CINEPLEXX KOSOVO LLC-Veternik Prishtine	\N
812	008950	CINI OIL SHPK-Prizeren	\N
813	013599	Cipollino SH.P.K.-Novobërdë	\N
814	000005	CITY  PARK- HIPERMARKET- PRISHTINE	\N
815	008465	City Fresh Market Shpk-Prizeren	\N
816	126494	CITY INVEST GROUP SH.P.K.	\N
817	010733	CITY MARKET ABSH SH.P.K.-Ferizaj	\N
818	007819	CITY MARKET SHPK-Gjakove	\N
819	006364	COCO LOUNGE & BAR - Ferizaj	\N
820	001873	COFFEA PHARM - Prishtine	\N
822	125839	COKI'S SH.P.K.	\N
823	001874	COLI DPT - Ulpiane Prishtine	\N
824	009157	Comandante Marcos L.L.C.-Prishtine	\N
825	126202	Concierge Park L.L.C.	\N
826	125793	CONO NAPOLITANA SH.P.K.	\N
827	008765	COOP Market SHPK-Prishtine	\N
828	005887	CORNER 2 DPH - PRIZREN	\N
829	005865	CORNER BAR DPH - PRIZREN	\N
830	009988	CORNER BAR SHPK-Prishtine	\N
831	005932	CORNER DPH - PRISHTINE	\N
832	013039	CORNER FOOD & COFFEE SH .P.K. SH.P.K	\N
833	013765	Corner Group SH.P.K.-Obiliq	\N
834	013749	Corner Store SH.P.K.-Ferizaj	\N
835	004839	CORPORAT V.B.E. SHPK - FUSHE KOSOVE	\N
836	126119	Corto Caffe SH.P.K.	\N
837	126524	Cozy Eatery SH.P.K.	\N
838	012480	CRUST AND CRUMB L.L.C.	\N
839	126194	CUCI CAFFE SH.P.K.	\N
840	013793	CUFA AUTO BARTJE SH.P.K.-SKENDERAJ	\N
841	012993	Culaccino Lounge L.L.C.-Prishtinë	\N
842	126158	CURA PHARMACY SH.P.K.	\N
843	001882	CURRI MARKET - Gjakove	\N
845	008361	D DRILONI SHPK-Kamenice	\N
846	008461	D GROUP INTERNATIONAL SHPK-Graçanicë	\N
847	100177	D.D & O SH.P.K.	\N
848	010603	D.P.H.  BEL AMI(Gezime Jaha)-Prishtinë	\N
849	012789	D.P.H. "LE-NAR-2"-Rahovec	\N
850	012575	D.P.H. ,,Peppino"	\N
851	013333	D.P.H. Caffeteria "TE SHPATI"-Gjakovë	\N
852	009440	D.P.H. DONI	\N
853	012463	D.P.H. RIVER&BAR (Ymri Bajrami B.I.)	\N
854	008860	D.P.H.Caffe XL	\N
855	010379	D.P.T "Diana"-Vushtrri	\N
856	007896	D.P.T TE LULI - PEJE	\N
857	010589	D.P.T. '' IN & LEO ''-Gjakovë	\N
858	013101	D.P.T. " ALD "-Prizren	\N
859	012972	D.P.T. " Charlie "-Suharekë	\N
860	013068	D.P.T. " Jaffa "-Gjakovë	\N
861	003354	D.P.T. " KIOSK TE RRUSHI " -  ZHABAR	\N
862	013037	D.P.T. " Mendi "-Llozice	\N
863	010470	D.P.T. " Olti "-Gjilan	\N
865	012950	D.P.T. " TE HASANI "-Mitrovicë	\N
866	007483	D.P.T. " V. P PROKSHI "	\N
867	009921	D.P.T. " VLERA "	\N
868	010410	D.P.T. "Erdi & Joni"-Gjakovë	\N
869	000492	D.P.T. SUADI  - Gjilane	\N
870	003498	D.P.T. VELANIA	\N
871	012331	D.P.T."EDO"-Prizren	\N
872	012645	D.P.T."MEMA"-Kaçanik	\N
873	013104	D.P.T.,,Kastrati"-Pejë	\N
874	010957	D.P.T.,,Minatori"-Suharekë	\N
875	010773	D.P.T.,,Valentini D"-Bishtazhin Gjakove	\N
760	001826	CADI DPT - Fushe Kosove	\N
761	009735	CADI Market -Fushe Kosove	\N
762	126510	Caffe Bar Dionis	\N
763	125791	CAFFE BAR TE VISI SH.P.K.	\N
764	013672	Caffe Check in SH.P.K.-Gjakovë	\N
765	013843	Caffe de Flore SH.P.K.-Prishtinë	\N
766	125771	Caffe KIDS SH.P.K.-Fushë Kosovë	\N
767	013635	CAFFE LAB SH.P.K.-Prishtinë	\N
768	126455	CAFFE RP KNEZ D.O.O.	\N
770	012089	CAJA COMPANY SH.P.K.-Malishevë	\N
771	126473	Cakes By Vjollca L.L.C.	\N
772	009077	CAKI SHPK-Ferizaj	\N
773	001840	CALI - Ulpiane - Prishtine	\N
774	013493	Cali 94 SH.P.K.-Rahovec	\N
775	004809	CALI DPT - OPOJE	\N
776	008905	CALI-M SHPK -Dragash	\N
777	001843	CAMEL S  - Rahovec	\N
778	003587	CAN MARKET  -MAMUSHE	\N
779	006800	ÇANA MARKET SHPK - Shterpce	\N
780	012478	CANI & SYLA SH.P.K.-Prizren	\N
781	013669	Cantina Group L.L.C.-Ferizaj	\N
782	013392	Car Wash Lumi L.L.C.-Podujevë	\N
783	008524	CAR WASH NOAH SHPK-Fushe Kosove	\N
784	001850	CARDEMON BARNATORE- Kastriot	\N
785	126152	Casa de babel SH.P.K.	\N
787	012517	CASA MIA Terrazza Sh.p.k	\N
788	006735	CASA RITA DPH- Prishtine	\N
789	010956	Casablanca L.Bar SHPK-Fushë Kos	\N
790	126135	CELTIC IRISH PUB SH.P.K.	\N
791	003952	CENTRUM HOTEL - PRIZREN	\N
909	012408	Day 'n' Nite SH.P.K.	\N
910	125877	DC Beauty KS SH.P.K.	\N
911	013499	DDG Group SH.P.K.-Prishtinë	\N
912	009062	DE AL SH.P.K.-Suharekë	\N
913	000310	DE RADA RESTAURANT SHPK - Prishtine	\N
914	012009	DEA COSMETIKS SH.P.K.-Prizren	\N
915	126385	DEA Market FV SH.P.K.-Prishtine	\N
916	006501	DEA MARKET SHPK - Peje	\N
917	004622	DEA NTP - Aeoroport - Prishtine	\N
918	009749	DEA SH.P.K.	\N
919	012467	DEDA CENTER SH.P.K.-Kaçanik	\N
920	001919	DEDA COMMERC - Doganaj-Kaqanik	\N
921	013589	DEER SH.P.K.-Skenderaj	\N
922	125812	Deha Emiri B.I.	\N
923	126542	DEJAN JOVANOVIC I.B.	\N
924	007372	DEL POSTO SHPK-Prishtine	\N
925	009954	DELFINI NPH-Lipjan	\N
927	126411	Delicious SH.P.K.	\N
928	008193	DELISH L.L.C -Prishtine	\N
929	004292	DELIVERY PIZZA N.T.SH -FUSHË KOSOVË	\N
930	001923	DELTA  R NTP - Dardani - Prishtine	\N
931	004381	DELTA GROUP SHPK-Peje	\N
932	013601	Delta -R NTP-Prishtinë	\N
933	012858	Dema Runik SH.P.K.-Skenderaj	\N
934	001925	DEMA-Runik- Skenderaj	\N
935	007121	DEMPING - Z.M. -NTP Runik Skenderaj	\N
936	001927	DENI MARKET - Burim	\N
937	001928	DENI NT - Burim (Istog)	\N
938	001929	DENIZI DPT - Prizren	\N
939	012672	Destan Kadrija B.I.	\N
940	001930	DETARI - Mitrovice	\N
941	009906	Deutschzentrum Kosova LLC-Prishtine	\N
942	007150	DHF COMPANY SHPK-Peje	\N
943	126390	DHOMA 2012 SH.P.K.	\N
944	012826	DHURIMI MARKET SH.P.K.-Klinë	\N
945	126515	Di Voli SH.P.K.	\N
946	011311	DIAGNOZA2009 SH.P.K.-Ferizaj	\N
948	003933	DIAMBE SHPK	\N
949	011202	DIAR TRAVEL SH.P.K.-Pejë	\N
950	001937	DIARTI SHPK - Prishtine	\N
951	005079	DIELLA SHPK - MATI 1- PRISHTINE	\N
952	009696	Diellëza DPT-Gllogoc	\N
953	013382	DIELLI MARKET SH.P.K.-Ferizaj	\N
954	008239	DIELLI NTP-Bardh i Madh	\N
955	007406	DIELLZA SHPK-Drenas	\N
956	013665	DIGITAL HIVE L.L.C-Prishtinë	\N
957	010772	Dina Center SH.P.K.-Rahovec	\N
958	001945	DINA H - Ratkoc- Rahovec	\N
959	010966	DINA MARKET DRS D.O.O.-Shtërpcë	\N
960	001947	DINA R (Ramiz Dina)- Gjakove	\N
961	001948	DINA TRANS - Shterpc	\N
962	005187	DINAMIKA 2000 DPT- PRISHTINE	\N
963	008050	DINI - M SH.P.K.	\N
964	009019	DINI SHPK-Pograxhe - Gjilan	\N
965	001952	DIONI DPT  - Kaqanik	\N
966	004151	DIONI DPT - LIPJAN	\N
967	007222	DIONI DPT-Kishnic	\N
969	126177	Dior Neziri B.I.	\N
970	005840	DISKONT DIARI SHPK- VELANI-PRISHTINE	\N
971	007507	DITI - R DPT-Slivove Ferizaj	\N
972	126466	DITI 3 SH.P.K.	\N
973	001962	DITI COM SHPK - Gjilane	\N
974	005703	DITI NTSH- THERANDE	\N
975	126254	DITI-R  D.p.z.	\N
976	126504	Dizzy Group Shpk	\N
977	125729	Doan Raifi B.I.-Fushë Kosovë	\N
978	001969	DOBROTIN (K.Perenic) - Llapnasell	\N
979	012711	Doel S.Q SH.P.K.	\N
980	008272	DOLCETTO VJOSA SHPK-Prishtinë	\N
982	001975	DONA DENT - Lypjan	\N
983	006865	DONA SHPK-DRENAS Mehdi Veliu B.I.	\N
984	126557	Doner House Burek	\N
985	001985	DONI - Krushe- Prizren	\N
986	006236	DONI DPT - Komogllave - Ferizaj	\N
987	022211	DONI KIOSK - Obiliq	\N
988	005012	DONI MARKET D.P.T - PRISHTINE	\N
989	007332	Doni Market -S.Gashi B.I.-Begrac	\N
990	009026	DONI NTP-Podujeve	\N
991	125872	Doni Speed Market SH.P.K.	\N
992	008308	DONIKA ZHEGRA B.I.-Gjakove	\N
993	001995	DONITA MARKET NTP - Burim	\N
994	008532	Doruntina Mamaj-Morina B.I.	\N
876	002587	D.P.T.FRESH MARKET- Prishtine	\N
878	010522	D.P.Z. " SWEET VESA "-Prishtinë	\N
879	009670	D.P.Z. ,,PRIZRENI-1"	\N
880	012488	D.P.Z. Furra " DIELLZA " (A. Ab Morina)	\N
881	125946	D3 Pharmacy SH.P.K.	\N
882	012477	D3 Pharmacy SH.P.K.-Prishtinë	\N
883	012492	DA MICHELE KOSOVA SH.P.K.	\N
884	009711	DADA Restaurant & More SHPK-Prishtine	\N
885	002728	Dafi Company SH.P.K.- PRISHTINE	\N
886	001889	DAFINA NTP - Dardane-Kammenic	\N
887	001892	DAFOTA - Gjakove	\N
888	001893	DAIJA - Gjakove	\N
890	009911	DAILY STORE LLC-Fushe Kosove	\N
891	125885	Damar Studios L.L.C.	\N
892	013454	DANEK SH.P.K.-Prishtinë	\N
893	007181	DANI COMPANY-Rama Petrol  Lipjan	\N
894	001899	DANI SHPK- Ratkoc- Rahovec	\N
895	009807	Dante SHPK-Prizeren	\N
896	013676	Dardan Duraj B.I.-Prizren	\N
897	008071	DARDAN MALOKU B.I.-Prishtine	\N
898	001905	DARDANI- Besiane	\N
899	001907	DARDANIA  SHPK- Mitrovic	\N
900	004924	DARDANIA MARKET NTP - TANKOSIQ	\N
901	009730	DARDANIA Market(A.Sallahu B.I.)-Dardani	\N
902	010778	DARDANIA PALACE SH.P.K.-Prizren	\N
903	013040	Dardania PPM SH.P.K.-Prishtinë	\N
904	010779	DARDANIA ROYAL SH.P.K.-Prizren	\N
905	001910	DASHI MARKET - Prizren	\N
906	006470	DASHI-2 - PRIZREN	\N
908	004316	DAUTI KOMERC	\N
1027	008817	DRIN GROUP SHPK-Kline	\N
1028	002028	DRINI 3F  N.T. SH. - Peje	\N
1030	007810	DRITA COMM NPT-Drobesh  Viti	\N
1031	004120	DRITA DPT - LAGJIA SPITALIT- PR	\N
1032	002035	DRITA SHPK - Gjakove	\N
1033	006998	DRITON PALUSHI B.I-BUDAKOVE	\N
1034	022219	DUALOS SHPK - Prizren	\N
1035	125783	Dubova Market SH.P.K.-Obiliq	\N
1036	012955	Duo A.B SH.P.K.-Mitrovicë	\N
1037	013870	Duo Cosmetics Group SH.P.K.-Prishtinë	\N
1038	008630	DUO Cosmetics SHPK-Prishtine	\N
1039	012785	Duo Market F&S SH.P.K.-Gjilan	\N
1040	009990	DURGUTI STORE SHPK-Prizren	\N
1041	008115	DURIM HAXHAJ B.I.-Greikoc Therande	\N
1042	009743	DURIM IBISHAJ B.I(Market Duri)-Malisheve	\N
1043	007317	DURIM SYLAJ B.I.-Gjakov.	\N
1044	002046	DURIMI - Hajvali  Sh.P.K- Prishtine	\N
1045	013004	Durmart L.L.C.-Mitrovicë	\N
1046	006302	Durmart L.L.C.-Mitrovicë	\N
1047	002049	DURO Pharm D.P.T- Prishtine	\N
1049	005950	DUSHI MARKET DPT - DRENOC- MALISHEV	\N
1050	010102	DUSHI MK SHPK-Malisheve	\N
1051	008316	DUSHI SHPK-Prishtinë	\N
1052	002050	DUSHKAJA NT -  Kaqanik	\N
1053	126553	DYNER BUKI 6 SH.P.K.	\N
1054	125768	DYNER KLEA SH.P.K.-Klinë	\N
1055	013398	Dyqan i Pavarur Hotelier " Edin"	\N
1056	002051	E & A  D.P.T- Ferizaj	\N
1057	013047	E BAR CAFFE SH.P.K.-Ferizaj	\N
1058	013102	E Hasani BTP L.L.C.-Vushtrri	\N
1059	126161	E KIOSK 24h L.L.C.	\N
1060	003834	E MARKET - KOLOVICE	\N
1061	013727	E TORRA SH.P.K.-Prishtinë	\N
1062	126031	E&ERA MARKET SH.P.K.	\N
1063	012364	EA Center SH.P.K.-Ferizaj	\N
1064	013667	EA PACK SH.P.K.-Ferizaj	\N
1065	008916	Eat SH.P.K.	\N
1066	010082	EAVD MARKET SH.P.K.-Ferizaj	\N
1068	003114	EBC KOZMETIK - Store Pr	\N
1069	126238	EBI GROUP SH.P.K.	\N
1070	126259	ECHTE BERLINER Prishtina SH.P.K.	\N
1071	126204	ECO CENTER SH.P.K.	\N
1072	126178	ECO MARKET SH.P.K.	\N
1073	009681	ECOLOG INTERNATIONAL SH.P.K	\N
1074	126479	EcoSun Energy  L.L.C.	\N
1075	002061	EDA PROM  Sh.P.K - Dragash- Prizren	\N
1076	011219	EDEN G 2021 SH.P.K.-Prishtinë	\N
1077	002072	EDI MARKET - Vranjec - Prishtine	\N
1078	012513	EDILGRANITI SH.P.K.-Prizren	\N
1079	002074	EDISON - Peje	\N
1080	001999	EDISON DPT - Peje	\N
1082	003967	EDITI NPTSH - VRELLE- ISTOG	\N
1083	007131	EDLIRA GOVORI B.I.-Prishtine	\N
1084	007303	EDMOND HAXHAJ B.I,-Gllareve	\N
1085	007886	EDONA 5 SHPK-Ferizaj	\N
1086	012764	Edona Company L.L.C.-Vushtrri	\N
1087	009490	EDONA GROUP SHPK-Vushtrri	\N
1088	006805	EDONI OIL SHPK - DRENOC	\N
1089	012864	EDUL MARKET SH.P.K.-Prishtinë	\N
1090	002052	EE-EXIM Sh.P.K- F.Kosove	\N
1091	013766	EGA Market 2024 SH.P.K.-Prishtinë	\N
1092	126112	Eggcellent Group SH.P.K.	\N
1093	011189	EGI GROUP SH.P.K.-Pejë	\N
1094	013818	EGNOR Market SH.P.K.-Pejë	\N
1095	012329	Egzolinda 2 SH.P.K.-Prishtinë	\N
1096	125868	Egzon M. Kelmendi B.I.-EKPHYSIO	\N
1097	002095	EGZONI G Sh.P.K - Peje	\N
1098	002098	EGZONITA MARKET NTP - Besiane	\N
1099	009128	EJA DPT(Bekim Hoda B.I.) Hajvali	\N
1100	006500	EKI DPT - DRAGASH	\N
1101	125875	Eklips Group Sh.p.k.	\N
1102	007994	EKO MARKET SHPK-Prishtine	\N
1104	012327	El Bar Lounge - Fushe Kosove	\N
1105	011296	EL Ga SH.P.K.-Prishtinë	\N
1106	013399	EL TOBACCO 2024 SH.P.K.-Gjakovë	\N
1107	002111	ELA (Naser Jasiqi B.I.)- Gjakove	\N
1108	012969	ELA MARKET 2023 SH.P.K.-Istog	\N
1109	002112	ELA MARKET DPT- Peje	\N
1110	009783	ELAA 1 SHPK-Mitrovice	\N
1111	012077	ELAN MARKET SH.P.K.-Vushtrri	\N
1112	002113	ELAN PETROL - Vushtri	\N
995	126328	Doss'3 Pizza SH.P.K.	\N
997	007038	DPH FELLAS-PRIZREN	\N
998	003873	DPH STARSUN COFFEE- PRISHTINE	\N
999	010477	DPH,, Aba "-Prishtinë	\N
1000	003964	DPT ARDI BATLLAVE-PODUJEVE	\N
1001	006488	DPT DONESI-VRANIDOLL-BESIANE	\N
1002	006394	DPT EDIONI MARKET - RAHOVEC	\N
1003	007680	DPT ELMEDIN-RAHOVEC	\N
1004	002145	DPT EMA - Prizren	\N
1005	003917	DPT ERZA - SHTIME	\N
1006	007731	DPT KATER+NJE RATKOC	\N
1007	002002	DPT KIWI  - Shipol - Mitrovice	\N
1008	003082	DPT KIWI - Shipol - Mitrovice	\N
1009	006734	DPT MURATTI-FORTESE	\N
1010	004029	DPT OSLO 2- MITROVICE	\N
1011	006447	DPT SYLA - PRIZREN	\N
1012	006801	DPT TE LOKI-KUSHNIN	\N
1014	000467	DPT,,SIHANA" - Prizren	\N
1015	002008	DRAGUSHA - B.Diellit - Prishtine	\N
1016	012551	DREAMPHARM-Ferizaj	\N
1017	005819	DREDHEZA NTP - KERPIMEHE-BESIANE	\N
1018	002013	DRENI  Sh.P.K(Z.Ramadani)- Matiqan	\N
1019	002016	DRENI HT NTP - Rakosh- Istog	\N
1020	002017	DRENI MARKET DPT -  Prishtine	\N
1021	012025	DRI LONII SH.P.K.-Prishtinë	\N
1022	012612	Drilon Podvorica B.I.	\N
1023	022150	DRILONI - M - Peje	\N
1024	004734	DRILONI DPT - SHAKOVICE	\N
1025	010605	DRILONI LB1-Mitrovicë	\N
1026	002025	DRILONI NTP  - Tophane- Prishtine	\N
1146	002155	EN SHARKU - Rahovec	\N
1147	010546	ENA MARKET SH.P.K.-Gjilan	\N
1148	011012	ENDI 06U MARKET SH.P.K.-Gjilan	\N
1149	012996	ENDI CENTER SH.P.K.-Gjilan	\N
1150	003468	ENDI MARKET - DRENAS	\N
1151	003270	ENDI MARKET-Zheger-Gjilan	\N
1152	008281	ENDRI MARKET SHPK-Kamenice	\N
1153	126425	Endrit Sahiti B.I.	\N
1155	002157	ENDRITI - Burim	\N
1156	002159	ENDRITI - Gjilan	\N
1157	013484	ENDRITI BUS SH.P.K.-Ferizaj	\N
1158	002160	ENDRITI DPT  Gavran  - Gjilan	\N
1159	000887	ENDRITI DPT - Peje	\N
1160	005162	ENDRITI DPT - VRELLE- ISTOG	\N
1161	005987	ENDRITI GF NTP - VITI	\N
1162	005776	ENDRITI MARKET NTP - ROGOVE	\N
1163	010427	Endriti Market -Skenderaj	\N
1164	008462	ENDRITI NTP-Istog	\N
1165	003613	ENDRITI-K  DPT -Magure LYPJAN	\N
1166	011014	ENERCOGAS BS SH.P.K.-Pejë	\N
1167	008508	ENERCOGAS SH.P.K	\N
1168	012928	ENERGYM FITNESS SH.P.K.-Prishtinë	\N
1169	126287	Enes Xhemili  B.I.	\N
1170	009412	Enesi Group SH.P.K.-Gjilan	\N
1171	002164	ENI - Bellanice - Malishev	\N
1172	003456	ENI GAQK- FERIZAJ	\N
1173	007205	ENIS HAZIRI B.I.-Prishtine	\N
1174	008507	ENIS HYSENI B.I.-Ferizaj	\N
1175	002168	ENISI DPT - Fushe Kosove	\N
1176	010279	ENISI DPT-Fushe Kosove	\N
1177	012639	Enjoy at B3 SH.P.K.-Gjakovë	\N
1179	009056	ENNUI SHPK-Prishtine	\N
1180	003915	ENSARI DPT- SHTIME	\N
1181	008225	ENZO SHPK-Gllogovc	\N
1182	002184	ERA MARKET- Ulpiane - Prishtine	\N
1183	007902	ERA PHARMACY SHPK-Fushe Kosove	\N
1184	126163	Erblina Krasniqi B.I.-EUROPA JUNIOR	\N
1185	013720	EREA LOUNGE BAR SH.P.K.-Prizren	\N
1186	002189	ERENIKU - Besiane	\N
1187	010771	Ereniku 2021 SH.P.K.-Podujevë	\N
1188	004585	ERI B DPT - FUSHE KOSOVE	\N
1189	008213	ERII SHPK-SUHAREKE	\N
1190	125882	Erion Kryeziu- Market Mara	\N
1191	125864	ERION TAULANT SH.P.K.	\N
1192	002196	ERIONI DPT - Guragoc- Istog	\N
1193	003416	ERJONA DPT- GJAKOVE	\N
1194	126095	ERSON BABA SH.P.K.	\N
1196	005898	ES MARKET DPT - FUSHE KOSOVE	\N
1197	013666	Esat A. Bytyqi B.I.-Kalabria Bistro & B	\N
1198	012941	Eshref Haskaj B.I.-Deçan	\N
1199	013380	ESPO MARKET SH.P.K.-Kaqanik	\N
1200	126357	Estrada D'or SH.P.K.	\N
1201	000007	ETC SHPK	\N
1202	006588	EURO - CO NTP - Prishtine	\N
1203	005837	EURO ALBI DPT- DUBRAVE-THERANDE	\N
1204	125983	Euro Alkos Group SH.P.K.	\N
1205	002215	EURO COM - Prishtine	\N
1206	002214	EURO COM NTP - Miresh Gjilan	\N
1207	000008	EURO FOOD SHPK- PRIZREN	\N
1208	005815	EURO LIRI NTP - DRAGASH	\N
1209	002217	EURO MARKET NTP- Lupç i poshtem -Besiane	\N
1210	003127	EURO MARKETI 1 - Prizren	\N
1211	003128	EURO MAX - Taslixhe	\N
1213	010947	Euro Max Market SH.P.K.-Prishtinë	\N
1214	010027	Euro Max Plus  SH.P.K.-Prishtinë	\N
1215	012372	Euro Mili Petrol SH.P.K.-Prishtinë	\N
1216	003330	EURO MIT SHPK - FERIZAJ	\N
1217	995544	EURO PARK PISHINE((P.Heqimi) - ZLLAKUQAN	\N
1218	126085	EURO TEAM D.O.O.	\N
1219	005233	EURO TRADE - E SH.P.K - PRISHTINE	\N
1220	012376	EuroAmarket Group SH.P.K.-Prishtinë	\N
1221	125824	EUROFRUITS LONI SH.P.K.	\N
1222	012006	EUROJON SH.P.K.-Arllat Gllogoc	\N
1223	013477	Euroland Global L.L.C.-Prishtinë	\N
1224	012415	Euromax Pro SH.P.K.-Prishtinë	\N
1225	126399	Europa Junior	\N
1226	008302	EUROTEC - SH.P.K	\N
1227	011273	EUROTEC SH.P.K.-Gjilan	\N
1228	012775	Euvision N.H.(Fox Bar)	\N
1229	126315	Eva's Brew and Bites L.L.C.	\N
1230	126566	EVL HOLDING SH.P.K.	\N
1231	005767	EVROPA 92-1 - Ferizaj	\N
1115	006300	ELECTRON NTP - THERANDE	\N
1116	012545	ELECTRONI SH.P.K.-Suharekë	\N
1118	125789	ELEKTRA L.L.C.-Hani i Elezit	\N
1119	125763	Elen Energy L.L.C.-\tPrishtinë	\N
1120	125720	ELEON MOTEL 1 D.O.O.-Shtërpcë	\N
1121	002119	ELI AB  SHPK - Ferizaj	\N
1122	005920	ELIDA EMBELTORE SHPK - FERIZAJ	\N
1123	002127	ELIRA MARKET - Ferizaj	\N
1124	002125	ELIRA MARKET NTP - Shtime	\N
1125	002129	ELITA  1 - Kline	\N
1126	012883	Elite Pharm SH.P.K.-Gjakovë	\N
1127	125817	Ellie Bistro L.L.C.	\N
1128	126356	Ellie Coffe RRB L.L.C.	\N
1129	009419	ELLIE Coffe SHPK-Prishtine	\N
1130	126018	Ellie Coffee and more L.L.C.	\N
1131	013315	ELLIE GROUP SH.P.K. - Graçanicë	\N
1132	009001	Ellie O.P.-Graçanicë	\N
1133	010225	ELLIS SHPK-Prishtine	\N
1134	009782	ELSA E DPT-Prishtinë	\N
1135	002136	ELSA NT- Gjakove	\N
1137	002144	EMA D.T.- Lubizhde - Prizren	\N
1138	125951	EMA MARKET 2024 SH.P.K.	\N
1139	010651	EMA MARKET SH.P.K.-Lipjan	\N
1140	125700	EMBELSIRA HOMEMADE TE BLERTA SH.P.K.	\N
1141	010062	Emina Abazi B.I.(Miri Pharm)-Prishtine	\N
1142	002150	EMIRA - SH NTP - Prishtine	\N
1143	002153	EMONA CENTER SHPK	\N
1144	012583	Emporium Free Shop SH.P.K.	\N
1145	125715	EMS Market SH.P.K.-Pejë	\N
1274	002256	FATI PHARM - Peje	\N
1275	002261	FATI-G N.T.-Peje	\N
1276	126171	Fatima Xhakli B.I.	\N
1278	002263	FATLINDI - Budrige	\N
1277	013746	Fatime Mazreku B.I.-Prizren	\N
1279	126319	Fatlum F. Gashi B.I.	\N
1280	126212	Fatlum H. Mehmeti B.I.	\N
1282	005056	FATONI -1 NTSH- BELLACERK	\N
1283	005152	FATONI RESTAURANT - FERIZAJ	\N
1281	126181	Faton H. Jashari B.I.	\N
1284	013430	FAVE GROUP SH.P.K.-Pejë	\N
1285	126412	Fazli Maroshi B.I.	\N
1288	009400	FELLAS SH.P.K.	\N
1290	002277	FELLINI NTP(RASIM BERISHA) - Prishtine	\N
1291	002278	FEMI MARKETSH.T.P.- Koretin- Kamenic	\N
1293	126116	FENIX VE 02 SH.P.K.	\N
1294	004864	FER PETROL N.T. - KOMORAN	\N
1295	010729	FERDI SOFTA & ORTAKU O.P.-Prizren	\N
1305	100349	FIDANISHTJA  NTP - SEFEDIN	\N
1306	002297	FIENTI NTP - Fushe Kosove	\N
1307	125892	Fifloar SH.P.K.	\N
1308	013701	FIKA CAFE L.L.C.-Prishtinë	\N
1309	126230	FILIGRAN ALBAN ISMAILI SH.P.K.-Prishtinë	\N
1310	013825	FinCrest L.L.C.-Prishtinë	\N
1311	013508	FINN OIL PETROL SH.P.K.-Mitrovicë	\N
1312	126261	Firaja N.T.P	\N
1313	012338	First Market SH.P.K.-Prishtinë	\N
1314	011083	Fish House SH.P.K.-Shtërpcë	\N
1315	012772	Fisnik Hana B.I.	\N
1316	002305	FISNIKU - Lypjan	\N
1317	002306	FISNIKU  MARKET DPT - Vushtrri	\N
1318	003573	FISNIKU NTP - LYPJAN	\N
1319	005370	FIT IN GYM SHPK - PRISHTINE	\N
1320	005877	FITA DPT   - Kline e Eperme	\N
1321	006934	FITA MARKET DPH-BESIANE	\N
1322	002307	FITA N.P.- Shakovic- Besiane	\N
1323	007786	FITA SHPK-Shakovice Besiane	\N
1325	013032	Fitim M. Bekteshi B.I.-Prizren	\N
1326	005356	Fitim Z. Osmanaj B.I.	\N
1327	005118	FITIMI MARKET - CARRALEVE	\N
1328	013811	Fitore Futko B.I.-Prizren	\N
1329	012308	Fitore Leci Kika B.I.	\N
1330	003743	FITORJA  SHPK - FERIZAJ	\N
1331	012824	FLAG Auto Parking Larje Siguri SH.P.K.	\N
1332	002018	Flamur Beqiri B.I. DRENI NTP TREG - Pris	\N
1333	005091	Flamur Beqiri B.I. DRENI TREG NTP - PRIS	\N
1334	012722	Flamur Gola B.I.- Ura Restaurant-GJK	\N
1335	009620	FLAMUR JASHARI B.I.- FRESH MARKET RID-Ma	\N
1336	009561	Flamur Javori B.I.- FRESH MARKET RID-Ma	\N
1337	013622	FLAMURI 1999 SH.P.K.- Prizren	\N
1338	013592	FLETA MARKET SH.P.K.- Babush, Gadime	\N
1339	012519	FLEX GYM SH.P.K.-Prishtinë	\N
1341	009013	FLOKQI NTP(B.Muharremi)-Ferizaj	\N
1342	002327	FLORA DPT - Mitrovice	\N
1343	002324	FLORA DPT-Mitrovice	\N
1344	002328	Flora- NTSH -  Malisheve	\N
1345	000009	FLORENTI NPT- MITROVIC	\N
1346	003473	FLORI - DRENAS	\N
1347	012386	Florije Bucolli B.I.( Bucolli)-Gllogoc	\N
1348	002333	FLORIKOS N.P.T - Burim- Istog	\N
1349	005131	FLORIKOS NTP - ISTOG	\N
1233	004821	EX FIS SHPK	\N
1235	013642	EXPRESS MARKET DIART SH.P.K.-Gjilan	\N
1236	125876	Express Market Shop SH.P.K.	\N
1237	009257	Express Store SH.P.K-Peje.	\N
1238	013657	Express04 Food&Coffee SH.P.K.-Prizren	\N
1239	009814	EXTRA FISH SHPK-Fushe Kosove	\N
1240	002235	EXTRA MARKET  - Prishtine	\N
1241	002234	EXTRA MARKET - Gjakove	\N
1242	012049	Extra Markett Blerti SH.P.K.-Ferizaj	\N
1243	002707	EXTREME PIZZA - Prishtine	\N
1244	012387	Ezo Rifati B.I.(Hasan Market)-Prizren	\N
1245	125856	F Code500 SH.P.K.	\N
1246	002774	FA COM SHPK - Dobrushe - Istog	\N
1247	012499	FAAN MARKET-Gjakovë	\N
1248	126376	FABS INTERNATIONAL L.L.C.	\N
1249	003990	FADI - Barileve	\N
1251	012391	FAM MARKET SH.P.K.-Ferizaj	\N
1252	005177	FAMILY AGUSHOLLI NPT- PEJE	\N
1253	002242	FAMILY DPT - Bardh i Madhe- Fushe Kosove	\N
1254	009237	FAMILY DPZ-Prizeren	\N
1255	126365	Family Dyner & Pizza	\N
1256	013680	FAMILY MARKET BSM SH.P.K.-Pejë	\N
1263	002245	FARM VET BARNAT. - Viti	\N
1264	013656	Fasa Bajrami B.I.-Prizren	\N
1265	126348	Fast Food  Beni D.p.h.	\N
1266	126507	Fast Food And Pasticceria Seven Shpk	\N
1267	011197	FAST SHOP MARKET-Prizren	\N
1268	002254	FATI - Kastriot	\N
1273	004930	FATI MARKET DPT - FERIZAJ	\N
1272	005321	FATI MARKET DPT - FERIZAJ	\N
1286	012594	Feha 2000 SH.P.K.-Lipjan	\N
1287	002275	FEKLA - Peje	\N
1292	013045	FEMIS COSMETICS SH.P.K.-Fushë Kosovë	\N
1296	100156	FESHGROUP L.L.C.	\N
1297	013041	FESI CENTER SH.P.K.-Mitrovicë Veriore	\N
1298	007331	FESI DEPO - Mitrovice	\N
1299	002647	FESTA - Pograxhe-Gjilane	\N
1300	010403	Festina Qufaj B.I.-Deçan	\N
1301	009190	FFS MARKET-Hajvali	\N
1302	010577	Fidan Fejza B.I.-Gjakovë	\N
1304	002295	FIDANISHTE-G DPT - Peje	\N
1384	009657	Free Stop Market SH.P.K.-Prishtinë	\N
1385	012482	Free Stop Tobacco SH.P.K.-Prishtinë	\N
1386	125960	FreeBase SH.P.K.	\N
1387	126052	FREESHOP DAR SH.P.K.	\N
1388	022152	FREESHOP DPT BOSSI - Ferizaj	\N
1389	125968	Freeshop KEKO SH.P.K.	\N
1390	125958	FRESCO EXCLUSIVE SH.P.K.	\N
1391	012985	Fresh Fruits 005 SH.P.K.-Ferizaj	\N
1392	126038	FRESH LOOK AESTHETICS L.L.C.	\N
1393	007060	FRESH MARKET 2 SH.P.K.-PEJE	\N
1395	006608	FRESH MARKET NTP -Kaqanik	\N
1396	010515	FRESH MARKET-Lipjan	\N
1397	009598	Fresh Mondi Sh.p.k	\N
1398	012506	Fresh Shop Store SH.P.K.-Lipjan	\N
1399	125978	Fresh Stop SH.P.K.	\N
1400	126228	Fresh&Fast SH.P.K.	\N
1401	011172	FRESH.MARKET BM SH.P.K.-Klinë	\N
1402	004969	FRESHI SHPK - PEJE	\N
1403	002351	FRESKIA -02 SHPK- Rr.Germise,Prishtine	\N
1404	126501	Freskia A.D   Armend Delijaj BI	\N
1405	004101	FRESKIA NPH- PRISHTINE	\N
1406	007500	FRIENDS AVENU SHPK-Prishtine	\N
1407	126151	Frisso Fry SH.P.K.	\N
1408	009558	FRIX L.L.C.-Prishtine	\N
1409	126439	Fron Bar AA Shpk	\N
1410	002359	FRUCTAL N.T 3(Xh.Bytyqi) - Prizren	\N
1411	008349	FRUITS MARKET SHPK-Prishtinë	\N
1412	012031	FRUKTAL GROUP SH.P.K.-Ferizaj	\N
1413	007433	FRUTARIA SHPK-Ferizaj	\N
1414	125831	FRUTELLA L.L.C.	\N
1415	126549	Frutex SH.P.K.	\N
1416	002363	FRUTI GB - Gramaqel -Deqane	\N
1418	002365	FRUTIN COMPANI SHPK - Prishtine	\N
1419	007439	FTONI NTP-Peje	\N
1420	006239	FUAD - AS- U.P - Prizren	\N
1421	013478	Fuat Shabani B.I.-Market Narti 2017	\N
1422	126561	Furra ARBRI SH.P.K.	\N
1423	126239	FURRA AROMA DDD 3	\N
1424	010368	Furra Artizzan SH.P.K.-Prishtinë	\N
1425	126193	Furra Çollaku DPZ - Kadri Çollaku B.I.	\N
1426	126215	Furra DUKAGJINI	\N
1427	126383	Furra e Bukes Aroma  2	\N
1428	126351	Furra e Bukes Edi D.p.z.	\N
1429	126483	Furra e bukës FLAMURI SH.P.K.	\N
1430	126388	Furra e Bukës GRANITI A SH.P.K.	\N
1431	126164	FURRA E BUKES ZAGREBI SH.P.K.	\N
1432	126547	Furra ETIKA SH.P.K.	\N
1433	126248	FURRA EVROPA AO	\N
1434	012571	FURRA FRESKIA SH.P.K.	\N
1435	126435	Furra KAPESHNICA SH.P.K.	\N
1436	013054	Furra Korabi SH.P.K.-Ferizaj	\N
1438	126489	Furra MANI D.Q. SH.P.K.	\N
1439	126209	Furra OREX DARDANIA SH.P.K.	\N
1440	126529	Furra OREX Shpk	\N
1441	126564	Furra Palma 2024	\N
1442	007915	Furra Parajsa	\N
1443	126445	FURRA PICERIA GOLDEN BAKERY SH.P.K.	\N
1444	126384	Furra Pizzeria  Tradita	\N
1445	126312	Furra Pizzeria Aroma SH.P.K.	\N
1446	126244	Furra Pizzeria Festimi SH.P.K.	\N
1447	126442	Furra Pizzeria Xerxa  Rrustem Sefsalihu	\N
1448	012863	FURRA PLUS	\N
1449	126441	Furra Prizereni KF Shpk	\N
1450	004981	FURRA QERIMI 2 DPZ - PRISHTINE	\N
1451	126552	Furra QERIMI 4 SH.P.K.	\N
1452	126538	Furra SALA 1a SH.P.K.	\N
1453	126408	Furra Theranda	\N
1455	126223	Furrë Buke Shekulli ABC SH.P.K.	\N
1456	126413	FURRË BUKE TONI SH.P.K.	\N
1457	002370	G - DEMA DPT - Prizren	\N
1458	013715	G Fructal Shop SH.P.K.-Suharekë	\N
1459	013450	G3 OIL SH.P.K.-Mitrovicë	\N
1460	002371	GACAFERRI - Junik	\N
1461	005957	GANI COMERC NTP - GADIME E EPËRME	\N
1462	007447	Ganimete Istrefi B.I -Vushtri	\N
1463	012854	GARDE L.L.C.-Pejë	\N
1464	006039	Garden Shpk	\N
1465	002382	GASHI Commerc NTP TREG - Prizren	\N
1466	007028	GASHI DPT-Lozice Malisheve	\N
1467	002380	GASHI NTP - Kieve	\N
1351	125830	Flux Market SH.P.K.	\N
1352	009049	FOB LTD SHPK-Prishtinë	\N
1354	002339	FONTANA  - Ulpiane - Prishtine	\N
1355	126242	Fontana Bar SH.P.K.	\N
1356	126523	FOOD AND MORE N11 LOUNGE SH.P.K.	\N
1357	009313	FOOD HOUSE SHPK-Prizeren	\N
1358	126359	FOX BAR SH.P.K.	\N
1359	007376	FRATELO TRADE P.P.-Graqanice	\N
1360	126263	Free Shop & Bar coffe Malmo	\N
1362	002346	FREE SHOP A-Prishtine	\N
1363	013012	FREE SHOP DEA.Since 2022 SH.P.K.	\N
1364	009675	FREE SHOP DEA-Fushë Kosovë	\N
1365	125804	Free Shop Extra SH.P.K.	\N
1366	012827	FREE SHOP GOLDEN SH.P.K.-Prishtinë	\N
1367	126537	Free Shop Jona ABC Shpk	\N
1368	125719	Free Shop JONI SH.P.K.-Fushë Kosovë	\N
1369	125976	Free Shop Loni SH.P.K.	\N
1370	013783	Free Shop M&Y SH.P.K.-Fushë Kosovë	\N
1371	126156	Free Shop MATINI SH.P.K.-Prishtinë	\N
1372	012884	FREE SHOP MOSSI-Prishtinë	\N
1373	012933	Free SHOP Nesa SH.P.K.-Fushë Kosovë	\N
1374	010487	Free Shop OMERI-Mitrovicë	\N
1375	013433	Free Shop ORBI SH.P.K.-Suharekë	\N
1376	012357	FREE SHOP PRISHTINA 01 SH.P.K.	\N
1377	126474	Free Shop Qera Shpk	\N
1378	013329	Free Shop Roani-Prishtinë	\N
1379	126120	Free Shop RS SH.P.K.	\N
1381	126544	FREE SHOP TE ELLI SH.P.K.	\N
1382	126160	Free Shop XL SH.P.K.	\N
1383	126558	Free Shop Ylli Pr SH.P.K.	\N
1502	002423	GEZIMI- Gjilan	\N
1503	002424	GEZIMI- Kaqanik	\N
1504	002428	GEZIMI SHPK - Zheger- Gjilan	\N
1505	010924	Gili A SH.P.K.-Podujevë	\N
1506	002434	GIMI MARKET - Ferizaj	\N
1507	009120	GIMI NT(Burim Dekaj B.I,)-Istog	\N
1508	010239	GINGER Caffe SHPK-Podujeve	\N
1509	125787	GINO'S PIZZA L.L.C.	\N
1510	012446	GINO'S SH.P.K.	\N
1511	002435	GIZZI DPH - Prishtine	\N
1512	008801	GIZZI GRIL SHPK-Prishtine	\N
1513	012947	GIZZI SH.P.K.-Prishtinë	\N
1515	126226	Gjelltore Dukagjini-Elitë Shala B.I.	\N
1516	008427	Gjirafa inc.	\N
1517	005541	GLAVBOLGARSTROYAD BRANCH - KOSOVE	\N
1518	013496	GLLAREVA SH.P.K.-Klinë	\N
1519	007821	GLOBAL PARAJSA (ISUF MUSLIU)- Vushtrri	\N
1520	126444	Gluten Free LLC	\N
1521	008101	G-MARKET SHPK-PEJE	\N
1522	000849	GNTC Group  SH A	\N
1523	000832	GNTC HOTEL GORENJE- PRISHTINE	\N
1524	126405	GO Fast Market L.L.C.	\N
1525	013099	GO market(Prend Pnishi B.I.)-Gjakovë	\N
1526	012777	Go Rex Energy SH.P.K.-Prizren	\N
1527	008362	GOGAJ AG-Isuf Cacaj B.I.	\N
1528	011276	GOGAJ PHARM SH.P.K.	\N
1529	011328	GOGAJ SH.P.K.-Peje	\N
1530	008314	GOGAJ-AG SH.P.K	\N
1531	005001	GOLD GARDEN SHPK- PRISHTINE	\N
1532	000835	GOLD MARKET - Korotice- Drenas	\N
1533	009802	GOLD ROOM SHPK-Prishtine	\N
1535	012637	Golden Mix SH.P.K.-Mitrovicë	\N
1536	003153	GONA DPT-Prishtine	\N
1537	004005	GONI - FERIZAJ	\N
1538	003458	GONI 2 - FERIZAJ	\N
1539	000841	GONI COMERC SHPK - Prishtine	\N
1540	008983	GONI Comerce O.P.-Prishtinë	\N
1541	000843	GONI DPT - Besiane	\N
1542	000844	GONI DPT - Ferizaj	\N
1543	004749	GONI MARKET DPT - PRISHTINE	\N
1544	126424	GP Pupa Shpk	\N
1545	000850	GR ERIONA SHPK - Prishtine	\N
1546	012773	Grand Events L.L.C.	\N
1547	009423	GRAND HOUSE SH.P.K.	\N
1548	126061	Grand Restaurant and Lounge L.L.C.	\N
1549	007816	GRANIT CACAJ B.I.-Deçan	\N
1550	000855	GRANITI - Ferizaj	\N
1551	005042	GRANITI DPT - PRISHTINE Hajvali	\N
1553	012966	GREEN BAR SH.P.K.-Pejë	\N
1554	126249	Green Caffe & More SH.P.K.	\N
1555	126380	GREEN HEALTHY FOOD L.L.C.	\N
1556	126358	Green Lounge SH.P.K.	\N
1557	012983	GREEN OIL SH.P.K.-Ferizaj	\N
1558	006811	GREEN SALLAD 1-  Prishtine	\N
1559	013120	Green Shop ADO-Prizren	\N
1560	125852	Green Shop L.L.C.	\N
1561	010382	GREEN T SH.P.K.-Komoran	\N
1562	005146	GRESA - V  MARKET - PEJE	\N
1563	006570	GRESA LOUNGE RESTAURANT SHPK - Prishtine	\N
1564	004776	GRILL SARAJEVA  E-A  DPH - PRISHTINE	\N
1565	010056	Grill XXL SH.P.K.-Shtime	\N
1566	006648	GRINI DPT - Vushtrri	\N
1567	013686	Grosmarket L.L.C.-Prishtinë	\N
1568	005675	GRYKA SHPK - MALISHEVE	\N
1569	008133	GRYKA SHPK-Shtimje	\N
1570	012904	Grykaplus SH.P.K.-Shtime	\N
1571	012677	GTA SUPERMARKET SH.P.K.	\N
1572	011242	Guri 1992 SH.P.K.-Ferizaj	\N
1574	010357	Guri N market Shpk-Nikaj	\N
1575	000870	GURI NTP - Ferizaj	\N
1576	005472	GURI NTSH - STUDENÇAN	\N
1577	005019	GURI-N  N.T. - NIKAJ - KAÇANIK	\N
1578	126137	Guta Tradicional SH.P.K.	\N
1579	010950	HA SA SH.P.K.-Ferizaj	\N
1580	004794	HAJDARI CAFFE SHPK - PRISHTINE	\N
1581	000881	HAJDINI NTP(Musa Leku) - DRENAS	\N
1582	008968	HAJREDIN AGUSHI B.I.-Ferizaj	\N
1583	125878	Haki Spahiu B.I.-N.P.T. Albina	\N
1584	005687	HALF &HALF CAFE N.H. - PRISHTINE	\N
1585	000882	HALILI - Prizren	\N
1586	000884	HALITI CENTER - Kamenic	\N
1469	010913	GASHI Y SH.P.K.-Mitrovicë Veriore	\N
1471	011093	Gastroteca REPUBLIKA SH.P.K.-Gjakovë	\N
1472	007200	GAZI DPT-Prishtine	\N
1473	002385	GAZI MARKET - Prishtine	\N
1474	008986	GAZMEND HYSENI B.I.(Korzo 1)-Vushtrri	\N
1475	125992	GECI SH.P.K.	\N
1476	002390	GEGA BARNAT.- Gjakove	\N
1477	011333	GEGË RESTAURANT SH.P.K.	\N
1478	125920	GELIAR Group SH.P.K.	\N
1480	126525	GEN STORE 25 SH.P.K.	\N
1481	002394	GENA NTP - Viti	\N
1482	002395	GENCI - Gjonaj- Prizren	\N
1483	002397	GENCI DPT - Mitrovice	\N
1484	013023	GENI MARKET SH.P.K.-Prishtinë	\N
1485	013679	Genis Kaqi B.I.-Gjakovë	\N
1486	125796	GENTA MARKET ab SH.P.K.	\N
1487	004702	GENTI SHPK- PRIZREN	\N
1488	007216	GENTIAN RAMA Genti B.I.-Hajvali	\N
1489	125985	Gentiana S. Zymberi B.I.	\N
1490	010701	GËRGURI SH.P.K.(Villa Natyra)-Prishtine	\N
1491	008959	GERMAN HOUSE LLC-Prizeren	\N
1492	006569	GERMOVA - GG Dpt - Mitrovice	\N
1493	012036	GERMOVA FRESH SH.P.K.-Mitrovicë	\N
1494	012907	Gerti Halilabazi B.I.(Market GERTI)	\N
1495	011180	GES TRADE L.L.C.-Gjilan	\N
1496	007693	GESSI MARKET SHPK - PRISHTINE	\N
1497	005284	GETI MARKET DPT - MITROVICE	\N
1498	002808	GETI SHPK - Gjilan	\N
1500	004647	GETUARI DD - Krushe e Vogel -Prizeren	\N
1501	002427	GEZIMI D.P.T. - BESI	\N
1620	000905	HERTA SHPK - Fushe Kosove	\N
1621	125632	HIB PETROL	\N
1622	012596	HIB Petrol Corporation SH.P.K.	\N
1623	002148	HIB PETROL SHPK	\N
1624	010298	HIB Restaurantet SH.P.K.	\N
1625	009350	HIDAJETE HAMZA B.I.-Rahovec	\N
1626	000909	HIDO NTP - Rahovec	\N
1627	125799	Hija e Maleve SH.P.K.	\N
1628	012083	HILLSTONE RESTAURANT SH.P.K.	\N
1629	012801	Hilton's Restaurant SH.P.K.	\N
1630	000910	HIMI - Bllac Therande	\N
1631	009041	HIRA MARKET SHPK-Prishtine	\N
1632	012930	Hivzi Sadiku B.I.-Mitrovicë	\N
1633	010497	HOFFMAN Stores SH.P.K.-Prishtinë	\N
1634	011140	HOLIDAY RESORT SH.P.K.-Pejë	\N
1635	008320	HOLLYWOOD-R SHPK-Gjilan	\N
1636	012045	Home Veterinaria SH.P.K.-Gjilan	\N
1637	125727	Horizonti 1974 SH.P.K.-Klinë	\N
1638	013784	HOT BOX SH.P.K.-Gllogoc	\N
1639	126274	HOTEL ALLEGRA SH.P.K.	\N
1640	125955	Hotel DARDANI SH.P.K.	\N
1641	005891	HOTEL DUKAGJINI SHPK - PEJE	\N
1643	010092	Hotel International Prishtina-Prishtine	\N
1644	004160	HOTEL LORD - PRISHTINE	\N
1645	002729	HOTEL SIRIUS - B.NTH - Prishtine	\N
1646	126391	HOTEL URA E GURIT SH.P.K.	\N
1647	009025	HOUSE 44 SH.P.K	\N
1648	005822	HUMOLLI PETROL NPT - LUPÇE I POSHTEM	\N
1649	004803	HYSI DPT - MITROVICE	\N
1650	009312	HYSKA DPH-Prizeren	\N
1651	126517	Iba Burger D.p.h.	\N
1652	011274	IBO MARKET SH.P.K.-Podujevë	\N
1653	011235	IBOS IDJ SH.P.K.-Istog	\N
1654	000932	IBRAHIMI TREG - Prizren	\N
1655	006153	IDEA MARKET SHPK -Poturovc - Lipjane	\N
1656	000937	IDEAL CENTER 3 - Peje	\N
1657	003726	IDEAL CENTER SHPK - PEJE	\N
1658	000936	IDEAL MARKET NT- Prizren	\N
1659	006808	IDEAL PHARM SHPK - Gjakove	\N
1661	126326	Ideoma Sh.p.k.	\N
1662	009273	IDRIZ MALOKU(Ariu) B.I.-Ferizaj	\N
1663	012844	IFFI'S SH.P.K.-Fushe Kosove	\N
1664	013604	Igballe Potera B.I.-MARKET GON-Podujevë	\N
1665	012771	Ikonë Lounge SH.P.K.	\N
1666	012541	IL GUSTO LOUNGE BAR BRASSERIE SH.P.K.	\N
1667	009403	IL GUSTO Ristorante Italiano SHPK-Feriza	\N
1668	013615	ILidi's Fresh Store SH.P.K.-Prizren	\N
1669	012490	Ilir I. Sadrija B.I.(Ing Market)-B.Bokes	\N
1670	006274	ILIRI DPT - Prishtine	\N
1671	000941	ILIRI DPT - Zhabar - Mitrovice	\N
1672	125890	ILIRI MARKET QRR SH.P.K.	\N
1673	004706	ILIRI NTP-PRISHTINE	\N
1674	000948	ILIRIA -1  DPT - Mitrovice	\N
1675	008569	ILIRIA COSMETICS 1 Shpk	\N
1676	000947	ILIRIA N.N.T. - Vushtrri	\N
1677	000949	ILIRIA N.SH.H -Deqan	\N
1678	011023	ILIRIJA - A.K. SH.P.K.	\N
1679	126461	Ilirjan Shabanaj B.I.	\N
1680	012724	ILLARIOO'S CAFFE SH.P.K.	\N
1681	005392	IN CAFFE  - FERIZAJ	\N
1683	012788	IN MARKET-Hani i Elezit	\N
1684	125891	IN Petrol SH.P.K.	\N
1685	007156	INDRITI AMBULLANCA VETERINARE-Ferizaj	\N
1686	000957	INFINIT DEPO SHPK - Prizren	\N
1687	012451	Infinit Food & Drinks SH.P.K.-Prishtinë	\N
1688	013509	Infinit Network SH.P.K- Kijeve-Malishevë	\N
1689	012855	INOX 90 L.L.C.-Gjakovë	\N
1690	126574	INSTANBOLL EFECAN DONER CAFE SH.P.K.	\N
1691	012902	Intercoop L.L.C.-Pejë	\N
1692	008309	INTERDISKONT GROUP-Shpk Kamenice	\N
1693	012825	Intern Investment Group SH.P.K.-Pejë	\N
1694	005341	IP KOS PETROL SHPK	\N
1695	126042	Irena Milisavljevic I.B.(JACI MARKET)	\N
1696	125925	Irfan G. Mjeku B.I.	\N
1697	010594	Isa market-Mitrovice	\N
1698	007525	ISA ZEQIRI B.I.-Gjilan	\N
1699	000972	ISMA - E  Rahovec SHPK	\N
1701	007311	ISMIR AJVAZI-Livoq Gjilan	\N
1702	126147	Isni Likaj B.I.	\N
1588	012900	Hamari AgroTurizëm L.L.C.-Prishtinë	\N
1589	013502	HAMBURGER ABA SH.P.K.-Prishtinë	\N
1590	000885	HAMRA - Prizren	\N
1591	126450	HAN TAVERNA SH.P.K.	\N
1592	000886	HANA - Dardani - Prishtine	\N
1593	126531	Hana Free Shop 24 Shpk	\N
1594	012340	HANA MARKET ARB SH.P.K.-Kamenicë	\N
1595	126044	HANA SHOPING CENTER SH.P.K.	\N
1596	000892	HANI - Gjakove	\N
1597	004576	HANI NTP(Nazmije Kukaj) - TËRSTENIK	\N
1598	004478	Hapiterija Manifakturë SH.P.K.	\N
1599	008396	HAPPY DAYS 2  D.O.O.	\N
1601	126471	Hardrockway L.L.C.	\N
1602	000894	HAREA - Rahovec	\N
1603	007101	HAREA NTH - THERANDE	\N
1604	012629	HAS 4 SH.P.K.-Pejë	\N
1605	000897	HASANI SHPK - Stanovc	\N
1606	013756	Hash Group SH.P.K.-Prishtinë	\N
1607	007268	HASIM DEMIRI B.I.-Novoberd	\N
1608	125736	Hatixhe Balaj B.I.-Istog	\N
1609	007505	HATIXHE GASHI B.I.(market Fidani)-Drenas	\N
1610	126420	Hava Imeri B.I.	\N
1611	008775	HAXHERE SVARÇA B.I.-Gllogoc	\N
1612	012484	HC STORE SH.P.K.-Gllogoc	\N
1613	011183	HEALTHSOME SH.P.K.-Prishtinë	\N
1614	013611	HEALTHY MANGO SH.P.K.-Fushë Kosovë	\N
1615	010967	HEGE STEAKHOUSE SH.P.K.-Ferizaj	\N
1616	007491	HELLO MARKET DPT - Peje	\N
1618	126247	HERTA CENTER SH.P.K.	\N
1619	009443	Herta Kids SH.P.K - RESTAURANT ORTA	\N
1737	005812	JONI MARKET DPT - MAZGIT	\N
1739	009633	JONI SHPK Supermarket-Obiliq	\N
1738	012498	JONI MARKET GROUP SH.P.K.-Ferizaj	\N
1741	007015	JORA CENTER SHPK-Llapushnik Gllogovc	\N
1740	012497	JoniALT SH.P.K.-Graçanicë	\N
1743	126155	JOURNAL Essence SH.P.K.	\N
1742	013659	Jora Market Fresh SH.P.K.-Ferizaj	\N
1745	012793	Jozefi SH.P.K.-Viti	\N
1746	001009	JUGO MARKET SHPK - Graqanice	\N
1747	010063	JUGODEPO D.O.O.-Graçanicë	\N
1744	003050	JOZEFI MARKET- STUBELL E EPERM	\N
1749	126305	Juvenilija D.p.h.-	\N
1751	126300	K MARIGONA KS SH.P.K.	\N
1752	004482	K&K BROTHERS L.L.C.-PIZZA HOUSE PR1	\N
1753	012626	KAAM Gjakova DT SH.P.K.-Gjakovë	\N
1754	126290	KADARE SH.P.K.	\N
1755	126099	Kafe Bar 501 D.P.H	\N
1748	126125	JUMBO PIZZA 2025 SH.P.K.	\N
1756	126172	Kafeinë SH.P.K.	\N
1757	126349	KAFJA   E   SABITIT   SH.P.K.	\N
1758	013714	Kafshate SH.P.K.-Prishtinë	\N
1759	008585	KAG OIL SHPK-Prizeren	\N
1760	126024	KaJon SH.P.K.	\N
1761	003392	Kalabria	\N
1762	001026	KALAJA  DPT - Vushtrri	\N
1763	001029	KAMEL -Rahovec	\N
1765	013745	KAN MARKET 2024 SH.P.K.-Gjakovë	\N
1766	007302	KAN SHPK KFC-Veternik Prishtine	\N
1767	126386	Kaqanik Balaj B.I.-Istog	\N
1768	001031	KARADAKU DPT - Zheger- Gjilan	\N
1769	001032	KARAXHA INVEST SHPK  - Prishtine	\N
1770	126019	KAS Distribution L.L.C.	\N
1771	013698	KAS MARKET SH.P.K.-Pejë	\N
1772	001033	KASALINDA-Vushtri	\N
1773	010889	KASTRATI CENTER SH.P.K.-Malishevë	\N
1774	001039	KASTRATI DEPO - Malisheve	\N
1775	012400	KASTRATI FASHION SH.P.K.-Prizren	\N
1776	006237	KASTRATI NTP - Buroje - Skenderaj	\N
1777	001042	KASTRATI NTP 2 - Prizren	\N
1778	001036	KASTRATI NTP- Buroj- Skenderaj	\N
1779	009218	KASTRATI STORE SH.P.K.-Malisheve	\N
1780	009156	Kastriot Javori B.I.-Malishevë	\N
1781	126045	KATRORI GROUP SH.P.K.	\N
1782	125994	KEA GROUP SH.P.K.	\N
1783	001047	KEIS PHARMACEUTICAL - Prishtine	\N
1784	012953	KEKA MED PHARMACY SH.P.K.-Klinë	\N
1785	001049	KELI A  SHPK- Peje	\N
1787	009450	KENZO DPT(H.Rugova)-Peje	\N
1788	013072	KEŠ 1976 D.O.O.-Leposaviq	\N
1789	013694	KGT SH.P.K.-Prishtinë	\N
1790	013096	KIDS CENTER SH.P.K.-Gjakovë	\N
1791	009528	Kids Galaxy SHPK-Prishtine	\N
1792	126485	Kids World SH.P.K.	\N
1793	125846	Kika's Coffee AAG SH.P.K.	\N
1794	126436	KIKXXL & Evrotarget LLC	\N
1795	009299	KINGJI DPH-Ferizaj	\N
1796	008818	KINO BAR SHPK(4stinet village)-Ferizaj	\N
1797	013413	Kino Plus SH.P.K.(CACAO)-Gjakovë	\N
1798	011412	KIPPER MARKET SH.P.K.-Lipjan	\N
1799	126131	Kisha Katolik	\N
1800	012494	Kitara21 Lounge Bar SH.P.K.	\N
1801	001063	KIVI DPT- Prizren	\N
1802	005951	KIWI - 2 DPT - PRIZREN	\N
1803	002001	KIWI  DPT -  Shipol- Mitrovice	\N
1804	001064	KIWI - Kline	\N
1805	001061	KIWI DPT - Prizren	\N
1806	013526	Kjan SH.P.K.	\N
1807	011316	KLAN ARENA SHPK-Prishtine	\N
1809	008399	KLEA MARKET - 2 SH.P.K. - Gjakove	\N
1810	003958	KLEA MARKET DPT - GJAKOVE	\N
1811	126143	Klevi s lounge bar SH.P.K.	\N
1812	126003	Klodian Market SH.P.K.	\N
1813	004740	KOESTLIN D.D - BJELOVAR - HRVATSKA	\N
1815	013324	Koha Group SH.P.K.-Fushë Kosovë	\N
1816	125993	KOHA LOUNGE SH.P.K.	\N
1817	010801	KOHA LOUNGE SH.P.K.-Gjilan	\N
1818	125714	Kong Healthy Food And More SH.P.K.-Priz	\N
1819	125807	KONMAR SH.P.K.	\N
1820	010925	Kopiliqi SH.P.K.-Skenderaj	\N
1821	001082	KORABI - Gjakove	\N
1704	126347	Istanbul Premium	\N
1706	012341	Isuf Ahmetaj B.I.	\N
1708	012878	Ivan M. Trajkovic B.I.(ICA)-Vushtrri	\N
1709	010488	Ivan Trajkovic - ICA-Vushtrri	\N
1710	012465	Izi's Apartment SH.P.K.-Prishtinë	\N
1711	012399	Jack`s Place - Prishtinë	\N
1712	000977	JAFFA - Burim	\N
1713	009058	JAFFA 2 SHPK-Istog	\N
1714	125971	JAFFA BSO SH.P.K.	\N
1715	013462	JAJKI SH.P.K.-Lipjan	\N
1716	999033	JAMNICA PLUS D.O.O-Zagreb	\N
1717	008915	JARA PHARMACY SHPK	\N
1718	010098	Jarina SHPK-Peje	\N
1719	125701	Jaseri Pharm SH.P.K.-Gllogoc	\N
1720	009546	JAZI 1 SHPK-Rahovec	\N
1721	009996	JEHONA COM NTSH-Rahovec	\N
1722	012989	Jehona Nikqi B.I.(DIJARI BLEDI)-Pejë	\N
1723	004896	JETA - A MARKET NTP - PEJE	\N
1725	125821	JETA -A SH.P.K.	\N
1724	003522	JETA - A MARKET NTP - PEJE	\N
1727	013547	Jetmir Badalli B.I.-Prizren	\N
1726	004360	JETA SHPK	\N
1728	126556	Jetmir Dakaj B.I.	\N
1729	010046	Jeton I. Mehmeti B.I.	\N
1730	003385	JETONI - SMERKOVNICE	\N
1732	125724	JKPR 2024 Eatery SH.P.K.-Prishtinë	\N
1733	008921	JOES CAFFE SHPK-Fushë Kosovë	\N
1734	012584	Jona Market SH.P.K.	\N
1735	006524	JONI - A NTP - Ferizaj	\N
1736	126140	Joni Alpha L.L.C.-Fushë Kosovë	\N
1855	005089	KUSHTRIMI& B SHPK- PRISHTINE	\N
1856	013561	KUZHINA E DJALIT SH.P.K.-Klinë	\N
1857	013693	Kuzhina e Jusufit L.L.C.-Prishtinë	\N
1859	010235	L&D Corp SH.P.K.-Prizren	\N
1860	012062	La Boheme (OPERA Lounge SH.P.K.)	\N
1861	012726	La Bohem-Peje	\N
1862	011056	LA CORTE SH.P.K.	\N
1863	126175	LA NAPOLETANA SH.P.K.	\N
1864	008800	La Resto SH.P.K.	\N
1865	007781	LA STRADA BAR SHPK-Prishtine	\N
1866	001126	LAB COM DPT  - Therande	\N
1867	000134	LAB COM NTSH - Therande	\N
1868	008892	Labi - Petrol N.T.P.	\N
1869	002776	LABI & GESA DPT - Mitrovice	\N
1870	006203	LABI AS DPT - Lipjan	\N
1871	001133	LABI DPT - Fushe Kosove	\N
1872	005773	LABI KIOSK DPT-  THERANDE	\N
1873	001127	LABI NTP - Dardane - Kamenice	\N
1874	001130	Labinot A. Ahmeti B.I.	\N
1875	126087	Labinot Aliu B.I.-Pablo	\N
1876	126251	LABINOTI-AS SH.P.K.	\N
1877	008875	LABI-Petrol NTP Therande	\N
1878	007822	LAB-OIL SHPK-Preoc Graqanice	\N
1880	013363	LAGOM SH.P.K.-Mitrovicë	\N
1881	125766	Laki Pharm SH.P.K.-Kaçanik	\N
1882	003090	LAMI NTH - THERANDE	\N
1883	008941	LANDI NTP-Rahovec	\N
1884	013390	LANDI STAR GROUP SH.P.K.-Gjakovë	\N
1885	012076	LANDI STAR RSH SH.P.K.-Gjakovë	\N
1886	009158	LANDI STAR SHPK-Gjakove	\N
1887	003506	LANIKA DPT - HAJVALI - PRISHTINE	\N
1888	126073	Lanika EG SH.P.K.	\N
1889	001141	LANKA DPT - Peje	\N
1890	012342	LANKA DPT-Vitomerice	\N
1891	022123	LANTI BESA NTP - Kamenice	\N
1892	012898	LATA HAS SH.P.K.-Prishtinë	\N
1893	001146	LATI NTP -  KAÇANIK	\N
1894	007493	LAURETA HUSAJ B.I- Peje	\N
1895	001148	LAURITI - Ferizaj	\N
1896	125902	Lauriti Fresh SH.P.K.	\N
1897	125801	Lavda BG 1 SH.P.K.	\N
1899	007073	LAVDIM ASLLANI B.I.-Emshir Prishtine	\N
1900	126426	LE SANDWICH SH.P.K.	\N
1901	125887	Lea Express Market SH.P.K.	\N
1902	012012	LEAR MARKET SH.P.K.-Gjilan	\N
1903	011334	LEARTI FK SH.P.K.	\N
1904	006088	LEDRI DPT - Drenas	\N
1905	126502	Ledri-G Shpk	\N
1906	126150	LEJLANIL FASTFOOD SH.P.K.	\N
1907	013325	Lejza Bio Restaurant SH.P.K.-F.Kosove	\N
1908	009571	Lemon Tree LOUNGE SHPK-Prishtine	\N
1909	005372	LENDI MARKET N.T. - Livoq - Gjilan	\N
1910	013627	Lendita Bytyqi B.I.-Prizren	\N
1911	009215	LENDITA TUNAJ B.I.-Kline	\N
1912	013844	Lendrit Kokollari B.I.-Prishtinë	\N
1913	010099	LENOMA SHPK-Ferizaj	\N
1914	001162	LENTI E MARKET- Mitrovice	\N
1915	126064	Lenti F JEA SH.P.K.	\N
1916	005527	LENTI NTP - BESIANE	\N
1918	013754	Lenti Zan SH.P.K.-Ferizaj	\N
1919	010042	LENTIL FOODS SH.P.K.	\N
1920	125758	Leo Z Group SH.P.K.-Pejë	\N
1921	001166	LEONDI - Vushtrri	\N
1922	126117	LEONI AGE	\N
1923	125943	Leoni Kas SH.P.K.	\N
1924	009958	Leoni Market 2 LOI SHPK-Prishtine	\N
1925	010064	Leoni Market(Zarife Muriqi B.I.)-Pejë	\N
1926	006263	LEONIDA SHPK - Prishtine	\N
1927	012867	Leotrim Gashi B.I.-Suharekë	\N
1928	011286	Leutrimi DPT-Rahovec	\N
1929	001173	LEUTRIMI SHPK - Rahovec	\N
1930	001177	LFHS MARKET DPT - Sllatine- F.Kosove	\N
1931	010432	LID Market SH.P.K-Prizren	\N
1932	010609	LIDER MARKET SH.P.K.-Gllogoc	\N
1933	006905	LIJON SHPK-SHIROKE	\N
1934	012013	LIKA Market-Ferizaj	\N
1936	013015	LILY'S CAFE AND RESTAURANT SH.P.K.	\N
1937	001185	LIMI COM - Kieve	\N
1938	006376	LIMI DPT - Gjinoc - Therande	\N
1939	126057	LIMI SHOP SH.P.K.	\N
1940	012648	LINA COMPANY L.L.C- Zheger -Gjilan	\N
1941	003574	LINDA DPT-THERANDE	\N
1942	004670	LINDA MARKET NTP - POLAC	\N
1824	007934	KORAL DAIRY SHPK-Fushe Kosove	\N
1825	005087	KOSHARJA DPT - GJAKOVE	\N
1826	001090	KOSOVA  Sh.P.K- Gjakove	\N
1827	126341	Kosova Appetit Sh.p.k.	\N
1828	001092	KOSOVA MARKET NTP - Mitrovice	\N
1829	011034	KOSOVA TRADE SH.P.K.-Lipjan	\N
1830	001095	KOSOVARI DPT - GJAKOVE	\N
1831	013555	KOZMETIKA LONDON 2012 SH.P.K-Vushtrri	\N
1832	008855	Kozmetike Gjermane	\N
1833	005794	KRAS MARKET DPT - PRIZREN	\N
1834	006863	KRESHNIK LUKAJ B.I.	\N
1835	009275	Kristal Palace SHPK-Prizeren	\N
1836	008912	KRISTIAN KOSHI B.I.-Prizeren	\N
1837	009361	KROJET HOTEL SHPK-Prevallle	\N
1838	125867	KRONI CENTER SH.P.K.	\N
1840	001107	KRONI DPT Bresje (Arsim Mjeku)-F.Kosove	\N
1842	126499	KRONI SH.P.K.	\N
1843	126017	KRUDO FR SH.P.K.	\N
1844	004149	KRUJA DPT - DRENAS	\N
1845	010632	Kualiteti Të Arapi - I SH.P.K.-Pejë	\N
1846	001112	KUJTIMI NTP - Besi- Besiane	\N
1847	001115	KUKLI BEG COMMERCE - Prizren	\N
1848	125795	KUKLIBEGII 2024 SH.P.K.	\N
1849	009998	KULLA NTP-Xerxe	\N
1850	003186	Kunevikët 2020 SH.P.K.	\N
1851	011186	Kunevikët 2020 SH.P.K.-Prishtinë	\N
1852	126416	Kuqi N.p.sh	\N
1853	001118	KURBINI - Peje	\N
1854	008966	KURRIZI MARKET SHPK-Prishtine	\N
1976	009071	LM KUSHTRIMI SHPK-Prishtine	\N
1977	009184	LOCAL Bistro & Bar SH.P.K.-Prishtine	\N
1978	012095	Loft Bistro Bar SH.P.K.	\N
1979	006093	LOLI-1 Dpt - Podujeve	\N
1980	009554	LONG BAR SHPK-Lipjan	\N
1981	004851	LONI ASH DPT - MAZGIT	\N
1982	002457	LONI DPT - Fushe Kosove	\N
1983	013124	LONI Market Drenas SH.P.K.	\N
1984	010033	Loni Market(Albana Dvorani)-Terstenik	\N
1985	010294	LONI SHPT-Kaçanik	\N
1986	002464	LONI TRADE - Skenderaj	\N
1987	012098	LORD B Restaurant & Grill (Zojë Dakaj B)	\N
1988	010932	LORD`s 3 SH.P.K.-Prishtinë	\N
1989	012796	Lord's Lounge SH.P.K.	\N
1990	008887	LORIANO SHPK Prishtinë	\N
1991	002472	LORIKU- Malisheve	\N
1993	126077	Lounge Bar Aurum	\N
1994	012469	Lounge Bar TROJA 101 SH.P.K.	\N
1995	009046	LOUTE SHPK-Prishtine	\N
1996	126040	Louvard Lounge SH.P.K.-Prishtinë	\N
1997	125815	Love Bar SH.P.K.	\N
1998	012535	LU&AR Market-Malishevë	\N
1999	013420	Luan Buçinca B.I.(N.T.P."NIV")-Mitrovice	\N
2000	012579	LUANI ADI SH.P.K.-Pejë	\N
2001	006595	LUANI DPT - Drenas	\N
2002	008336	LUANI EG SHPK-Peje	\N
2003	012647	LUANI LLG SH.P.K.-Pejë	\N
2004	008504	LUANI MARKET SHPK-Pejë	\N
2005	002476	LUANI NT DEPO-PEJE	\N
2006	008886	LUANI-SG SHPK-Peje	\N
2007	006677	LUARI MARKET SHPK-Prishtinë	\N
2008	125863	LUCKY CAFE	\N
2010	013097	Luka Market(Tijana Lazic I.B.)-Lapnasell	\N
2011	005059	LUKAJ MARKET - PEJE	\N
2012	013469	Lule Sufaj B.I.-Restaurant DUBROVNIK HA	\N
2013	002488	LULI - Gjinoc- Therande	\N
2014	002491	LULI - Taslixhe - Prishtine	\N
2015	002492	LULI COM 1 - Kaqanik	\N
2016	002494	LULI DISKONT - Burim	\N
2017	006482	LULI SHPK PRISHTINE	\N
2018	005961	LULI STACION I AUTOBUSEVE	\N
2019	126475	Luljete Ahmetaj B.I.	\N
2020	006754	LULU `S COFFEE AND WINE	\N
2021	007408	LULZIM BRAHIMI B.I.-Mitrovice	\N
2022	126076	Lulzim H. Syla B.I.	\N
2023	006999	LULZIM S.HOTI B.I ROGOVE-Gjakove	\N
2025	004009	LUMA COMMERCE 2 - RAHOVEC	\N
2026	002502	LUMI - Te permendorja - Prishtine	\N
2027	002503	LUMI - Ulpiane - Prishtine	\N
2028	002890	LUMI 1 NTP  - Prishtine	\N
2029	002501	LUMI DPT - Prishtine	\N
2030	012842	Lumi Joni SH.P.K.-Prishtinë	\N
2031	002499	LUMI SHPK- Dardane	\N
2032	000838	Lumnije Svirca B.I.-Gona-S DPT-Prishtin	\N
2033	013816	Luna Coffe Bar L.L.C.-Fushë Kosovë	\N
2034	013762	Luna Hotel L.L.C.-Prizren	\N
2035	002507	LUNDRIMI DPT - Gjakove	\N
2036	012005	Lutfi A. Kelmendi B.I.( Trend Caffe )-Vu	\N
2037	126184	Luxor Pizza SH.P.K.	\N
2038	126132	LUXOR SH.P.K.	\N
2039	008499	LUXORY SH.P.K.	\N
2040	010608	LYBETENI GRILL SH.P.K.-Ferizaj	\N
2041	013753	LYS Cosmetics SH.P.K.-Prishtinë	\N
2042	005788	M & A DPT - GREIKOC	\N
2043	005444	M CITY NTP - FERIZAJ	\N
2045	005311	MAB PROJECT SHPK - VUSHTRRI	\N
2046	007729	MAGASHI DPT-Llugaxhi Lipjan	\N
2047	005959	MAGIC - A.D.DPT - Vitomerice	\N
2048	002513	MAGIC NPT - Peje	\N
2049	126190	Magic Square SH.P.K.	\N
2050	010389	MAGIC VD SH.P.K.-Pejë	\N
2051	012951	Magna Market SH.P.K.-Ferizaj	\N
2052	125947	MAGNOLIA GROUP SH.P.K.	\N
2053	007601	Mahije Mullaademi B.I.-Gjakovë	\N
2054	126082	Maison Restaurant SH.P.K.	\N
2055	126241	Maison Ysabel SH.P.K.	\N
2056	125980	MAJA HOLDING SH.P.K.	\N
2057	013480	Majlinda Duriqi B.I.(Donati 3 DPT)-Prish	\N
2058	005828	MAKE MARKET DPT - PRIZREN	\N
2059	011192	Make Market New SH.P.K.-Prizren	\N
2060	126051	MAKI & GOGI SH.P.K.	\N
2061	002517	MAKI VERBOVC - Viti	\N
1944	009595	LINDEN SHPK-Prishtine	\N
1945	001198	LINDI A H - Burim- Istog	\N
1946	126443	Lindi Albi Shpk	\N
1947	010384	LINDI Llozic-Malisheve	\N
1948	001204	LINDI MARKET - Greme Ferizaj	\N
1949	002733	LINDI MARKET DPT- Gadime	\N
1950	001207	LINDI NTP TREG - Prishtine	\N
1951	003714	LINDI PETROL N.T. - CARRALEVE	\N
1952	001208	LINDI PETROLL - Ferizaj	\N
1954	001211	LIPS CAFFE - Prishtine Sh.P.K	\N
1955	126121	Liqeni 24 SH.P.K.	\N
1956	008994	LIQENI DUKAGJIN SH.P.K.	\N
1957	126467	LIQENI SH.P.K.	\N
1958	002814	LIQENI-B - Ulpiane-Prishtine	\N
1959	013549	LIRA Mark L.L.C.-Ferizaj	\N
1960	006658	LIRIA NTP - Shtime	\N
1961	002759	LIRIDONI - RAHOVEC	\N
1962	001221	LIRIDONI HG-DPT Junik Kosove	\N
1963	126431	LIRIDONI MARKET SH.P.K.	\N
1964	001224	LIRIDONI N.T. - Peje	\N
1965	009857	LIRIDONI QT SHPK-Peje	\N
1966	009118	LIRIDONI Z D.P.T(Ardit Kuqi B.I.).-Decan	\N
1967	001231	LIRIMI SHPK - Gjilan	\N
1968	010370	Lisas SH.P.K.-Prishtinë	\N
1969	001232	LISI DPT - Mitrovic	\N
1970	125810	LISI PHARM PRO SH.P.K.	\N
1971	012536	LIT MARKET SH.P.K.-Ferizaj	\N
1972	125823	Live Grill E. L SH.P.K.	\N
1974	125870	LizzAK GROUP SH.P.K.	\N
1975	002451	LLAPI  - Fushe Kosove	\N
2096	126438	Maris Resort LLC	\N
2097	001233	MARKET 1 SHPK - Ferizaj	\N
2098	012315	Market 2 Korriku-Podujevë	\N
2099	126182	MARKET ABI 2025 SH.P.K.	\N
2100	011284	MARKET ANDI SH.P.K.-Klinë	\N
2101	008888	MARKET ANI SH.P.K	\N
2102	125888	Market Aniku H&K SH.P.K.	\N
2103	011283	Market Armendi SH.P.K.-Fushë Kosovë	\N
2104	011332	MARKET AS SPAHIU	\N
2106	008918	MARKET BERISHA SH.P.K.	\N
2105	008904	MARKET BERISHA SH.P.K.	\N
2108	125699	MARKET BESNIK HAJDINI SH.P.K-Gjilan	\N
2107	009880	Market Besiani SHPK-Velani Prishtine	\N
2110	010640	Market Cani-Prizren	\N
2111	012437	Market Caprilla SH.P.K.-Lipjan	\N
2113	013688	MARKET CUFI & ISA SH.P.K.-Prizren	\N
2112	012945	Market Coli SH.P.K.-Prishtinë	\N
2115	125742	Market DEDA SH.P.K.-Kaçanik	\N
2114	011285	Market Dadini SH.P.K.-Kaçanik	\N
2117	012927	Market ELA 2023-Ferizaj	\N
2116	012936	MARKET DINI LDM SH.P.K.-Ferizaj	\N
2119	012487	Market Engjulli SH.P.K.-Malishevë	\N
2118	125774	Market Eltoni SH.P.K.-Suharekë	\N
2121	013626	MARKET ERA VERA SH.P.K.-Prizren	\N
2122	126570	Market Erti SH.P.K.	\N
2120	013379	Market Enisi 2 SH.P.K.-Prishtinë	\N
2123	126571	Market Ervisi	\N
2125	012576	Market Express Molla SH.P.K.-Gjilan	\N
2126	126530	Market Extra LK Lirim Kabashaj BI	\N
2124	011216	MARKET ERZENI SH.P.K.-Prishtinë	\N
2127	126342	MARKET FSHATI  SH.P.K.	\N
2129	012822	Market Goni Dardani SH.P.K.-Ferizaj	\N
2130	126270	MARKET GRANITI SH.P.K.	\N
2131	011243	Market Haappy-Ferizaj	\N
2133	126272	Market Korabi  SH.P.K.	\N
2128	010454	Market Gashi -Malisheve	\N
2135	012719	MARKET KULLA- Llozice Malishevë	\N
2134	125762	Market Kroni A&D SH.P.K.-Prishtinë	\N
2137	008475	MARKET LENTI SH.P.K.-Suhareke	\N
2138	012553	MARKET LILI SH.P.K.-Deçan	\N
2136	009098	Market LEKA - Ferizaj	\N
2139	011300	Market Lindi & Niti-Mitrovicë	\N
2140	013675	Market Lini SH.P.K.-Prizren	\N
2141	125779	MARKET LOKI SH.P.K.-Suharekë	\N
2142	126020	MARKET LONI LM	\N
2143	010386	MARKET LULI SH.P.K.-Kaçanik	\N
2144	126528	Market Malti Xig Shpk	\N
2145	125886	MARKET MILIC-Dragana D. Milic I.B.	\N
2146	012509	Market Moni SH.P.K.-Prizren	\N
2147	013660	market n 05 SH.P.K.-Shtime	\N
2148	007582	MARKET N`LAGJE SHPK-Prishtine	\N
2149	010726	Market NELI A-Malishevë	\N
2150	012301	MARKET NORI & 01-LIPJAN	\N
2151	012046	Market Onida-Mitrovicë	\N
2152	125905	Market ORA S.B. SH.P.K.	\N
2153	005085	MARKET PLUS - RUNIK	\N
2155	125735	MARKET PO SH.P.K.-Fushë Kosovë	\N
2156	009656	Market Resuli SHPK-Shipol Mitrovice	\N
2157	013677	MARKET ROGOVA SH.P.K.-Rugove	\N
2158	003255	Market Roni Center L.L.C.	\N
2159	007409	MARKET ROZI SHPK-Gllogoc	\N
2160	010596	Market Shpejtimi SH.P.K.-Lipjan	\N
2161	013723	MARKET SHPETA(Shukrije Mulliqi)-Podujeve	\N
2162	013662	Market Store YLLI SH.P.K.-Podujevë	\N
2163	126267	MARKET TE ANDI SH.P.K.	\N
2164	012052	Market TE CIMA-Mitrovicë	\N
2165	009837	Market Te Qeli SHPK -Prishtine	\N
2166	011236	Market Te Shkolla SH.P.K.-Prishtinë	\N
2167	013377	Market Tokio SH.P.K.-Prishtinë	\N
2168	125737	MARKET TRISA T S SH.P.K.-Gjilan	\N
2169	013523	Market UniKron SH.P.K.-Magj.Pr-Peje	\N
2170	011410	Market Urban DRT-Ferizaj	\N
2172	012560	MARKET Xhabiri Group SH.P.K.-Vushtrri	\N
2173	012834	MarketDea SH.P.K.-Fushë Kosovë	\N
2174	008795	MARKET-XHETI SHPK-Sllovi Lipjan	\N
2175	002539	MARKOVAC  P.P.- Plemetin - Obiliq	\N
2064	012592	MALI CENTER SH.P.K.-Lipjan	\N
2065	004069	MALI DPT- GODANC -SHTIME	\N
2066	010602	Mali Lounge SH.P.K.-Prishtinë	\N
2067	002521	MALI MARKET DPSH - Lubizhde- Prizren	\N
2068	004819	MALI MARKET NTP(L.Al.Gashi)-Prishitne	\N
2069	012366	MALINE SH.P.K.	\N
2070	007691	MALOKU 4 MARKET DPT-Gllanaselle	\N
2071	002523	MALSIA LUX 1 - Prishtine	\N
2072	002522	MALSIA LUX A - Prishtine	\N
2074	012759	MALZA SH.P.K.-Prishtinë	\N
2075	125808	MAMAS SH.P.K.	\N
2076	004663	MAMUSHA CENTER NTP(Qamil S) - Mamushe	\N
2077	010734	Mana Market SH.P.K.-Ferizaj	\N
2078	013684	MANDARINA 1985 SH.P.K.-Ferizaj	\N
2079	125911	MANDARINA FRUITS 2025 SH.P.K.(Frutaria 2	\N
2080	002530	MANDARINA MARKET- Ferizaj	\N
2081	005402	MANDI MARKET NTP - KLINE	\N
2082	009662	MANI 5 SHPK-Vellushe Prishtine	\N
2083	012600	MANI BA SH.P.K.-KLINË	\N
2084	010343	MANI DEPO SHPK-Malisheve	\N
2085	126370	MANI GK SH.P.K.-Malisheve	\N
2086	000012	MANI NTP(Rrahim Kastrati B.I)- MALISHEVE	\N
2087	012537	Manuka Restaurant SH.P.K.-Ferizaj	\N
2088	013721	Mara Store SH.P.K.-Prishtinë	\N
2089	003735	MARGARITA NTP - PRELEZ-  FERIZAJ	\N
2090	009456	MARGO LLC-Prishtine	\N
2091	012511	MARIGO RESORT SH.P.K.	\N
2092	002534	MARIGONA  MARKET - Gjakove	\N
2094	005705	MARIGONA RESTAURANT SH.P.K- LIPJAN	\N
2095	009830	Marigona Tower SHPK-Prishtine	\N
2209	007662	MELLOW SHPK-Prishtine	\N
2210	009852	MELODYRESTORANT	\N
2211	002582	MELOS KAFITERIA DPH - Prishtine	\N
2212	125898	Melt Bistro L.L.C.	\N
2213	002583	MEMA DPT - Vranjevc - Prishtine	\N
2214	013441	MEMA GROUP SH.P.K. - Prishtinë	\N
2215	002584	MEMI - Rahovec	\N
2216	009920	MEMO Caffe SHPK-Prishtine	\N
2217	012417	Menda SH.P.K.-Shtërpcë	\N
2218	005670	MENDI DPH - SUHAREKE	\N
2219	009597	Mendi G&A Sh.p.k	\N
2220	003435	MENDI- MAGJISTRALE - KIEVE	\N
2222	126102	Mentor Gjocaj B.I.	\N
2223	010280	MERCI I SH.P.K.-Lipjan	\N
2224	002602	MERGIMI NTP- Diskont - Peje	\N
2225	003868	MERIDIAN EXPRESS SHPK	\N
2226	126533	Meriton Cacaj BI	\N
2227	013516	Merlinda Halili B.I.-Gjakovë	\N
2228	012347	Mero Group SH.P.K.	\N
2229	010495	Mert Market SH.P.K.-Prishtinë	\N
2230	006989	MERY S FOODS AND COFE NTH -PRISHTINE	\N
2231	012895	Mess Market SH.P.K.-Ferizaj	\N
2232	013057	Met Distribution Kosove SH.P.K.	\N
2233	006070	Meta Comerc N.T-Malishevë	\N
2234	007013	METEX SHPK-Albi market-Ferizaj	\N
2235	013372	METI & SIKAN SH.P.K.-Gjilan	\N
2236	013515	Meti Benz SH.P.K.-Skenderaj	\N
2238	002612	METRO 1 - Dragash	\N
2240	009099	Metro Market Group SH.P.K.	\N
2241	002616	METRO MARKET-Sabedin Buqa B.I.-Podujevë	\N
2242	126387	Metro-A n.t.p.	\N
2243	007031	METROPOLI SHPK-Prishtine	\N
2244	008345	MEVLJUDE RAGIPI B.I.-Graqanice	\N
2245	002618	MIG  P.P.- Shterpc	\N
2246	002620	MIGROS GROUP SHPK- PRISHTINE	\N
2247	126240	Mihrije Elezi B.I.	\N
2248	012697	Mijodrag Pantic B.I.	\N
2249	004150	MIKSA COMERC - GRAQANIC	\N
2250	012976	Milaim Mustafa B.I.-Vushtrri	\N
2251	013609	Mileniumi I Ri SH.P.K.-Podujevë	\N
2252	006176	MILOS N.T.P. - VERBOVC- VITI	\N
2253	002624	MILOTI DPT - Begrac- Viti	\N
2254	011025	MIMI S HOME SH.P.K.-Fushë Kosovë	\N
2255	005689	MIMOZA DPH	\N
2256	012967	Mimoza V. Ahmeti B.I.(Rroni 123)	\N
2257	010026	MIMOZA ZENELI B.I.-Mitrovice	\N
2258	006620	MINATORI  SHPK - Hajriz Pacolli	\N
2259	013788	MINI MARKET ALEA SH.P.K-Prishtinë	\N
2260	125989	MINI MARKET Blerimi SH.P.K.	\N
2262	126084	MINIMARKET BENI GROUP SH.P.K.	\N
2263	012343	Minimarket BESA SH SH.P.K.-Kaçanik	\N
2264	126332	Minimarket ISA-DPT	\N
2265	013038	Minimarket LISI-Mitrovicë	\N
2266	008929	MINIMAX GROUP SHPK-Prishtine	\N
2267	010474	MINT TB(Tomorr Berbati B.I.)-Graçanicë	\N
2268	002635	MIRI MINIMARKET DPT - Gjakove	\N
2269	013872	MISHTORE ERZA SH.P.K.-Prishtinë	\N
2270	125760	Misin Qerimi B.I.-BLETA AM GROUP-Ferizaj	\N
2271	010067	MISSINI SHPK-Skenderaj	\N
2272	007833	MISSINI SWEETS&VALAONI SHPK  PRIZREN	\N
2273	007783	MITIC D.O.O.-LLAPNASELLË	\N
2274	004726	MITIC DOO	\N
2275	010980	MITROS WIN MARKET D.O.O.	\N
2276	002641	MITROVICA PHONE - Mitrovice	\N
2277	013629	Mivago Group SH.P.K.-Prishtinë	\N
2278	002642	MIX MARKET - Prishtine	\N
2279	012807	MIXED SHOOP-Shtërpcë	\N
2280	013588	MOA SH.P.K.-Prishtinë	\N
2281	001838	MODELI NTP - Viti	\N
2283	126449	Moka Bar 038 SH.P.K.	\N
2284	009944	MOKA Coffe SHPK-Prishtine	\N
2285	009939	Mokis Cafe SH.P.K.- Prishtinë	\N
2286	009420	Molla Express SHPK-Gjilan	\N
2287	008733	MOMO Coffee & more SHPK-Prishtine	\N
2288	009918	Mon Ami SHPK-Ferizaj	\N
2289	009145	MONET GROUP L.L.C.	\N
2290	006098	MONEX MARKET - Peje	\N
2291	000026	MONI COMMERCE - Besiane	\N
2292	000024	MONI DPT - Dragash	\N
2293	008972	MONI MARKET B.I.-Podujevë	\N
2177	013514	Maroto SH.P.K.-Ferizaj	\N
2178	002541	MARSI 1 - Dardani - Prishtine	\N
2179	013018	MARTINAJ SH.P.K.-Prishtinë	\N
2180	126522	Martini Bekery & Coffee SH.P.K.	\N
2181	008872	MARTIUS L.L.C.-Prishtinë	\N
2182	126253	MASTER STEAK SH.P.K.	\N
2184	013079	Matisse Factory SH.P.K.-Graçanicë	\N
2185	010271	MAX Market SHPK-Gjilan	\N
2186	002549	MAXI DPT - Dragash	\N
2187	002551	MAZREKU - Malisheve	\N
2188	126395	M-BURGER SH.P.K.	\N
2189	012981	MDL Sylejmani SH.P.K.-Mitrovicë	\N
2190	125975	Me lugë L.L.C.	\N
2191	013780	MEAR 05 SH.P.K.-Ferizaj	\N
2192	003401	MECINAJ - SKENDERAJ	\N
2193	003560	MEDA 92 NTP - BUDRIKE- VITI	\N
2194	009702	MEDICON NTP-Prishtinë	\N
2195	002563	MEDINA - Prishtine	\N
2196	006183	MEDINA DPH - Prishtine	\N
2197	005090	MEDINA MARKET DPT - BREGU I DIELLIT	\N
2198	010905	Medina Market SH.P.K.	\N
2199	002567	MEDITERAN GROUP  SH.P.K.- VITI	\N
2200	013820	MEETING POINT 24 SH.P.K.-Prishtinë	\N
2201	012865	MEETPOINT SH.P.K.-Prishtinë	\N
2202	125914	Mega Market Plus SH.P.K.	\N
2203	007993	MEGACENTER SHPK-Lluzhan	\N
2205	009926	MEJDA MFG GROUP SHPK-Fushe Kosove	\N
2206	005833	MELI PETROL N.T - FERIZAJ	\N
2207	002578	MELISA BARNATORE - Lypjan	\N
2208	010569	Melisa Market SH.P.K.-Vushtrri	\N
2327	003535	MURATI N.T - KLINE	\N
2328	011045	MURIQI center SH.P.K.-Pejë	\N
2330	000036	MURIQI SHPK - Peje	\N
2329	007279	MURIQI MARKET NTP-Peje	\N
2332	008851	Musli Bytyqi B.I.(Vavi market)-Greme	\N
2331	010288	Musa B. Krasniqi B.I.-Malishevë	\N
2333	126378	My Bite SH.P.K.	\N
2335	010973	My Gym SH.P.K.-Fushë Kosovë	\N
2334	010458	My Cosmetics Store-Skenderaj	\N
2336	009417	My Way Lounge Bar SH.P.K.	\N
2338	012058	N - LARGE SH.P.K.	\N
2339	009550	N CORNER OBILIQ	\N
2341	008184	N Dhomë SH.P.K.	\N
2340	009677	N Dhomë SH.P.K.	\N
2343	009364	N Kojshi SHPK-Prishtine	\N
2337	007629	MYELINE SH.P.K.-Prishtine	\N
2342	007977	N HIJE  "Sh.P.K"	\N
2346	012042	N.H.T." NATYRA-H.I. "-Gjakovë	\N
2344	013428	n Stop MARKET-Fushë Kosovë	\N
2348	003996	N.H.TSH.P. OK SH.P.K.- PRIZREN	\N
2349	012504	N.P. T. " B P "-Babaj i Bokës	\N
2351	012964	N.P.H. "BISTROL"-Mitrovicë	\N
2347	012831	N.H.T.SH. Shkëlqimi - 2 SH.P.K.-Gjakovë	\N
2353	007568	N.P.T. " D & Z " Sh.p.k.	\N
2352	013042	N.P.SH. '' URESA "-Suharekë	\N
2350	010652	N.P.H. " California Park "-Pejë	\N
2355	012030	N.T. " Ardi .com "-Gjilan	\N
2356	009922	N.T.H. " Reforma-D"	\N
2357	012048	N.T.H. "YJET E SHARRIT"	\N
2358	007910	N.T.P LAURESA-COM	\N
2359	000385	N.T.P RRAFSHI-R - Duhel Therande	\N
2354	012802	N.T H. "Rio"	\N
2361	001193	N.T.P. " LINDI " - Greme Ferizaj	\N
2362	000407	N.T.P. " Samanda "	\N
2363	010511	N.T.P. "Hani"-Pejë	\N
2360	012734	N.T.P. " COMPAK "-Gjilan	\N
2364	002676	N.T.P. BUKËPJEKËS " QERIMI 1 "	\N
2365	010484	N.T.P."TROPIK"-Mitrovicë	\N
2368	010743	N.T.SH. " CHOCOLATE CORNER "-Prishtinë	\N
2367	010533	N.T.SH. " Baci Petrol "-Klinë	\N
2370	013077	N.T.SH. " O & M "-Ferizaj	\N
2369	012833	N.T.SH. " CIMI "-Gjakovë	\N
2372	008976	N.T.SH." Lulzimi Comerc "-Gramaqel Deçan	\N
2371	008854	N.T.SH. GIPA (Mergim Iberhysaj B.I.)	\N
2373	007313	NAIMI -SHM -RAUSHIQ - Peje	\N
2374	013437	NAKI-TRADE SH.P.K.-Prishtinë	\N
2375	012434	NALLBANI Market SH.P.K.-Pejë	\N
2376	005010	NAPOLI DPH - Br. Diellit - Prishtine	\N
2377	000047	Napoli Ntp - Prishtine	\N
2378	013683	Napoli Pizza B L.L.C.-Prishtinë	\N
2379	125972	NAR  S.T.R.	\N
2380	000048	NARI SHPK  - Ferizaj	\N
2381	126415	Narti 2026 SH.P.K.	\N
2382	126030	NAS GROUP SH.P.K.	\N
2383	000050	NASER UKAJ - Peje	\N
2384	126350	NATURA TRADE SH.P.K.	\N
2385	009444	Natural BI SH.P.K.	\N
2387	126414	Natural Pool&Spa SH.P.K.	\N
2388	012957	NATYRA - F SH.P.K.-Gjakovë	\N
2389	006406	NATYRA - Prizren	\N
2390	000051	NATYRA 1 NTP - Shtime	\N
2391	010633	NATYRA RESORT SH.P.K.-Prizren	\N
2392	010065	NATYRA(Sali S. Sali B.I.)-Dragash	\N
2393	125913	NATYRAL PLUS SH.P.K.(Frutaria 5)	\N
2394	009879	Nazim Kurteshi B.I.-Ord.Veterinare-Viti	\N
2395	126173	N'Caffe 2024 SH.P.K.	\N
2396	013716	N'DARDHË MARKET24 SH.P.K.-Prishtinë	\N
2397	010658	në mangoo SH.P.K.-Ferizaj	\N
2398	126559	Në Prush B SH.P.K.	\N
2399	126398	Nehar Beqiri B.I.	\N
2400	126519	NEJLA MARKET SH.P.K.	\N
2401	004087	NEKI DPT- SKENDERAJ	\N
2402	010395	NEKI 's SH.P.K.-Skenderaj	\N
2403	000060	NELI BANJA - Malisheve Sh.P.K	\N
2404	010100	Nemanja Kostic I.B.-Graqanice	\N
2405	000067	NEPTUN SH NPT - Rahovec	\N
2406	012092	NERAMARKET SH.P.K.-Prishtinë	\N
2407	012861	Nero Lounge Bar L.L.C.-Prishtinë	\N
2408	125998	NERO SHESHI SH.P.K.	\N
2409	000069	NERTILI SHPK - Gjakove	\N
2411	000073	NESI MARKET NTP - Prishtine	\N
2295	010263	Mono xxx Restaurant SHPK	\N
2296	010255	MONROE BAR SH.P.K.-Fushe Kosove	\N
2297	009514	MONROE SHPK-Prishtine	\N
2298	125990	MONROES SH.P.K.	\N
2299	125973	Mons Group SH.P.K.	\N
2300	012687	MONUM L.L.C.	\N
2302	012365	Moon LB SH.P.K.	\N
2303	126097	MORE CAFFE SH.P.K.	\N
2304	013813	MOREA ALT SH.P.K.-Istog	\N
2305	009363	Morea Bistro & Bar Galeria Shpk-Prizeren	\N
2306	009933	Morea Food & Drink SHPK-Prishtine	\N
2307	007671	MORENA BAR SH.P.K	\N
2308	009304	MOSCATEL CAFFE SHPK-Prishtine	\N
2309	010472	Moscatel Free Shop-Prishtinë	\N
2310	126555	MOTEL  Roma SH.P.K.	\N
2311	006372	Motel Villa A2	\N
2312	126101	Motrat Binjake N.T	\N
2313	126046	MoveX Solutions SH.P.K.	\N
2314	126372	Mozaik D.p.h.	\N
2315	000031	MOZART SHPK -  PRISHTINE	\N
2316	126191	Mr Crust SH.P.K.	\N
2317	125843	MR HONG ASIAN RESTAURANT SH.P.K.	\N
2318	006277	M-TECHNOLOGIE NTP- Prishtine	\N
2320	001495	Muhadin Hashani BI DPT ART-Ferizaj	\N
2321	012388	Muhamet N. Ejupi B.I.-Prishtinë	\N
2319	012959	Muhadin Hashani BI DPT ART-Ferizaj	\N
2324	003542	MULI - BANJE E PEJES	\N
2325	000033	MUNDIMI SHPK - Gjakove	\N
2326	000035	MURATI DPT- Lubizhde - Prizren	\N
2322	008009	MUHAMET SYLI B.I.-Gjilan	\N
2445	009064	N'LAGJE SHPK-Malisheve	\N
2446	009309	NOARI BLN B.I.-Prishtinë	\N
2447	009131	NOBEL N.H.-Gllogoc	\N
2448	000114	NOLI - Shtime	\N
2449	008069	NOLI-D DPT-Gjakove	\N
2450	126575	NOOK 95 L.L.C.	\N
2451	008329	NORA MARKET SHPK-Fushe Kosove	\N
2452	007339	NORA SHPK-Skenderaj	\N
2453	000119	NORA-BARN - Prizren	\N
2454	000122	NORI - Gjakove	\N
2456	000014	NORWEGIAN PX	\N
2457	012330	Novum L.L.C.-Prishtinë	\N
2458	126344	NOVUM New  L.L.C	\N
2459	126381	Novus bar&lounge SH.P.K.	\N
2460	125734	NOY COSMETICS VH SH.P.K.-Rahovec	\N
2461	010211	Noya SH.P.K.	\N
2462	126148	N'Perlë Lounge Bar SH.P.K.	\N
2463	008124	N'PESHK Terrace Restaurant SHPK	\N
2464	016343	NPIKE MARKET SH.P.K.-Ferizaj	\N
2465	005545	NPN RENELUAL TAHIRI  SH.P.K -ÇAGLLAVICE	\N
2466	000859	NPSH Supermarket GRANITI- Kolovice	\N
2467	002717	NPT  Bled SH.P.K.-Gjakovë	\N
2468	125961	NPT Meka O.P.	\N
2469	000483	NPT SRNA 1979	\N
2470	010301	NR74 SH.P.K.-Gllogoc	\N
2471	100164	NSB SYMPHONY SH.P.K.	\N
2472	011268	NTH DASMORI-Gjakovë	\N
2474	010588	NTP ARDI MARKET BRAHA-Ferizaj	\N
2475	006797	NTP HANI COMERCE-RAHOVEC	\N
2476	006439	NTP RRAFSHI-R - DUHEL	\N
2477	013498	NUMO Bistro SH.P.K.-Fushë Kosovë	\N
2478	010120	NUNO CAFFE(A.Bivolaku B.I.)-Prishtinë	\N
2479	011015	NUNO LOUNGE L.L.C.-Prishtinë	\N
2480	013840	N'viva Dine and Coffee SH.P.K.-Deçan	\N
2481	009636	O2BM D.O.O.-Shtërpcë	\N
2482	008992	OAZA COM NTP-Prishtinë	\N
2483	009139	OAZA COMPANY SH.P.K	\N
2484	002652	OAZA DPT - F.A -Bill Klinton- Prishtine	\N
2485	012813	OAZA F.A SH.P.K.-Prishtinë	\N
2486	000138	OAZA NTP - Te Qafa - Prishtine	\N
2487	013036	ODA E JUNIKUT SH.P.K.-Deçan	\N
2488	126481	ODA GRILL HOUSE SH.P.K.	\N
2489	013583	Ogipharm SH.P.K.-Prishtina Mall	\N
2490	125844	Ojala SH.P.K.	\N
2492	000148	OLA SHPK - Prishtine	\N
2493	125880	Old Barrel GastroPub SH.P.K.	\N
2494	010955	Old Tree L.L.C.-Prishtinë	\N
2495	013316	OLEA SHOPPING SH.P.K. - Vushtrri	\N
2496	011038	OLIVE BAKERY SH.P.K.-Prishtinë	\N
2497	126126	Olivia.ITA SH.P.K.	\N
2498	013126	Olsa AAV SH.P.K.-Skenderaj	\N
2499	002755	OLSA MARKET - Bardhoshe - Prishtine	\N
2500	006268	OLSA MARKET NTP - Prishtine	\N
2501	008831	OLTA SH.P.K.-Radivojc	\N
2502	007029	OLTI DPT-Gjakove	\N
2503	006476	OLTI MARKET Dpt - Drenas	\N
2504	012948	OLTI MARKET FH SH.P.K.-Gllogoc	\N
2505	126406	Olti Trasing SH.P.K.	\N
2506	006594	OLYMP  PP (Igor Aritonovic)- Graqanice	\N
2507	012812	OMBRELLA GROUP L.L.C.	\N
2508	003345	OMEGA 1  TREG - Prishtine	\N
2509	126026	ON MARKET SH.P.K.	\N
2510	013395	ONDINE SH.P.K. -Istog	\N
2511	125840	ONEO SH.P.K.	\N
2513	013673	Onida Distribution SH.P.K.-Mitrovicë	\N
2514	000158	ONIX  DPT- Fortese - Rahovec	\N
2515	021003	ONIX GROUP SH.P.K.	\N
2516	126219	ONIX PALACE GROUP SH.P.K.	\N
2517	013426	ONIX PALACE GROUP SH.P.K.-Obiliq	\N
2518	010928	ONIX SPA L.L.C.-Istog	\N
2519	009910	ONLI ORIGANAL S.T.R.-Zveçan	\N
2520	009843	ONLINE Market(B.Bytyci)-Suhareke	\N
2521	005244	OPTIMUM SHPK - PRIZREN	\N
2522	009408	ORA CAFE SH.P.K.	\N
2523	008716	ORA LOUNGE BAR SHPK-Prishtine	\N
2524	006287	ORA MARKET NT- Strellc - Deqan	\N
2525	008947	ORA Restaurant SHPK-Podujeve	\N
2526	000162	ORANA DEPO N.T.P - Ferizaj	\N
2527	006843	ORANA GROUP-FERIZAJ	\N
2528	000163	ORANGE - KS SHPK - Prishtine	\N
2529	007192	ORANGE - M  D.P.T.-Prishtine	\N
2530	000164	ORANGE - Prishtine	\N
2414	009981	Nevi Market L.L.C.	\N
2415	013393	NEW BLENDI SH.P.K.-Podujevë	\N
2416	126080	NEW CALABRIA SH.P.K.	\N
2418	125773	NEW PRANVERA SH.P.K.-Ferizaj	\N
2419	013056	New Sun House SH.P.K.-Prishtinë	\N
2420	012755	NEW VANILA(Yll Lajqi B.I.)Gjakovë	\N
2421	000080	NEW YORK NTSH - Skenderaj	\N
2422	009536	Newco Restaurant Ballkan LLC-Suhareke	\N
2423	009023	NEWCO TROFTA L.L.C.-Istog	\N
2424	000082	NEXHI - Ulpiane - Prishtine	\N
2425	005826	NEZA DPT - ROMAJE- PRIZREN	\N
2426	000085	NEZA MARKET DPT - Dardane	\N
2427	010757	N'HIJE 1 SH.P.K.-Gllogoc	\N
2428	125884	NIDO Caffe Bar SH.P.K.	\N
2429	003568	NIDZA DPT - GUSHTERICE	\N
2430	000089	NIKI MARKET SHPK- Koshare Ferizaj	\N
2431	000091	NIKU  NTP - Besiane	\N
2432	000093	NIKU DPT  Dardani  - Prishtine	\N
2433	125897	Nina &Tanaj SH.P.K.	\N
2434	125825	Nina Market 23 SH.P.K.	\N
2435	126486	Ninja Group LLC	\N
2436	002571	NISI COM N.T - Crep Dardan	\N
2437	000099	NISI FARM - Peje	\N
2438	007442	NITA NTSH-Skenderaj	\N
2440	000108	NITI B NPT - Vitomiric- Peje	\N
2441	009934	NITI DPT(Granit Elezi)-Suhareke	\N
2442	011315	Një Market SH.P.K.-FERIZAJ	\N
2443	002764	NL FARM - R.GERMIS - Prishtine	\N
2444	013743	N'LAGJE MMN SH.P.K.-Gjilan	\N
2564	012082	Papa's Pita SH.P.K.	\N
2565	010543	PAPI MARKET SH.P.K.-Prishtinë	\N
2566	001021	PAPILLON KAFITERIA - Prishtine	\N
2567	010556	Papirun Express SH.P.K.-Prishtinë	\N
2568	003299	PAPIRUN SHPK- PRISHTINE	\N
2569	012656	Parku GCC SH.P.K.-Prishtinë	\N
2570	126232	PASA DÖNER SH.P.K.	\N
2571	004876	PASARELA DPH - PRISHTINE	\N
2572	126434	Pashtriku 1-N.T.SH.-Gjakove	\N
2574	000194	PASHTRIKU Shpk - Prishtine	\N
2575	013010	Pashtriku Trade SH.P.K.-Prishtinë	\N
2576	009829	PASSAGE Prime SHPK-Prizeren	\N
2577	008380	PASTA FASTA SHPK-Prishtinë	\N
2578	010018	Pastao Eatery SH.P.K.-Prishtinë	\N
2579	126340	Pastaria  Pri SH.P.K.	\N
2580	013786	Pastatore Eatery SH.P.K.-Prishtinë	\N
2581	126360	Pasticeria Grande D.p.z	\N
2582	126250	Pasticerija Palma D.p.z.	\N
2583	125963	Patio.PR SH.P.K.	\N
2584	000197	PATRIK DPT - Nepolje - Peje	\N
2585	126294	Paw Corner SH.P.K.	\N
2586	126550	Pemtaria Market EDI Shpk	\N
2587	125828	Pemtore Pazari i Ri SH.P.K.	\N
2588	000205	PEPI MARKET DPT - Mitrovice	\N
2589	012099	Pepperific L.L.C.	\N
2591	000000	PERGJITHSHEM	\N
2592	011309	Perla Beauty SH.P.K.-Prizren	\N
2593	006964	PERLA SHPK-FUSHE KOSOVE	\N
2594	126100	PESHKATARI	\N
2595	000283	PESHKOPIA  NTSH- Drenas	\N
2596	009217	PESHKU Restaurant SHPK-Ferizaj	\N
2597	004325	PESTOVA SHPK	\N
2598	013775	Petrit Bajrami B.I.-Prishtinë	\N
2599	000209	PETRITI - Peje	\N
2600	004297	PETROL COMPANY SHPK	\N
2601	005967	PETROL KABASHI SHPK. - PRISHTINE	\N
2602	005659	PHARMA IN  SH.P.K.- PRISHTINE	\N
2604	009827	PHARMA TREE SHPK-Prishtine	\N
2605	005986	Pharmacion Vet STV Sh.p.k.- Vushtrri	\N
2606	011039	PharmaSen plus SH.P.K.-Prizren	\N
2607	126569	Piceria NITI SH.P.K.	\N
2608	000217	PICOLINO TE QAFA- Prishtine	\N
2609	011335	Pika Market	\N
2610	125732	Pika Market Plus SH.P.K.-Prizren	\N
2611	010347	PIKA PHARM SHPK-Gjakove	\N
2612	010080	PIKNIK DPH Prizeren	\N
2613	002743	PINOCCHIO NPH - Dragodan Prishtine	\N
2614	004399	Pishat SH.P.K	\N
2616	126285	PIT STOP MARKET SH.P.K.-GJILAN	\N
2617	012486	Pit Stop Store SH.P.K.-Prishtinë	\N
2615	009171	Pishat SH.P.K	\N
2619	010374	PIZZA BAR SH.P.K.-Ferizaj	\N
2620	008750	PIZZA CRUST L.L.C.-Prishtinë	\N
2618	012835	PIZZA ALBI-Gjakovë	\N
2622	009024	PIZZA HOUSE L.L.C.-Prishtinë	\N
2621	013331	PIZZA FRESH SH.P.K.-Klinë	\N
2624	126516	PIZZERIA EDAA'S ART SH.P.K.	\N
2625	126127	Pizzeria Tony SH.P.K.	\N
2623	004664	PIZZA HUTT DPH - PRISHTINE	\N
2627	125909	Plan Market Rugovë SH.P.K.	\N
2628	009086	Plast House SH.P.K	\N
2626	010095	Pizzeria XXL SHPK-Shtime	\N
2630	013696	PLAZA PARK SH.P.K.-Prishtinë	\N
2631	125959	PLIKO SH.P.K.	\N
2633	000225	PLLUMBI NTSH - Gjakove	\N
2634	012698	Plus Market group SH.P.K.	\N
2635	000226	PLUS MARKET(S.Neziri) - Ferizaj Sh.P.K	\N
2636	000228	PLUS-MARKET - Gjakove	\N
2637	126203	Poema Erveheja SH.P.K.	\N
2632	000224	PLISI SHPT- Malisheve e Eperme - Gjilan	\N
2639	009499	Ponte Caffe 1 SH.P.K.-Prizren	\N
2641	010051	Ponte Lounge SHPK-Prizeren	\N
2642	008797	Ponte Vecchio DPH	\N
2640	009572	Ponte Caffe 1 SH.P.K.-Prizren	\N
2638	012014	Pomo21-Migjen Dema	\N
2644	013778	Posantio Food L.L.C.-Suharekë	\N
2643	008290	POPOVIC D.O.O.-Shtërpce	\N
2647	009647	POWER HOUSE Gym(A.Cakiqi)-Prishtinë	\N
2646	010923	POWER EXCLUSIVE SH.P.K.-Prishtinë	\N
2649	009948	PP Viva Pro Team-Mitrovice	\N
2533	009831	Orange fruits SHPK	\N
2648	006477	PP KRISTIQ - Dobratin	\N
2535	005066	ORGENI - H - PEJE	\N
2534	013422	ORCHIDEA Cosmetics SH.P.K.-Pejë	\N
2537	000168	ORHAN MARKET DPT-  Prizren	\N
2536	010582	Orhan A. Aliu B.I.-Mitrovicë	\N
2539	009898	Ornela Dyqani(M.Shurdhaj B.I.)-Malisheve	\N
2538	008834	ORIK COSMETICS SHPK-Mitrovice	\N
2540	126301	ORTA GAVA GROUP SH.P.K.	\N
2542	000172	OSLO 2 MARKET SHPK - Mitrovice	\N
2543	010622	Osman Lokaj B.I.-Deçan	\N
2541	126208	OSKE L.L.C.	\N
2544	012810	Ota Pharm L.L.C.-Vushtrri	\N
2546	013492	OTTIMO L.L.C.-Prishtinë	\N
2545	000920	OTI DPT - Gjakove	\N
2548	126352	OX'HO SH.P.K.	\N
2547	125965	Otto Market SH.P.K.	\N
2550	008614	OXYGEN SHPK-Fushë Kosovë	\N
2551	008806	OZAN SH.P.K.-Mitrovice	\N
2553	013332	P.P.''ICE PLUS''-Zveçan	\N
2554	003514	P.U.P. Grand Siniša Perenic B.I.	\N
2549	022051	OXYGEN NPH - Gjakove	\N
2555	126047	Padel Zone L.L.C.	\N
2556	008452	PAJTIMI Center shpk 3 Malisheve	\N
2557	010090	PAJTIMI-1 SHPK-Malisheve	\N
2558	009523	PALMA PASTICERIJA DPZ-Lipjan	\N
2559	126169	Pano Pizza SH.P.K.	\N
2560	009340	PANORAMA (FEGATO) LLC-Prizeren	\N
2561	126309	PANORAMA MOUNTAIN L.L.C.	\N
2562	000189	PANTINA - Mitrovice	\N
2563	000190	PANTINA MARKET 2 - Mitrovice	\N
2682	012943	PRO PIDE SH.P.K.-Prishtinë	\N
2683	002974	Proex SH.P.K.	\N
2685	010975	PROPER PIZZA & MORE SH.P.K.-Gjakovë	\N
2686	010055	PRUSH CAFFE SHPK-Prishtine	\N
2687	003269	PUNONJESI - Migros	\N
2688	009332	PUNTO CAFFE SHPK-Ferizaj	\N
2689	012066	PURE PHARM SH.P.K.-Fushë Kosovë	\N
2690	012979	Q MAX PETROL-Gllogoc	\N
2691	005825	QARSHIA DT - KRAJKE- PRIZREN	\N
2692	126096	QAUSHI SH.P.K.	\N
2693	013063	Qazim Alaj B.I.- Corner Kaffe-Deçan	\N
2694	006796	Qazim Rizvanolli B.I - Gjakove	\N
2695	003626	QENDRA E RE NTP - DOBRAJ	\N
2696	126469	Qendra Market Shpk	\N
2697	000258	QENDRESA - Llabjan- Gjilan	\N
2698	007208	QENDRIM BYTYQI B.I.-Ferizaj	\N
2700	000260	QENDRIMI - Astrazub- Malisheve	\N
2701	009279	QENDRIMI DPZ-Ferizaj	\N
2702	125893	Qengji I Sharrit SH.P.K.	\N
2703	000265	QERSHIZA - Zllakuqan- Kline	\N
2704	125778	Qlirim Krasniqi B.I.-Furra ÇLIRIMI-Pejë	\N
2705	000269	QYPOLI - Gllamnik- Besiane	\N
2706	013105	R DUO SH.P.K.-Pejë	\N
2707	009699	R STORE SHPK-Fushe Kosove	\N
2708	012916	RADIO BY MINIBAR SH.P.K.-Ferizaj	\N
2709	126354	RADIO LOUNGE BAR Fr1 SH.P.K.	\N
2710	013647	Raja RMR SH.P.K.-Gjilan	\N
2711	013452	Rama Pharm SH.P.K.-Viti	\N
2712	007160	RAMA SHPK-Rahovec	\N
2713	008266	RAMADAN BALIJA B.I.I-Mitrovice	\N
2714	126256	Ramadan N. Salihu B.I.	\N
2715	000272	RAMIZI  - Bllace- Therande	\N
2716	003975	RAMSHA DPT - RAHOVEC	\N
2717	007613	RAMUSH IZLAMAJ B.I.-Istog	\N
2718	009832	Rasim Hasi B.I.(Oferta)-Drenas	\N
2719	000275	REAL CENTER - Viti	\N
2720	000277	REAL CO - Gjakove	\N
2722	000278	REAL MARKET - Skenderaj	\N
2723	125869	Real Metal Group SH.P.K.	\N
2724	012581	REAL SHOP SH.P.K.-Pejë	\N
2725	990283	REDONI - Ferizaj	\N
2726	010419	Reforma market -Malisheve	\N
2727	013486	REGINA Colori L.L.C.-Mitrovicë	\N
2728	000284	REGINA VALI VM - B.Pejes	\N
2729	000285	REHA NTP(Reshit Ramadani B.I.) Prizeren	\N
2730	125802	REINA MARKET SH.P.K.	\N
2731	012527	Reina SH.P.K.-Vushtrri	\N
2732	010054	REIS MARKET B.I.-Prishtinë	\N
2733	012942	REISI PHARM SH.P.K.-Rahovec	\N
2734	012336	RELAX-Bar 01-DPZ Drenas	\N
2735	007538	REMA - 1 SHPK-Ferizaj	\N
2736	013062	Rema Impex SH.P.K.-Ferizaj	\N
2737	125931	Republicafe L.L.C.	\N
2739	013467	RERO Caffe & Cakes SH.P.K.-Prishtinë	\N
2740	022161	Resort Planet ECO Sh.p.k	\N
2741	126518	Resort Turistik ILIRIA SH.P.K.	\N
2742	125826	Restaurant & Pizza Bohem SH.P.K.	\N
2743	012433	RESTAURANT ADRIATIKU SH.P.K.	\N
2744	125770	RESTAURANT ALBANEZI FAMILY SH.P.K.-Prish	\N
2745	009661	Restaurant and More UNICO SHPK-Ferizaj	\N
2746	013824	Restaurant Dushku SH.P.K.-Prishtinë	\N
2747	012693	Restaurant HOME SH.P.K.	\N
2748	013520	RESTAURANT LIBURNA 2 SH.P.K.-Kaçanik	\N
2749	012001	RESTAURANT PIZZERIA A6I-Ferizaj	\N
2750	010509	Restaurant Pizzeria Druri SHPK-Shtime	\N
2751	013338	Restaurant PORTA SH.P.K.-Prizren	\N
2753	012712	RESTAURANT TE SYLA & FATONI PREVALL	\N
2754	126484	Restaurant Tempo 2005 SH.P.K.	\N
2755	125704	Restaurant The Family SH.P.K.-Shtime	\N
2756	012830	Restaurant Tradicional Albanezi SH.P.K.	\N
2757	011042	Restaurant Vikendi SH.P.K.-Prizren	\N
2758	010269	Restoran - Market METROPOL -Podujeve	\N
2759	126397	RESTORANT  JARA SH.P.K.	\N
2760	012886	Restorant Adriani SH.P.K.-Ferizaj	\N
2761	009076	Restorant Anes Drinit SHPK-Radafc Peje	\N
2762	006553	RESTORANT ARBERIA - PRIZREN	\N
2763	012688	Restorant Aroni SH.P.K.	\N
2764	004621	Restorant Bujana SH.P.K.	\N
2651	000234	PPV DUGA - Shterpce	\N
2652	126448	Pranvera Petrit Dph	\N
2653	000239	PRE MARKET NTP - Kline	\N
2654	005353	PREMIJA MARKET DPT(Sasa F.) - GUSHTERIC	\N
2655	125881	PREMIJA SFG SH.P.K.	\N
2656	126314	Premium Bakery SH.P.K.	\N
2657	126001	PREMIUM BURGER SH.P.K.	\N
2658	013011	PREMIUM DAA SH.P.K.-Mitrovicë	\N
2659	007175	PREMIUM MARKET SH.P.K.-Koshare	\N
2660	126421	PREMIUM QUALITY  SH.P.K.	\N
2661	126266	Premium Relax Bar	\N
2663	000240	PREMTIMI - Vranjevc-  Prishtine	\N
2664	013075	PRENDE EXLUSIV RESTAURANT BAR-Prishtine	\N
2665	008602	PRETTY SHPK-Prishtinë	\N
2666	005857	Preventiva Agro Veterina  Ntsh -Gjilan	\N
2667	126133	PREVENTIVA PHARMACY SH.P.K.	\N
2668	013356	PRIME LOUNGE FNZ SH.P.K.-Vushtrri	\N
2669	011052	PRIME MARKET SH.P.K.	\N
2670	126007	PrimoKS SH.P.K.	\N
2671	000246	PRINCE COFFEE  HOUSE - Prishtine	\N
2672	009609	PRISHTINA CITY SHOP SHPK-Fushe Kosove	\N
2673	008845	Prishtina Dog Shelter	\N
2674	126297	Prishtina Smoke House  SH.P.K.	\N
2675	126343	Prishtine Pour Sh.p.k	\N
2676	010510	PRIUS L.L.C.-Prishtinë	\N
2677	126345	PRIVE PIZZA SH.P.K.	\N
2678	000248	PRIZMA 1 - Plemetin-Obiliq	\N
2679	125726	PRIZRENI A L SH.P.K.-Pejë	\N
2680	006794	PRO - LONG LIFE SHPK - Graqanice	\N
2681	010210	Pro Pide Pr Mall SH.P.K.	\N
2797	000355	RINISI - Vranjevc Prishtine	\N
2798	013070	Rinori Market SH.P.K.-Vushtrri	\N
2799	012068	RISI GROUP L.L.C.-Obiliq	\N
2801	000365	RITA B N.T.P.-Besiane	\N
2802	000362	RITA NTP - Besiane	\N
2803	000366	RITA SH - Gjakove	\N
2804	008305	RITA SHPK -Gjilan	\N
2805	008073	RITA-SH DPT-Gjakove	\N
2806	126105	River Bar 2006 SH.P.K.	\N
2807	004665	RIVER BAR DPH - SHTIME	\N
2808	000367	RIXHEVA - Rixheve- Kline	\N
2809	005157	RIZA KOMERC DPT - QIREZ- DRENAS	\N
2810	012879	Rizza Hair Clinic L.L.C.-Fushë Kosovë	\N
2811	012940	Robert Ramadani B.I.(Fresh Look)-F.K .	\N
2812	011280	ROCK HOTEL SH.P.K.-Shtërpcë	\N
2813	013643	Rockuzinë SH.P.K.-Prishtinë	\N
2814	011032	ROGO'S SH.P.K.-Prishtinë	\N
2815	006830	ROKA PHARM -GJAKOVE	\N
2816	010698	ROKA SH.P.K.-Gjakovë	\N
2818	009599	RonExx Sh.p.k (Transit)	\N
2819	126313	ROOM CAFFE SH.P.K	\N
2820	012585	ROSANNA	\N
2821	012306	ROSE COCKTAIL CAFE (Granit Jemini B.I.)	\N
2822	126157	ROSTORANT SAFARI SH.P.K.	\N
2823	126213	Route 66 D.B.A RESTAURANTS SH.P.K.	\N
2824	012973	Royal Gate L.L.C.-Prishtinë	\N
2825	125698	ROZAFA AGROTURIZËM SH.P.K.-Prishtinë	\N
2826	126185	ROZAFA BIO MARKET SH.P.K.-Prishtinë	\N
2827	003895	ROZAFA FAST FOOD DPH - PRISHTINE	\N
2828	000384	ROZAFA RESTAURANT - Prishtine	\N
2829	005030	RRAFSHI R NTP - DUHEL	\N
2830	000387	RREZAKU - Gjakove	\N
2831	004849	RRON PHARM - GJILAN	\N
2832	012679	Rubato SH.P.K.-Prishtinë	\N
2833	009391	RUBIN COMPANY SHPK-Prizeren	\N
2834	008804	RUBIS  SH.P.K.	\N
2835	000391	RUDAJ Sh.P.K - Shiroke - Therande	\N
2836	010022	RUDI S Cake Factory SHPK-Prishtine	\N
2837	000392	RUDINA R - Gjakove	\N
2838	009164	RUGOVA-CAMP	\N
2839	000396	S Market- Prizren	\N
2840	000395	S MARKET Sh.P.K- Rogane	\N
2842	000020	S.T.R. " Dim "-Laplje Selo	\N
2843	010715	S.T.R. " Miki "-Shtërpcë	\N
2844	012522	Sa Ëmbël Group SH.P.K.-Prishtinë	\N
2845	010230	SA ëmbël SH.P.K.-Prishtinë	\N
2846	004728	SABEDIN MARKET DPT - MAXHUNAJ	\N
2847	000397	SABERI TREG - Prizren	\N
2848	007006	SADETE THAQI B.I.-Llapushnik Gllogoc	\N
2849	013751	Sadik Vërbaj B.I.-Istog	\N
2850	000401	SADIKU-A  N.T.P- Prishtine	\N
2851	013544	Safet Rrafshi B.I.- Flat Branch	\N
2852	012923	SAGI MARKET SH.P.K.-Gjilan	\N
2853	012525	Sahit Bütüç B.I.-Prizren	\N
2854	010494	Sahit Mziu-Mitrovicë	\N
2855	126325	Sahrim Dzaferi B.I	\N
2856	126480	Salajdin Fanaj B.I.	\N
2857	000404	SALINDA  Sh.P.K- Peje	\N
2858	012337	SAP Market SH.P.K.-Gjilan	\N
2859	003225	SAPONIA D.D-EXPORT	\N
2860	000410	SARA - Prishtine	\N
2861	000412	SARA DPT - Mitrovice	\N
2863	013401	Saray Sweets SH.P.K.-Prizren	\N
2864	009037	Sasa Mihajlovic I.B.-Graçanicë	\N
2865	000415	SASHA - Shterpc	\N
2866	010438	Sasha-Prelluzh	\N
2867	007199	SCARDIAN j.s.c - Prishtine	\N
2868	013031	SCORPION SH.P.K.-Gjakovë	\N
2869	008403	Seba SHPK - Viti	\N
2870	000419	Sedefi Comerc O.P.-Peje	\N
2871	126452	Seey Beauty LLC	\N
2872	006345	SEFEDIN M.BERISHA B.I.DELTA N.N Peje	\N
2873	013785	SEG GROUP SH.P.K.-Graçanicë	\N
2875	013326	SELECT MARKET SH.P.K.-Ferizaj	\N
2876	008717	SELMON KRYEZIU B.I. Rogane	\N
2877	000424	SEMIRA MARKET NTT - Kline	\N
2878	002014	SEN 5E5 DPH - Prishtine	\N
2879	010398	Sendviq Bar Dio SH.P.K.-Pejë	\N
2880	005969	SERAI SH.P.K. - PRISHTINE	\N
2881	009818	SeRAPHINA Hotel SHPK-Peje	\N
2882	013736	SETEGUSTI SA SH.P.K.-Viti	\N
2766	000321	RESTORANT TIRONA - Prishtine	\N
2767	006048	RETAIL KOSOVA SH.P.K.	\N
2768	013639	Retno Caffee SH.P.K.-Prishtinë	\N
2769	012694	REVE SH.P.K.	\N
2770	125926	REVISON SH.P.K.	\N
2771	009038	REVLON ONE DPT(Kismete Sahaticiu)-Pejë	\N
2772	009640	REXAL PHARM SHPK-Prishtinë	\N
2773	007187	REXALL B -Barnatore SHPK Prishitne	\N
2774	009031	REXHEPAJ CENTER SH.P.K.-Kamenice	\N
2775	006968	REXHEPAJ NTSH-Kamenice	\N
2776	000331	REZAKU NTP - Gjakove	\N
2777	008098	RGB SHPK -Prishtine	\N
2778	008588	RIA GROUP SHPK-Podujeve	\N
2779	013590	RIADI GROUP SH.P.K.-Prishtinë	\N
2780	126257	Rida Zh SH.P.K.	\N
2781	007554	RIDEA PHARM SHPK-Ferizaj	\N
2782	125996	RIFA CENTER SH.P.K.	\N
2784	000337	RIFAJ - BEGRAC- VITI	\N
2785	126187	Rifat Dugolli B.I.	\N
2786	013619	RIGA BAKERY AE SH.P.K.-Deçan	\N
2787	010049	RIGA PHARM SH.P.K.-Gjilan	\N
2788	005339	RIGA PHARM(Arta Zeqiri B.I.)- GJILAN	\N
2789	003939	Rilind Juniku B.I.	\N
2790	006982	RILINDJA M.V. -Te stacioni Prishtine	\N
2791	000343	RILONA  DEPO - Rogove-Prizren	\N
2792	007963	RINA COMERC SHPK-Zallc Istog	\N
2793	003481	RINA TE PARKU - PRISHTINE	\N
2794	125731	Ring Market SH.P.K.-Gjilan	\N
2795	000351	RINIA - Rugove-Rahovec	\N
2796	007774	RINIA DPH-Drenas	\N
2916	126336	Shpend Muqaj B.I.	\N
2917	000458	SHPETIMI  NTP - Pozhoran	\N
2918	005125	SHPIJA E VJETER SHPK- PRISHTINE	\N
2919	007224	SHPRESA Q-D.T. Livoq Gjilan	\N
2920	008694	SHQIPDONI SHPK-Drenas	\N
2921	004148	SHQIPONJA 2 - DAVIDOVC	\N
2922	126189	SHQIPONJA E HASIT SH.P.K.	\N
2923	006963	SHQIPONJA N.T.H -Drenas	\N
2924	126459	Shyqeri Shala B.I.	\N
2925	126488	Si Dikur SH.P.K.	\N
2926	126366	SIENA PLUS S.U.R.	\N
2927	010091	SIGAL CAFFEE SHPK-Prishtine	\N
2928	126180	SIMS LOUNGE CAFFE SH.P.K.	\N
2930	004591	Skenda-Miradi e Ulte	\N
2931	009302	SKO BAR-Prizeren	\N
2932	126010	SKY MARKET SH.P.K.	\N
2933	010250	Sleep Bar OKI- Obiliq	\N
2934	007625	SMAJL DEVA B.I.-Gjakove	\N
2935	006884	SMART PHARM-FUSHE KOSOVE	\N
2936	125722	Smile Pizza Caffe SH.P.K.-Prishtinë	\N
2937	011217	Smile Shop SH.P.K.-Prishtinë	\N
2938	012787	Societe Events L.L.C.	\N
2939	126310	SOFËR N'SHESH SH.P.K.	\N
2940	126400	Sofra e Nanës SH.P.K.	\N
2941	126108	SOHAM SH.P.K.	\N
2942	010397	SOHO BAR O.P.-Pejë	\N
2943	126058	Soju Bar L.L.C.	\N
2944	000477	SOKOLI B NT- Rahovec	\N
2945	013117	Sokoli I.S SH.P.K. - Rahovec	\N
2946	126539	Sole & Mia  N.H.   SH.P.K.	\N
2947	006014	SOLE RESTAURANT- PRISHTINE	\N
2949	013678	SOLO LOUNGE & EVENTS SH.P.K.-Prizren	\N
2950	012857	SOLO LOUNGE SH.P.K.-Prizren	\N
2951	010332	Solos Studio L.L.C.	\N
2952	006580	SOLUTION D SHPK - Prishtine	\N
2953	006142	SOMA SHPK- PRISHTINE	\N
2954	126237	SOMIS Pizza e Pasta SH.P.K.	\N
2955	125829	Sonat Group SH.P.K.	\N
2956	008267	SONDER SHPK-Prishtine	\N
2957	125950	SONDERINN SH.P.K.	\N
2958	008510	SONOMA SHPK-Fushë Kosovë	\N
2959	008985	SOPI COSMETICS SHPK-Prishtinë	\N
2960	010705	Sopranos Lounge Bar shpk-Ferizaj	\N
2961	010351	Soso Caffe SH.P.K.-Prishtinë	\N
2962	005277	SPAHIA PETROL NT- THERANDE	\N
2963	009507	SPAHIU-Petrol SHPK-Prizeren	\N
2964	012784	Spanca Center L.L.C.	\N
2965	009063	SPAR KOSOVA J.S.C.-Prishtine	\N
2966	012427	SPECIAL - PEJTON SH.P.K.	\N
2967	013633	SPEED PETROL SH.P.K.-Dragash	\N
2969	008756	SPORT DEPO SHPK-Prishtine	\N
2970	004922	SPORTISTI NPSH - BARDHE I MADHE	\N
2971	013729	Stacion Free Stop SH.P.K.-Prishtinë	\N
2972	125689	STANDARD BENZ	\N
2973	013546	STANDARD QUALITY SH.P.K.-Lipjan	\N
2974	010678	STAR AA SH.P.K.-Pasjak Gjilan	\N
2975	125794	Star express market SH.P.K.	\N
2976	011248	Star Hill SH.P.K.-Prishtinë	\N
2977	007085	STAR MARKET SHPK-Ferizaj	\N
2978	009354	STARSUN 2 SHPK-Prishtine	\N
2979	009126	STEAKHOUSE SHPK-Ferizaj	\N
2980	013494	Steller SH.P.K.-Prishtinë	\N
2981	126104	Step Market Njs2 SH.P.K.	\N
2982	009983	Step Market SH.P.K.	\N
2983	009201	Stepia DArra SH.P.K.	\N
2984	000488	STINA SHPK - F.Kosove	\N
2985	004602	STOP DPT - FUSHE KOSOVE	\N
2986	010240	STOP MARKET B SH.P.K.-Mitrovicë	\N
2988	010650	STOP Market-Fushe Kosove	\N
2989	126013	STOP NSHOP MARKET SH.P.K.	\N
2990	003268	STR BONA FIDES - Kamenic	\N
2991	005414	STROFCI DPT - Vranjevc - Prishtine	\N
2992	000491	SUADI - Velekince- Gjilan	\N
2993	126330	SUARE SH.P.K.	\N
2994	126036	SUGAR FREE  N.P.SH	\N
2995	012794	SUN TEA SH.P.K.	\N
2996	009020	SUNNY HILL GROUP SHPK-Prishtinë	\N
2997	010023	SUNRISE Caffe SHPK-Prishtine	\N
2998	012552	Sunrise Lounge Bar SH.P.K.-Pejë	\N
2999	010390	Supe Market Niti-Arllat Drenas	\N
3000	005495	SUPER FRESH MARKET N.T - KLINE	\N
2884	013821	Seven Sundays L.L.C.-Prishtinë	\N
2885	012997	SGG DINI SH.P.K.-Gjilan	\N
2886	126183	Shaban Kabashaj B.I.	\N
2887	008022	SHABAN RAFUNA B.I.-Prishtine	\N
2888	013815	Shaban Spahija B.I.-Malishevë	\N
2889	125703	Shaip Behra B.I.-N.T.SH.LE - NAR-Rahove	\N
2890	000428	SHALA E BAJGORES - Besiane	\N
2891	007480	SHALA SHPK-Mitrovice	\N
2892	013369	Shalaj SH.P.K.-Istog	\N
2893	000432	SHALQINI DPT - Peje	\N
2895	009864	SHARR MOUNT LLC-Prizeren	\N
2896	007394	SHARRI NHT-PRIZREN-PREVALLE	\N
2897	009515	SHARRI QT SHPK-Komoran	\N
2898	125782	Shega Fresh SH.P.K.-Prizren	\N
2899	003418	SHEKULLI 21 CAFITERI- GJAKOVE	\N
2900	126457	Shemsidin Gigollaj B.I.	\N
2901	000440	SHENDETI BARNATORE - Lypjan	\N
2902	007151	SHERIF SH.P.K.-Llazareve Kastriot	\N
2903	000442	SHERIFI PETROLL NTP- Millosheve-Obiliq	\N
2904	011324	SHET MARKET SH.P.K.-Klinë	\N
2905	125781	Shija.PR SH.P.K.-Podujevë	\N
2906	005071	SHKEL E SHKO SHPK - PRISHTINE	\N
2907	000447	SHKELZENI COMERC - Kline	\N
2908	005588	SHKENDIA NTSH - KAÇANIK	\N
2909	006632	SHKENDIJA DPT - Ferizaj	\N
2910	007241	SHKENDIJE SHEHU B.I.-Gjakove	\N
2912	013638	SHOKU FAST FOOD SH.P.K.-Prishtinë	\N
2913	012580	Shpejtim S. Hoti B.I.(Eli Market)-Malis	\N
2914	005956	SHPEJTIMI DPT - GADIME E EPËRME	\N
2915	000320	SHPELLA E BOBIT DPH - Vitomirice- Peje	\N
3034	013700	Taksim City SH.P.K.-Prishtinë	\N
3036	126323	Tallku SH.P.K.	\N
3037	009825	TANDEM Bar SHPK-Prishtine	\N
3035	126324	Tallku SH.P.K.	\N
3039	000505	TAPQE - Prizren	\N
3038	126225	TAP RRAP Doner SH.P.K.	\N
3041	006159	TARGET NTSH -  Gjinoc - Therande	\N
3042	009474	TARTINE LLC-Prishtinë	\N
3043	007592	TASIMI DPT-Vushtrri	\N
3044	126118	Tasty Cater SH.P.K.	\N
3046	004778	TAUNITA EXPRESS FOOD - PRISHTINE	\N
3045	013050	TAT' S SH.P.K.-Prishtinë	\N
3047	007304	TAUNITA FISH SHPK-Prishtine	\N
3049	006334	TAUNITA SHPK - Prishtine	\N
3050	125798	Taverna Bani	\N
3051	008293	TAVERNA BARON SHPK-Prishtinë	\N
3052	012313	Taverna Menata SH.P.K.	\N
3048	010521	TAUNITA PESHK SH.P.K.-Prishtinë	\N
3054	126166	Taverna Shkodrane SH.P.K.	\N
3055	012435	Taverna Shpija Group SH.P.K.	\N
3056	126521	Taverna TORO SH.P.K.	\N
3053	125709	Taverna Pellazge SH.P.K.-Suharekë	\N
3057	995570	TAXI MARKET DPT - DRAGASH	\N
3058	010763	TDM GLOBAL L.L.C.-Prishtinë	\N
3059	126317	TE  SYLA 1967 SH.P.K.	\N
3062	005103	TE ARTI DPT - RAHOVEC	\N
3063	007221	TE ASLLANI -Skenderaj	\N
3064	008719	TE BANESAT SHPK-Ferizaj	\N
3065	003532	TE BELI - PEJE	\N
3066	000517	TE BESART- Vushtrri	\N
3061	013389	Te Ardhmëria SH.P.K.-Lipjan	\N
3068	000520	TE DARDI DPT - POLAC	\N
3067	004562	TE BLINI DPT - VUSHTRRI	\N
3069	000522	TE DERGUTI- Studenqan - Therande	\N
3070	007773	TE ENDRITI DPSH-Skenderaj	\N
3071	126331	TE EURO BAKERY SH.P.K.	\N
3072	009588	Te Fahria SH.P.K.-Prishtine	\N
3073	012720	Te Garazhdat SH.P.K.	\N
3074	000534	TE GEZIMI - Skenderaj	\N
3075	000538	TE KENA NTSH - Gjakove	\N
3076	000539	TE KIMI Sh.P.K- Besiane	\N
3078	002485	TE LUKI Sh.P.K - Prishtine - Xhemajl Ibi	\N
3079	004882	TE LULI NTSH - PEJE	\N
3080	013017	Te Luli SH.P.K.-Pejë	\N
3081	010590	Te Luli SH.P.K.-Te Rrethi-Pejë	\N
3082	010393	TE NONA SH.P.K.-Pejë	\N
3083	008496	TE Pishat Restaurant DPH.-Fushë Kosovë	\N
3084	006336	TE PISHAT SHPK - Duhel Suhareke	\N
3085	007229	TE PRINCAT E BOSIT DPT-Llozice	\N
3086	009175	Te Prokshi DPT-Mitrovice	\N
3087	126382	Te Riani	\N
3088	000548	TE RONI (Vlora Zeka)- Gjakove	\N
3089	010668	TE SEJDA-Prishtine	\N
3090	008379	TE SOKOLI SHPK-Sllovi-Lypjan	\N
3091	000552	TE TAHIRI - CARALEV	\N
3092	000524	TE TONI Sh.P.K- Kolovice - Prishtine	\N
3093	007100	TE TRIMI SH.P.K.	\N
3094	007393	TE UKA DPT-Velani Prishtine	\N
3095	007644	TEA Market FP SH.P.K.	\N
3096	125764	Tea Market SH.P.K.-Gjilan	\N
3097	012479	TEATRO SH.P.K.	\N
3098	008238	TEFI DPT-Peje	\N
3099	003000	TEMPO PETROL SHPK- MRAMOR	\N
3101	012716	Terra Eatery SH.P.K.	\N
3102	013636	Terrassiere SH.P.K.-Prishtinë	\N
3103	126055	TESLICA SH.P.K.	\N
3104	125822	The Back Garden 02 SH.P.K.	\N
3105	011247	THE CHARM LOUNGE & BAR SHPK-Prizeren	\N
3106	995602	THE GALERY DPH - PRISHTINE	\N
3107	126338	THE GASTRONOM SH.P.K.	\N
3108	008088	THE GOLDEN SILL SHPK-Prishtine	\N
3109	013598	THE GREEN DREAM SH.P.K.-Ferizaj	\N
3110	010259	THE RETRO SH.P.K.-Gjakovë	\N
3111	010570	The View(Emin Seferi B.I.)-Prishtinë	\N
3112	009936	The White Tree Prishtina SHPK	\N
3113	011053	Tian Distribution SH.P.K.	\N
3114	005088	TIARA DPT - PEJE	\N
3115	012503	TIEN SH.P.K.-Viti	\N
3116	006812	Tifani - Prishtine	\N
3117	008679	TIFFANY SHPK	\N
3118	126318	Tihomir Markovic B.I.	\N
3002	011062	Super Market TINA SH.P.K.	\N
3004	009810	SUPER STORE SHPK-Prishtine	\N
3005	000018	SUPER VIVA SHPK	\N
3006	006575	SUPERMARKET BESIANI SHPK-Prishtine	\N
3007	010953	Supermarket Niti-Gllogoc	\N
3008	125933	Supermarketi Besa 3 NEW SH.P.K.	\N
3009	009006	SUSHICO KOSOVA SHPK-Prishtinë	\N
3010	126165	SV SAMIA SH.P.K.	\N
3011	000497	SVIRCA MARKET NTP - Prishtine	\N
3012	012084	Sweet Box SH.P.K.-Prishtinë	\N
3013	012333	SWEET TIME SH.P.K.-Prishtinë	\N
3014	126464	SWISS Clean FA SH.P.K.	\N
3015	012526	SWISS CORP SH.P.K.-Lipjan	\N
3016	002692	SWISS DIAMOND HOTEL SHPK - Prishtine	\N
3017	013804	SWISS PRODUCT AG SH.P.K.-Viti	\N
3018	006727	SYAR LOSHI B.I	\N
3019	000499	SYLA - Rugove - Prizren	\N
3021	007163	Tabacco Shop EFI SH.P.K.	\N
3022	011195	TACOLAND SH.P.K.-Ferizaj	\N
3023	004915	TAFA COMERC - QIREZ -SKENDERAJ	\N
3024	004085	TAFA COMERCE NTSH- KAÇANIK I VJETER	\N
3025	000125	TAFA TOR N.T (Nehat Tafa B.I)- Torine-	\N
3026	013770	TAFA TOR SH.P.K.-Lipjan	\N
3027	009442	TAFAJ & CO SH.P.K.	\N
3028	000501	TAFI  Sh.P.K-  Prizren	\N
3029	005492	TAFILOVIC-TRANS	\N
3030	012455	TAG GROUP SH.P.K.-Ferizaj	\N
3031	007054	TAHIRSYLAJ OIL SHPK-Peje	\N
3032	125997	Tai Sweets SH.P.K.	\N
3033	010592	Takeaway coffee SH.P.K.-Gjakovë	\N
3152	008843	TORI CENTER SH.P.K	\N
3153	000619	TORI N.T (Xhevat Tafa B.I.)- Lypjan	\N
3155	013808	TOSTY SH.P.K.-Lipjan	\N
3156	125784	TRADITA T 1989 SH.P.K.-Vushtrri	\N
3157	010340	TRE Market SHPK-Pojate-Ferizaj	\N
3158	126141	Tree Pharmacy SH.P.K.-Prishtinë	\N
3159	125910	TREGU DITOR 2025 SH.P.K. (Frutaria 6 )	\N
3160	013517	Tregu Ditor DREDHËZA SH.P.K.-Skenderaj	\N
3161	125827	Tregu ditor EGZONI	\N
3162	006765	TREGU GROUP SHPK -Prishtine	\N
3163	125908	TREGU I FRESKËT SH.P.K.(Frutaria 4)	\N
3164	008127	TREGU I RI GJELBERT SHPK-Ferizaj	\N
3165	013024	Trgovina Ibar 24 D.O.O.-Zubin Potok	\N
3166	126327	TRI SESIRA 2022 D.O.O.	\N
3167	010563	Triangle Corporation SH.P.K.-Pejë	\N
3168	126050	TRIMAX MA SH.P.K.	\N
3169	007511	TRIMI DPT- Vushtrri	\N
3170	012795	TRIO HOUSE&GRILL SH.P.K.	\N
3171	999534	TRIO PIZZA SHPK-Obiliq	\N
3173	009263	TRIOSS GROUP SHPK-Mondo Prizeren	\N
3174	009976	TRIOSSGROUP SH.P.K.-Vushtrri	\N
3175	126428	TripleX Group SH.P.K.-Prishtine	\N
3176	013046	Trock SH.P.K.-Prishtinë	\N
3177	009894	Trock Taverna SHPK-Prishtine	\N
3178	010977	Trofta e Drinit SH.P.K.-Pejë	\N
3179	007108	TROFTA E DRINIT-NPSH Radavc Peje	\N
3180	000322	TROFTA RESTAURANT SHPK - Istog	\N
3181	013625	TROI MARKET 2024 SH.P.K.-Gjakovë	\N
3182	126179	Troi Market DO SH.P.K.	\N
3183	126498	Troi Restaurant SH.P.K.	\N
3184	125744	TROI STORE SH.P.K.-Prishtinë	\N
3185	000638	TROPIKAL NPT  - Deqan	\N
3186	005683	TROSHA SH.P.K - PRISHTINE	\N
3187	000641	TUBA GAVRAN - Gjilan	\N
3188	010696	Turist Kosova E Re SH.P.K.(NShtog)	\N
3189	008478	TUTTO PASTA SH.P.K.	\N
3190	010057	TWINS MARKET SH.P.K. -Fushë Kosovë	\N
3191	008511	TWO 2 SHPK-Fushë Kosovë	\N
3192	009796	UDA SHPK-Doganaj Kacanik	\N
3193	004338	UJE RUGOVE SHPK - PRISHTINE	\N
3194	000645	UJORI SHPK - Prishtine	\N
3195	000646	UKA  AS MARKET - Gjilan	\N
3196	126255	Umai Group SH.P.K.	\N
3198	009905	UN1K Market(Lirim HerticaB.I.)-Prishtine	\N
3199	125919	UNIC FOODS SH.P.K.	\N
3200	125995	Unico Coffe Brunch SH.P.K.	\N
3201	126440	Unik market SH.P.K.-Skenderaj	\N
3202	010560	UNIKERA SH.P.K.-Prizren	\N
3203	013506	UNIMIKS L.L.C.-Ferizaj	\N
3204	000650	UNION T - Peje	\N
3205	013491	UNION TRADITA U T SH.P.K.-Prishtinë	\N
3206	126329	Unipek 028 D.O.O.	\N
3207	009330	UNITRRGSO NPT-(Proper pizza)-Prizeren	\N
3208	010613	Univer SH.P.K.-Podujevë	\N
3209	005805	UNIVERSI PN SH.P.K. - PRISHTINË	\N
3210	000654	UNIVERTRADE Sh.P.K- Besiane	\N
3211	126154	UNO BAR SH.P.K.	\N
3212	008343	UNO PHARM SHPK-Prishtine	\N
3213	000658	URA - Ferizaj	\N
3214	000659	URA - SH NT - Gjilan	\N
3216	009638	URA Minimarket (A,Rexhepi BI)-Gllogoc	\N
3217	013713	URA PUB SH.P.K.-Prishtinë	\N
3218	013735	Urban Free Shop SH.P.K.-Prishtinë	\N
3219	009653	URBAN Gastrolounge SHPK-Prishtine	\N
3220	013787	Urban Market GMK SH.P.K.-Ferizaj	\N
3221	008458	URBAN MARKET SHPK - Vushtrri	\N
3222	005285	URBANO & FOOD CAFE N.H -PRISHTINE	\N
3223	125954	Usaj Market	\N
3224	012938	V & M MARKET SH.P.K.-Gjakovë	\N
3225	000662	V&V MARKET DPT - Peje	\N
3226	012470	VA Company L.L.C.	\N
3227	126367	Valbona D.p.h.	\N
3228	126430	Valdet Gegollaj B.I.	\N
3230	007631	VALDRINI D.P.T.- Peje	\N
3231	007998	VALDRINI SHPK-Peje	\N
3232	003417	VALENTINI- BISHTAZHIN	\N
3233	010544	VALERIANA PHARMACY SH.P.K-Prishtinë.	\N
3234	007164	VALI - R SH.P.K.-Lubeniq -Deqan	\N
3235	003570	VALI COMERC NT - LYPJAN	\N
3120	000409	TINA - Mitrovice	\N
3122	005378	TINA B - E NTP - GJILAN	\N
3123	000567	TINA N.T - GJILAN	\N
3124	000574	Tini D.p.t.-Arjeta Imeri B.I.	\N
3125	012566	TINI MARKET SH.P.K.-Ferizaj	\N
3126	100167	TINOGARA BAR SH.P.K.	\N
3127	010906	TINTIN SH.P.K.-Prishtinë	\N
3128	126280	Tipsy Lounge Bar SH.P.K.	\N
3129	007128	TIRONA SH.P.K.-Prishtine	\N
3130	000578	TITI  DPT - Emshir - Prishtine	\N
3131	000579	TOBACCO NTP -  Prizren Sh.P.K	\N
3132	000580	TOBACCO NTP - Prizren Sh.P.K	\N
3133	013704	Tobacco Shop A&K SH.P.K.-Gjakovë	\N
3134	010227	TOKS Coffee food  SHPK-Prishtine	\N
3136	004823	TONA DPT - Samadraxhe - Prizren	\N
3137	009255	Toni Caffe Bar-Prizeren	\N
3138	009723	TONI EEO SH.P.K.-Prishtinë	\N
3139	013552	TONI EVENT GROUP SH.P.K.-Lipjan	\N
3140	126200	Toni Fas SH.P.K.	\N
3141	009202	Toni GB DPT	\N
3142	000600	TONI GB Sh.P.K - Gjakove	\N
3143	000605	TONI MARKET D.P.T - Mitrovice	\N
3144	000603	TONI MARKET NTP - Ferizaj	\N
3145	000608	TONI MARKET SHPK - Kolovice - Prishtine	\N
3146	007239	TONI MARKET-3 SHPK-Prishtine	\N
3147	012539	TONI PEJA SH.P.K.-Pejë	\N
3148	002910	TOP DISTRIBUTION SH.P.K.	\N
3149	013030	TOP MARKET GROUP TMG SH.P.K.-Ferizaj	\N
3150	004084	TOP MARKET Sh.p.k. -PRISHTINE	\N
3151	003657	TOP STORE SHPK-MILLOSHEVE	\N
3270	126298	Venhar Haxhimustafa B.I.	\N
3268	000703	VENERA NTSH - Kline	\N
3271	012836	VENISI SHOP SH.P.K.-Prizren	\N
3272	009491	VENUS SH.P.K.	\N
3273	010775	VERA MARKET SH.P.K.(Mia Group)-Ferizaj	\N
3274	126334	VERANDA GRILL SH.P.K.	\N
3275	000707	VERONA DPT - Bregu i Diellit - Prishtine	\N
3276	013073	Verona Tullari B.I.(FSH Troi)-Prishtinë	\N
3277	125988	VËRRINI BaRe SH.P.K.	\N
3278	125929	Vertigo home lounge SH.P.K.	\N
3279	013511	VETERINARY PET HOME SH.P.K.-Ferizaj	\N
3280	126062	Veton Grapci B.I.	\N
3281	008596	VETON HAZIRI B.I.-Viti	\N
3282	000720	VICIANUM - Vushtrri	\N
3284	012413	Vigromi EN SH.P.K.-Prishtinë	\N
3285	002688	VIKTORIA NT - Skenderaj	\N
3286	009815	Viktoria Restaurant SHPK-Mitrovice	\N
3287	010748	VILLA BELI SH.P.K.-Skenderaj	\N
3288	009885	Villa Blinaja  VB-SHPK Gllogoc	\N
3289	010503	Villa Freskia SH.P.K.-Prishtinë	\N
3290	003290	Villa Germia - Prishtine	\N
3291	000725	VILLA MARIGONA SHPK- Lypjan	\N
3292	013774	Village Cafe SH.P.K.-Ferizaj	\N
3293	126333	Village Restaurant & Fauna L.L.C.	\N
3294	002648	VIPROS SHPK - Prishtine	\N
3295	126470	Visar I. Berisha B.I.	\N
3296	000729	VISARI - Kaqanik	\N
3297	125923	VISI DARDI MARKET SH.P.K.	\N
3299	012532	Vita Market Store SH.P.K.-Podujevë	\N
3300	126490	Vitafood  SH.P.K.	\N
3301	125932	VitaMix Group SH.P.K.	\N
3302	010988	VIVA AR PHARM SH.P.K.-Prishtinë	\N
3303	000015	VIVA FRESH Sh.p.k.	\N
3304	126088	VIVA PRO TEAM P.P	\N
3305	012797	Vizi Food KLD SH.P.K.	\N
3306	010554	Vjeshta market -Osek Hil	\N
3307	007775	VLAJA S.T.R-Kufce Gjilan	\N
3308	000752	VLERA DPT - Ferizaj	\N
3309	022217	VLERA NTP - Ferizaj	\N
3310	000757	VLL. MJEKU NTP Fatmir Mjeku B.I.	\N
3311	000761	VLL.HAJDINI-Buroj- Skenderaj	\N
3312	005004	VLLEZERIT HASANAJ - SAVROVE-THERANDE	\N
3313	005386	VLLEZERIT ZYMBERI -LIKOFC-SKENDERAJ	\N
3314	006976	VLORA ÇITAKU B.I.-Runik Skenderaj	\N
3315	010073	VLORA EEI(Enis Ilazi)-Ferizaj	\N
3317	126138	VLO'S L.L.C.	\N
3318	007421	VM3 SHPK-Emshir Prishtine	\N
3319	005294	VOCI NT - SHIROKE - THERANDE	\N
3320	000767	VOKSHI DPT - PRIZREN	\N
3321	003424	VOKSHI LB- DUJAKE- GJAKOVE	\N
3322	012531	VORTEX D.O.O.-Mitrovicë Veriore	\N
3323	126224	Voss Air L.L.C.-Fushë Kosovë	\N
3324	008176	VPD DRILL SHPK-Malisheve	\N
3325	009307	VRELLA MARKET SH.P.K.-Istog	\N
3326	125921	Vrrini Center SH.P.K.	\N
3327	010350	WALKER S FOOD SHPK-Prishtine	\N
3328	005184	WALKER S N.SH. - PRISHTINE	\N
3329	008746	WEST LIGHTS DPT-Suhareke	\N
3330	009848	WeterNick SHPK-Prshtine	\N
3331	126234	Wing D.p.h.	\N
3332	013334	Wise Guys Restaurant L.L.C.-Prishtinë	\N
3333	009108	Wonder Store SH.P.K.-Prishtinë	\N
3334	125841	WONDERLAND GROUP D.O.O.	\N
3335	013548	WORLD BUILDING CORPORATION SH.P.K.-Priz	\N
3336	011156	WOW discount-Prizren	\N
3337	012534	X&S Store SH.P.K.-Prishtinë	\N
3338	010228	XAXI Market SHPK-Mitrovice	\N
3340	004724	XHABIRI DPT - VUSHTRRI	\N
3341	000782	XHAXHI COM FORTES - Rahovec	\N
3342	008732	XHELA Market SHPK-Fushe Kosove	\N
3343	008763	XHELAL BEQIRI B.I.-Mitrovicë	\N
3344	000783	XHIDA - Kastriot	\N
3345	000788	XILI - Therande	\N
3346	010123	XILI & JONI SHPK-Prizeren	\N
3347	000789	XIMI  Sh.P.K- Vranjevc - Prishtine	\N
3348	012065	XVX Crossfit SH.P.K.-Prishtinë	\N
3349	008586	Y & Y Cosmetics - Prishtinë	\N
3350	126433	Yas 12 Cosmetics Shpk	\N
3351	009826	YASAM MARKET-Prizren, MAMUSHË	\N
3352	009390	YELLOW PHARMACY L.L.C-Fushe Kosove	\N
3237	004365	VALI IMPEX N.T SHPK	\N
3239	004923	VALI-R NTSH-Lumbardh-Decan	\N
3240	000680	VALMIRI DPT - Gjakove	\N
3238	000679	VALI-R NTSH-Lumbardh-Decan	\N
3242	012780	Valon I. Mehmeti B.I.-Vushtrri	\N
3241	125769	Valon Elan.M SH.P.K.-Gjilan	\N
3243	006752	VALON NASUFI B.I.	\N
3245	000681	VALONA SHPK - Prishtine	\N
3244	008341	VALON ZABELI B.I.-Skenderaj	\N
3247	000687	VALONI- Mitrovice	\N
3249	007975	VALONI PETROL  SHPK-Prishtine	\N
3250	000688	VALONI TRADE- Rahovec	\N
3248	007089	VALONI M-NTSHP-Poterc Kline	\N
3252	012954	VAMP COSMETICS SH.P.K.-Prishtinë	\N
3251	000689	VALTONI - Koretin- Kamenic	\N
3254	000693	VAROSHI - Varosh- Ferizaj	\N
3255	000694	VATANI MARKET - Burim-Istog	\N
3253	004916	VANESA T.F  DPT - GJAKOVE	\N
3257	013652	VAVI MARKET SH.P.K.-Ferizaj	\N
3258	012908	VB OIL SH.P.K.-Ferizaj	\N
3256	126124	Vault Restaurant Lounge Bar SH.P.K.	\N
3260	010564	Veda -2-Petroll SH.P.K.-Viti	\N
3261	013794	Vedat Mazreku B.I.-Malishevë	\N
3259	000700	VEBA MARKET - Gjilan	\N
3263	008434	VELA FISH SH.P.K.	\N
3262	001806	VELA FISH RESTORANT - Prishtine	\N
3266	010024	VENECIA PRO SHPK-Suhareke	\N
3267	008047	VENERA HOXHA B.I.-Peje	\N
3264	126008	Vëllezërit Çoçaj N.P.T	\N
3269	009937	VENEZZIA DPH-Prizeren	\N
3385	013525	Zymer Miftari B.I.-VEDA 3-Shupkovc Mitro	\N
3386	126371	Zyra e ambasades Kineze	\N
129	005348	**MERY S FOODS AND COFE NTH -PRISHTINE	\N
148	000695	**VATANI MARKET - Burim-Istog	\N
166	001248	A & B Market  L.Spitali  SHPK- Prishtine	\N
172	010883	ABA Market SH.P.K.-Prishtinë	\N
179	013463	Action Home Store L.L.C.-Klinë	\N
197	007593	AG MARKET(Agim M. Gashi B.I.)-Peje	\N
236	005435	ALBA PETROL SHPK-Fshati i Vjeter-Feriza	\N
254	013814	Albi Haxhismajli B.I.-Bora H3 market-Gj	\N
275	006661	ALLMAKES GLOBAL SERVICES - (Ideal Shala)	\N
290	009953	AMBAR SHPK-Prishtinë	\N
303	006294	AMIRI NTP - Vranjevc - Prishtine	\N
320	125730	Ani Super Market SH.P.K.-Prishtinë	\N
339	012962	Arbana Unique SH.P.K.-Prizren	\N
360	003410	ARDI BARNATORE- RAHOVEC	\N
376	002674	Arjeta Group SHPK(QTA)-Skenderaj	\N
395	013091	Arta 24 QARSHIA SH.P.K.-Prizren	\N
409	004511	Artoni D.P.T-Slivove Ferizaj	\N
425	002824	AURORA GROUP SHPK-  PRISHTINE	\N
445	013048	B Clean 2021 SH.P.K.-Prishtinë	\N
463	003723	BAJRAKTARI AB-Kline e eperme -Skenderaj	\N
484	001577	BANI NTP(Mefail Bytyqi) - Ferizaj	\N
501	012087	BARON Restaurant Ferizaj SH.P.K.	\N
522	012730	BEE TRADE GROUP L.L.C.-Mitrovicë	\N
526	012385	Behar E. Krasniqi B.I.-Malishevë	\N
541	126535	Belle Bakery & Caffe L.L.C.	\N
557	001655	BENI NTP  TREG - Prishtine	\N
595	009833	Besim Sh. Isufi B.I.-Prishtinë	\N
612	004748	BETA ING 2 N.SH.-MATI 1 - PRISHTINE	\N
631	001729	BINJAKET NTP- Smrekovnice -Mitrovice	\N
643	006114	Blend Market SHPK-Fushe Kosove	\N
656	012054	Blerta Dushi B.I. (Bake my Day)	\N
673	013806	Bloom Lounge Caffe and More SH.P.K.-Pri	\N
697	001780	BOSS MARKET DPT- Kolovice - Prishtine	\N
719	125865	Bronx Food Eatery BC L.L.C.	\N
735	007021	BUJARI MARKET -Sfeqel Besiane	\N
753	003563	BURSA STR - GUSHTERIC E POSHTME	\N
759	022175	BYTYQI DPT - Samadraxh - Suhareke	\N
769	000622	CAFFE Z + DPH -Prishtine	\N
786	013839	Casa DE Xiki SH.P.K.-Prishtinë	\N
804	012619	Chicken House Te Pula SH.P.K.	\N
821	013710	COFFEE PASTICERIA ORGESI PZ SH.P.K.-Pr	\N
844	012500	CURRI Market SH.P.K.-Gjakovë	\N
864	012860	D.P.T. " Te Agroni "-Podujevë	\N
877	002347	D.P.T.FRESH MARKET- Prishtine	\N
889	009987	DAILY DOSE by in caffe SHPK-Ferizaj	\N
907	009274	DASHMIR KRASNIQI B.I.-Prizeren	\N
926	008529	DELIA Cosmetics SHPK-Prishtine	\N
968	001953	DIONI NT TREG - Prishtine	\N
981	005549	DON CAFE HOUSE L.L.C-Veternik-Prishtine	\N
996	006162	DOWN TOWN SHPK - Prishtine	\N
1013	010710	DPT,, Isa "-Dobërqan Gjilan	\N
1029	002026	DRINI Sh.P. K- Dardani - Prishtine	\N
1048	013019	Ðus Market D.O.O.-Zubin Potok	\N
1067	009182	EBC Company SHPK-Prishtine	\N
1081	012847	Edita Haziri B.I.(IMAGE 1982)-Prishtinë	\N
1103	125753	EL 1 MARKET SH.P.K.-Fushë Kosovë	\N
1113	002116	ELDA MARKET - B.Diellit - Prishtine	\N
1117	011291	Eleganca Alb(Albi Reshitaj B.I.)Suhareke	\N
1136	010356	ELTIONI(Faton Lekaj B.I.)-Lipjan	\N
1154	013055	Endrit Tirolli B.I.(SYON BAR)-Kaçanik	\N
1178	126195	ENKO DPT Enis Dana B.I.	\N
1195	009079	ERTI NPT(Henor Gashi B.I.)Prishtine	\N
1212	002220	EURO MAX DPT- Rr.Bledit - Prishtine	\N
1232	126437	EvroTarget LLC	\N
1234	012472	Expres Market Store SH.P.K.-Prizren	\N
1271	008110	FATI DYNER DPH-Kaqanik	\N
1289	126462	Fellini Market SH.P.K.	\N
1303	010968	Fidan Fejzullahu B.I.-Mitrovicë	\N
1324	008120	FITIM BYTYÇI B.I.-Therande	\N
1340	009927	Flex Lounge Bar SH.P.K.-Prishtine	\N
1350	013681	Florin Gërçari B.I.-Gjakovë	\N
1361	012992	FREE SHOP & TOBACO XHEKI-Prizren	\N
3354	000800	YLLI DPT - Therande	\N
3355	126454	Ylli Dpt Islam Ymeri BI	\N
3356	000801	YLLI MARKET D.P.T. - Besiane	\N
3357	000796	YLLI N.P.T.- Bellanice - Malisheve	\N
3358	009641	YLLZA AH -Rahovec	\N
3359	000805	YLLZA NTP - Therande	\N
3360	126170	Yllza Sahitaj B.I.	\N
3361	000807	YMERI COMMERC - Xh.Ibish - Prishtine	\N
3362	006171	YMERI MARKET DPT - Prishtine	\N
3363	000806	YMERI NTP - Skivjan- Gjakove	\N
3364	012635	YMERII VH SH.P.K.-Gjakovë	\N
3365	012516	yummy pita SH.P.K.	\N
3366	126546	ZADE HOME BAR SH.P.K.	\N
3367	126142	ZALT DISTRIBUTION L.L.C.	\N
3368	012809	Zan Premium SH.P.K.	\N
3369	013734	Zana S. Rama B.I.-Mitrovicë	\N
3370	126302	Zane e luleve Sh.p.k.	\N
3371	013682	Zeka H. Temaj B.I.-Gjakovë	\N
3372	013482	ZEKAJ GROUP SH.P.K.-Pejë	\N
3373	007395	ZEM ZEM N.T.- Junik	\N
3374	007740	ZENELABEDIN ZLLANOGA  B.I.RAHOVEC	\N
3375	005052	ZEQA MARKET- SOPI-THERANDE	\N
3376	000817	Zeqir Rama B.I.- Hajvali-  Prishtine	\N
3377	012476	Zeqir Zeqiraj B.I.-Suharekë	\N
3378	000821	ZHABARLITË DPT - MITROVICË	\N
3380	000823	Zhili Commerce NTP - MITROVICË	\N
3381	000825	ZHURJANI 6 NPT - Zhur- Prizren	\N
3382	126511	Zllata SH.P.K.	\N
3383	009787	ZONE GROUP GjK SHPK-Gjakove	\N
3384	125845	Zucca VZ L.L.C.	\N
1917	010797	Lenti R SH.P.K.-Fushë Kosovë	\N
1935	001181	LILA COM  NTP - Therande	\N
1943	003312	LINDA MARKET- SKENDERAJ	\N
1953	009380	LIND'OR STEAKHOUSE SH.P.K.-Prizren	\N
1973	998303	LIVING CAFE AND FOOD SHPK-Prishtine	\N
1992	002473	LORIS  SHPK - Gjakove	\N
2009	013479	LUCKY GROUP SH.P.K.-Pejë	\N
2024	002497	LUMA COM(Nazim Kadriaj)- Prizren	\N
2044	012638	M&E MARKET SH.P.K.-Fushë Kosovë	\N
2062	004739	MALESIA MARKET N.P.T. - PODUJEVE	\N
2063	126565	Malesia Muhamet Maloku B.I	\N
2073	013058	MALVESA GROUP SH.P.K.-Fushë Kosovë	\N
2093	012529	Marigona Pharm SH.P.K.-Vushtrri	\N
2132	013827	MARKET KELMENDI SH.P.K.-Rahovec	\N
2154	013020	Market Plus 091 D.O.O.-Zubin Potok	\N
2171	010540	Market VANESSA( M.Simoni BI)-Pjetërshan	\N
2176	011320	Marlette SH.P.K.-Fushë Kosovë	\N
2183	009418	MATIN S Coffee SHPK-Prishtine	\N
2204	125883	Mehdi Gashi B.I.-N.T.P.SH.  Mega	\N
2221	996000	MENDI TRADE SH.P.K - PRISHTINE	\N
2239	002614	METRO MARKET DPT- Br Diellit-Prishtine	\N
2261	006586	MINIMARKET ANA SHPK - Prelluzhe	\N
2282	012856	MOKA 3 SH.P.K.-Prishtinë	\N
2294	126532	Mono Market Shpk	\N
2301	013796	Moon Caffe Kitchen SH.P.K.-Prishtinë	\N
2323	013391	Muharrem Kutllovci B.I.-Fushë Kosovë	\N
2345	013451	N.H.T. " SIRIUS "-B(Samir Ahmeti BI)-Pri	\N
2366	013438	N.T.P.Graniti-Astrit Haxhiu BI-Mitrovicë	\N
2386	002813	NATURAL PHARM - Prishtine(Trim Shala)	\N
2410	999226	Nese Mazrek B.I.(Elkebir)-Mamushe	\N
2412	000267	Nesim Qafleshi B.I.(N.T. " Çlirimi ")	\N
2417	010708	NEW POLLSON 2 SH.P.K.-Fushë Kosovë	\N
2439	126168	NITI AGB SH.P.K.-Malisheve	\N
2455	000123	NORI MARKET - Sopi - Therande	\N
2473	000127	NTP 7 Vellezerit(Fadil Sopa)- Lypjan	\N
2512	125717	ONI 3 CAPITAL SH.P.K.-Suharekë	\N
2531	000165	ORANGE 2 - Prishtine	\N
2532	125912	ORANGE FRUITS 2013 SH.P.K.(Frutaria 3)	\N
2552	012440	P.P. " Explosive Gr. " (S Gligorijevic)	\N
2573	008235	PASHTRIKU S DPZ  RAHOVEC	\N
2590	126012	Pepperoni Pizza SH.P.K.	\N
2603	013724	Pharma Point Partners SH.P.K.-Prishtinë	\N
2629	008766	PLAZA COSMETICS SHPK-Prizeren	\N
2645	005181	POTOK P.R. RESTAURANT - BREZOVICE	\N
2650	000233	PPFVD Shpk - Graqanice	\N
2662	126281	PREMIUM STORE SH.P.K.-MITROVICË	\N
2684	007919	Proka SH.P.K. - Prishtine	\N
2699	013485	Qëndrim Meha B.I.(Dpt Qendrimi)-Ferizaj	\N
2721	013434	REAL GRUP SH.P.K.-Skenderaj	\N
2738	007011	RERA COM SHPK-Kllokot Viti	\N
2752	013423	Restaurant Sofra e Gollakut SH.P.K.- Pr	\N
2765	012618	Restorant Bujana SH.P.K.	\N
2783	000336	RIFA N.P.T(Liridon Hyseni) - Viti	\N
2817	000375	RONA NTP -Bregu i Diellit - Prishtine	\N
2841	012952	S.T.R. '' COLMAR ''-Shtërpcë	\N
2862	008479	Sarajeva Steak House Sh.P.K	\N
2874	012765	Sejdi Miftari B.I.(Kollçak)-Prishtinë	\N
2883	013655	Seven Market L.L.C.-Graçanicë	\N
2894	000433	SHALQINI DPT - Therande	\N
2911	008026	SHKODRAN LATIFI B.I.-Prishtine	\N
2929	000472	SKENDA MARKET D.P - Prishtine	\N
2948	000478	SOLERO ICE DPH - Dardani - Prishtine	\N
2968	000481	SPEKTAR PP- (Dragan Josifovic)Gracanice-	\N
2987	009766	Stop Market(B.Tafarshiku B.I.) Gjakove	\N
3001	004425	Super Market Leandra SH.P.K.	\N
3003	013658	SUPER STAR - BA SH.P.K.-Prizren	\N
3020	004965	T.P.SANTOS(D.Nedeljkovic)-M.Veriore	\N
3040	009812	TARA COSMETICS(F.Gjikokaj)-Deçan	\N
3060	013823	TE AJA 2021 SH.P.K.-Prishtinë	\N
3100	000554	TEMPO PETROLL - Mramor- Prishtine	\N
3119	008969	TIKI BAR DPH-Prishtine	\N
3121	126086	Tina  N.T-Rexhep Aliu B.I.	\N
1394	995541	FRESH MARKET NPT- Berivojce-  Kamenice	\N
1417	002364	FRUTI MARKET- Dragodan - Prishtine	\N
1437	126289	Furra Kroni GLG SH.P.K.	\N
1454	126540	FURRE BUKE BUQI SH.P.K.	\N
1468	002379	GASHI SUPERMARKET NTP - Therande	\N
1479	013849	Gemb Bejtullahu B.I.-Gjakovë	\N
1499	011031	GETRADE L.L.C.-Prishtinë	\N
1534	010764	Golden Market SH.P.K.-Prishtinë	\N
1552	009306	GRAPE Gastropub Shpk-Prishtine	\N
1573	011270	Guri 1996 SH.P.K.-Ferizaj	\N
1587	013566	HALLALL - E.B. SH.P.K.-Pejë	\N
1600	005287	HAPPY MARKET SH.P.K. - FERIZAJ	\N
1617	007432	HEROLIND MUSTAFA B.I. Barnatore -Besiane	\N
1642	010299	Hotel Emerald SH.P.K.-Graçanicë	\N
1660	012528	Iden Cosmetics  DPT(A.Axhemi)Gjakovë	\N
1682	010933	IN Market XHA SH.P.K.-Ferizaj	\N
1700	013712	Ismailj Renda B.I.-ISO CHOCOLATE-Prizre	\N
1703	012061	Istanbul Baklava SH.P.K.	\N
1707	010568	IV cosmetics(Ivanka Sekulic B.I)-Graçan	\N
1731	008094	JETONI 2 DPT-Shapkovice Mitrovice	\N
1750	012811	K & A CATERING SH.P.K.	\N
1764	010525	KAMPIONI SHOPPING CENTER SH.P.K.-Poduj	\N
1808	006680	KLAS PPTU - Leposaviq	\N
1822	003910	KORABI DPT	\N
1823	001086	KORABI SHOW 2  SH.P.K.  - Vushtrri	\N
1839	001105	KRONI COMMERC  SHPK(I.Demaku) - Drenas	\N
1858	012963	L Bistro House SH.P.K.-Prishtinë	\N
1879	125842	LABORATORI I PATOLOGJISË PATHOLOGY	\N
1898	006874	LAVDA SHPK-FUSHE KOSOVE	\N
2800	012917	Risi Shop L.L.C.-Fushë Kosovë	\N
3077	000540	TE LUKI Sh.P.K - Prishtine - Xhemajl Ibi	\N
3135	000582	TOLI L  D.T - Ulpiane- Prishtine	\N
3154	011103	TOSSI MARKET SH.P.K.-Prishtinë	\N
3172	013702	Trio's 2024 Coffee & More SH.P.K.-Prizr	\N
3197	010991	UMAI SH.P.K.-Vushtrri	\N
199	012384	AGA CORPORATION L.L.C.	\N
214	007261	AGRO FIDANISHTJA HAVOLLI-Buroje Skendera	\N
308	011181	AN STORE SH.P.K.-Kaçanik	\N
309	008488	ANA PHARM SHPK-Fushe Kosove	\N
310	003546	ANDELA PP- LLAPNASELL	\N
311	126231	Ander BY Lenti SH.P.K.	\N
312	012507	ANDI & TONI SH.P.K.-Hani i Elezit	\N
313	001418	ANDI DPT - Gjakove	\N
314	013385	Andi Sport SH.P.K.-Gjilan	\N
315	012931	Andrijana Savic I.B.-Graçanicë	\N
316	003515	ANDRIJANA STR - GRAQANIC	\N
3215	008703	URA D.P.H.-Drenas	\N
3229	000667	VALDRILI MARKET - Kline	\N
3236	000676	VALI IMPEX - Prishtine	\N
3246	012909	VALONI Company SH.P.K.-Skenderaj	\N
317	012037	Anduen Berbati B.I.-Pejë	\N
571	005026	BESA - 2 NT(Arbon Kyqzku )-HANI I ELEZIT	\N
741	006136	BULZA NTP - Ferizaj	\N
3265	010898	VENDUM SH.P.K.-Prishtinë	\N
3283	008767	VIGAN BEGOLII B.I.-Peje	\N
3298	005995	VISI MARKET NTP - Kolovice -Prishtine	\N
947	007428	DIAMBE KOSOVA SHPK - Graqanice	\N
1114	010074	ELDI R Market SHPK-Gadime Lipjan	\N
1250	010058	FADIL REXHA B.I.-Barileve BESIANË	\N
3316	125767	Vlora Kadrolli B.I.-DPH Druri-\tPrishtinë	\N
3339	000776	XENI COMMERCE(B.Popaj) - Xerxe- Rahovec	\N
3353	013663	Ylli Beqa B.I.-Shtime	\N
3379	012520	ZHILI Co SH.P.K.-Mitrovicë	\N
40	002872	**BUTRINTI MARKET DPT - Çagllavice	\N
42	003551	**BYQMA DPT - HAJVALI	\N
43	001861	**CHEBAR BISTRO - Prishtine	\N
1257	008487	FAMILY PARK D.P.H.-Prishtine	\N
1258	008964	FAMILY PHARM SHPK-Pejë	\N
1259	010908	FAMILY STORE SH.P.K.-Ferizaj	\N
1260	013089	Famous Famiglia 1-Prizren	\N
1261	002244	FANA DPT  - Prishtine	\N
1262	011188	FANA MARKET-Bardhosh Prishtinë	\N
1269	002255	FATI - Shajkovc- Besiane	\N
1270	002258	FATI DPT - Ferizaj	\N
44	001926	**DEMPING - Runik- Skenderaj	\N
1353	013471	Foleja Foods L.L.C.-Vapiano - Graçanicë	\N
1380	004231	FREE SHOP SHEHOLLI SH.P.K.	\N
1470	125716	GASTRONOMIX SH.P.K.-Graçanicë	\N
1514	012572	Gjane Karaqi B.I.(Dasmori)-Gjakovë	\N
1705	007184	ISTANBUL TATLISES DONER LAHMACU DPH	\N
1786	001050	KELMENDI- E  N.P.-B.Diellit - Prishtine	\N
1814	001068	KOHA DPT - Bregu i Diellit - Prishtine	\N
45	006938	**DINI MARKET DPT-LLUGE PODUJEVE	\N
46	004091	**DPT DIONI - LYPJAN	\N
47	002021	**DRILONI NTP  - Mitrovice	\N
1841	001279	KRONI MARKET-  L.Spitalit - Prishtine	\N
2109	012405	MARKET BESNIKU PLUS SH.P.K. -Novobërdë	\N
2237	009487	METI Market (Burim Bytyqi)B.I.-Suharekë	\N
2413	010254	Neto Market(Gëzim Javori B.I.)-Malishev	\N
2491	007901	OKI'S CANDY CORNER SHPK-Prishtine	\N
\.


--
-- Data for Name: divisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.divisions (id, name, default_team_leader_id) FROM stdin;
1	Kozmetike	\N
2	Ushqimore	\N
3	NESTLE	\N
4	FRESH	\N
5	PIJE&KONDITORI	\N
6	HIGJIENE	\N
7	ESENCIALE	\N
18	KOZMETIKE	\N
\.


--
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ip_whitelist (id, cidr, label, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: known_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.known_devices (id, user_id, fingerprint, ip, label, first_seen, last_seen) FROM stdin;
13	2	ce1f2c3bab55a9b9	172.18.0.1	Auto-detected	2026-03-21 12:18:07.191618+00	2026-03-21 12:18:07.191618+00
15	2	2671bfa65f8d62af	172.18.0.1	Auto-detected	2026-03-21 12:40:43.179205+00	2026-03-21 12:54:17.366246+00
4	2	112bda24c0d7a445	172.18.0.1	Auto-detected	2026-03-20 22:58:06.088286+00	2026-03-21 17:08:05.4125+00
14	5	2671bfa65f8d62af	172.18.0.1	Auto-detected	2026-03-21 12:39:11.317822+00	2026-03-21 17:38:07.642915+00
2	5	112bda24c0d7a445	172.18.0.1	Auto-detected	2026-03-20 20:07:22.749042+00	2026-03-21 18:38:56.128456+00
16	1	ce1f2c3bab55a9b9	172.18.0.1	Auto-detected	2026-03-21 18:51:51.403852+00	2026-03-21 18:54:13.013275+00
3	5	ce1f2c3bab55a9b9	172.18.0.1	Auto-detected	2026-03-20 21:51:17.775231+00	2026-03-21 18:54:39.280293+00
1	1	112bda24c0d7a445	172.18.0.1	Auto-detected	2026-03-20 20:06:13.274887+00	2026-03-20 22:47:26.886669+00
5	4	112bda24c0d7a445	172.18.0.1	Auto-detected	2026-03-20 22:59:10.682087+00	2026-03-20 22:59:10.682087+00
7	1	0b7357435a30445b	172.18.0.1	Auto-detected	2026-03-20 23:27:35.709185+00	2026-03-20 23:27:35.709185+00
8	5	0b7357435a30445b	172.18.0.1	Auto-detected	2026-03-20 23:27:56.337131+00	2026-03-20 23:27:56.337131+00
10	3	339e6d9076c791e7	172.18.0.1	Auto-detected	2026-03-21 00:55:15.340861+00	2026-03-21 00:55:15.340861+00
12	2	339e6d9076c791e7	172.18.0.1	Auto-detected	2026-03-21 11:17:56.813988+00	2026-03-21 11:17:56.813988+00
9	4	339e6d9076c791e7	172.18.0.1	Auto-detected	2026-03-20 23:37:41.570467+00	2026-03-21 11:18:44.504661+00
11	1	339e6d9076c791e7	172.18.0.1	Auto-detected	2026-03-21 00:56:18.357593+00	2026-03-21 11:19:34.659114+00
6	5	339e6d9076c791e7	172.18.0.1	Auto-detected	2026-03-20 23:21:44.265818+00	2026-03-21 12:07:34.01634+00
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, user_id, token, expires_at, revoked, created_at) FROM stdin;
12	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwMzg2MjUsImV4cCI6MTc3NjYzMDYyNX0.c8Y3iNY41F2ykV1wNDOR7FSZ5xtbwMKNgi8KZ008q0g	2026-04-19 20:30:25.5+00	f	2026-03-20 20:30:25.501508+00
13	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwMzg2MzgsImV4cCI6MTc3NjYzMDYzOH0.W2O8AgSiu_GsrBKkb05yXysEYOQIqzTKglA7TKMEBi0	2026-04-19 20:30:38.216+00	f	2026-03-20 20:30:38.21679+00
21	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDAwNjksImV4cCI6MTc3NjYzMjA2OX0.SgVAeDix_MMJFiz_dnVXxHBmdSSqMSGotutda26F4X8	2026-04-19 20:54:29.121+00	f	2026-03-20 20:54:29.121643+00
23	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDIxMjQsImV4cCI6MTc3NjYzNDEyNH0.odFhymsMySr8kh0epE03fHmOK2J-Oe7P5ZLPiDBhaD8	2026-04-19 21:28:44.667+00	f	2026-03-20 21:28:44.668083+00
24	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDIzNzEsImV4cCI6MTc3NjYzNDM3MX0.Rs9RNFn35Nf4AJITL_Zu4MM4AVYol25nnYdNzbmiqn8	2026-04-19 21:32:51.328+00	f	2026-03-20 21:32:51.32902+00
26	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDMwMjMsImV4cCI6MTc3NjYzNTAyM30.y73xhKF_M9RBFRUgLprIMgSERK_ELilU6aXPaFmucF8	2026-04-19 21:43:43.406+00	f	2026-03-20 21:43:43.40714+00
29	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDM0MjksImV4cCI6MTc3NjYzNTQyOX0.S3fLpD4CqFA2RUMRi4ucFaZLoCPqOVBQVsJMT0bURUs	2026-04-19 21:50:29.879+00	f	2026-03-20 21:50:29.880155+00
30	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDM0NzcsImV4cCI6MTc3NjYzNTQ3N30.MwNi6s6KIQ3A2TBN6TV7q1wHT-yVtc0VViXxWEIPVuE	2026-04-19 21:51:17.802+00	f	2026-03-20 21:51:17.803248+00
31	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDUxNjAsImV4cCI6MTc3NjYzNzE2MH0.pRr3XbZaB-ns52bhdqP0rhQB97i5olr-70eQdrIPXJ8	2026-04-19 22:19:20.961+00	f	2026-03-20 22:19:20.961903+00
34	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDU2NTMsImV4cCI6MTc3NjYzNzY1M30.MLIskE32o3fW-IqsEqDWFTCLDNYAC9d2Ndql7xMY1SU	2026-04-19 22:27:33.808+00	f	2026-03-20 22:27:33.808286+00
35	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDYxNDgsImV4cCI6MTc3NjYzODE0OH0.XvbM3lopN5iXLcq8OGcmdodzUNulDv1F3Xl-TcKla6Q	2026-04-19 22:35:48.806+00	f	2026-03-20 22:35:48.806755+00
36	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDYxNzAsImV4cCI6MTc3NjYzODE3MH0.z6L2DH0RPnBmPz24eT0esrWXzxYLLC6D0ijHBb5NKkI	2026-04-19 22:36:10.025+00	f	2026-03-20 22:36:10.025508+00
37	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDYyOTcsImV4cCI6MTc3NjYzODI5N30.-kHraPlDUn6CUdCSal8qSX5r0z3jDjQplBGcs0AA0pk	2026-04-19 22:38:17.204+00	f	2026-03-20 22:38:17.204685+00
38	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDY0MTQsImV4cCI6MTc3NjYzODQxNH0.ucTUxcPLh3GVE0O12lHykB0u84lUBbaFHGdeJELURIM	2026-04-19 22:40:14.28+00	f	2026-03-20 22:40:14.280565+00
39	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDY0NDEsImV4cCI6MTc3NjYzODQ0MX0.qnJ6EojzbNHoKUy3TtYtkCxHooOxTFA-p3gJuoFLWmk	2026-04-19 22:40:41.282+00	f	2026-03-20 22:40:41.282575+00
41	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDY4NzQsImV4cCI6MTc3NjYzODg3NH0.MMqnlPZX9Hl5FKqZQKGTpCmcNhg-WgAOYhvmjHU1i98	2026-04-19 22:47:54.148+00	f	2026-03-20 22:47:54.148658+00
42	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDcxMzksImV4cCI6MTc3NjYzOTEzOX0.QaiOr8HXp57Td4hpZ4hj2BWrEmtJQ3Qa0Rz74UTW7Ko	2026-04-19 22:52:19.875+00	f	2026-03-20 22:52:19.875465+00
70	2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTY4NDMsImV4cCI6MTc3NjY4ODg0M30.zqQ6YG-8YZZ1Y-9lJKZicUCaN8NbZTWibDqMgv34LU4	2026-04-20 12:40:43.184+00	f	2026-03-21 12:40:43.18473+00
45	4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDc1NTAsImV4cCI6MTc3NjYzOTU1MH0.UBXAAUDfYhyIKdFm82nMzESTV0sbCPhLhSVzxBwnB9U	2026-04-19 22:59:10.687+00	f	2026-03-20 22:59:10.687548+00
46	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDc3NjAsImV4cCI6MTc3NjYzOTc2MH0.K9DMRUSmb-yXL7js044N-UV6qIVRXpBC8nIEJoHi8tg	2026-04-19 23:02:40.544+00	f	2026-03-20 23:02:40.545189+00
48	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDkxMTUsImV4cCI6MTc3NjY0MTExNX0.XUc9tyI-xMgMx7-b_6ZmaUOXkk_ImNxfXNlJ08f9VV0	2026-04-19 23:25:15.277+00	f	2026-03-20 23:25:15.277763+00
49	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDkyNTUsImV4cCI6MTc3NjY0MTI1NX0.I-h4kXV8PDL5B4E7eWV0s2HnaYtN4UImEuPDsAGkL_w	2026-04-19 23:27:35.718+00	f	2026-03-20 23:27:35.718333+00
50	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNDkyNzYsImV4cCI6MTc3NjY0MTI3Nn0.l4OaA1N4gYJ6urf6WRBP539sZEW6tSPOj5E8ulXtCp4	2026-04-19 23:27:56.345+00	f	2026-03-20 23:27:56.345507+00
71	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTc1NTUsImV4cCI6MTc3NjY4OTU1NX0.2aH85BFCR0aQWmU_Jyv_TYjH_cJUlQcueqfDFfa0cIg	2026-04-20 12:52:35.918+00	f	2026-03-21 12:52:35.91891+00
54	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwNTQ1NzgsImV4cCI6MTc3NjY0NjU3OH0.nBPSKRTMwue1N7nQbc7p209qd1QLqhnR0P4G3U-KOMc	2026-04-20 00:56:18.366+00	f	2026-03-21 00:56:18.366951+00
62	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTQ4NTQsImV4cCI6MTc3NjY4Njg1NH0.XMqv6wiIADt0ni0X-vxOAxMoEYqF4zmr2J74NNcecQ0	2026-04-20 12:07:34.022+00	f	2026-03-21 12:07:34.022637+00
63	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTQ5NzMsImV4cCI6MTc3NjY4Njk3M30.z_bxV1YSYKkeg4ueIh_-kVz2LZdkUTeti-khSu21puQ	2026-04-20 12:09:33.554+00	f	2026-03-21 12:09:33.554477+00
64	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTUzODIsImV4cCI6MTc3NjY4NzM4Mn0.vKoLjRVyXT6CMwXqSaOOpF6g_rswSsZfyXDo-h9CuZE	2026-04-20 12:16:22.866+00	f	2026-03-21 12:16:22.866792+00
67	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTU2MjksImV4cCI6MTc3NjY4NzYyOX0.H0xh5z60FPRgXGHNa4HBzqmarM7R2MDio_Xlkj6IVNw	2026-04-20 12:20:29.154+00	f	2026-03-21 12:20:29.155035+00
68	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTY2OTQsImV4cCI6MTc3NjY4ODY5NH0.exUWm3wBzOMiiLaHrYcYgr-ofoqMRV0sBTeb6nGFu2g	2026-04-20 12:38:14.965+00	f	2026-03-21 12:38:14.965288+00
74	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQwOTgwMzQsImV4cCI6MTc3NjY5MDAzNH0.-b8F1LlKSprml0skCL_EkpCChKb_LHHwAtE0x5gM0Fc	2026-04-20 13:00:34.727+00	f	2026-03-21 13:00:34.727528+00
78	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTMxNzcsImV4cCI6MTc3NjcwNTE3N30.AMdS5n5O_S_EQoobALVn-klo-QrAMI5QZKUVsgDKJxk	2026-04-20 17:12:57.304+00	f	2026-03-21 17:12:57.305098+00
79	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTM1MTIsImV4cCI6MTc3NjcwNTUxMn0.1SCBxPyOPoYBaALtZKvF9jyXNEE-3axYVmWW4Bt6b9s	2026-04-20 17:18:32.072+00	f	2026-03-21 17:18:32.072704+00
80	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTM2MDMsImV4cCI6MTc3NjcwNTYwM30.dYKDY_oEmcpLgXt_a98JArli15FmEtiA3JVShXbJTmk	2026-04-20 17:20:03.287+00	f	2026-03-21 17:20:03.287648+00
82	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTQ1NzgsImV4cCI6MTc3NjcwNjU3OH0._9SoryjH6BKz1B1zwJX1YVhqy6Olq3jLWQ2h6Mu5WLU	2026-04-20 17:36:18.031+00	f	2026-03-21 17:36:18.032133+00
83	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTQ2ODcsImV4cCI6MTc3NjcwNjY4N30.cGnkq05TFiCYdrsYPiGEiMGflZTGgCo_sUqE7AakWRg	2026-04-20 17:38:07.648+00	f	2026-03-21 17:38:07.648692+00
84	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTUxNzMsImV4cCI6MTc3NjcwNzE3M30.VD9N2Tr8MDBAro_SZCsgjDgiuvCk_HjD2aupN4uGyew	2026-04-20 17:46:13.999+00	f	2026-03-21 17:46:13.999567+00
85	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTYyMjQsImV4cCI6MTc3NjcwODIyNH0.4VbtxtiCc-qw5U7GMytD23C4M5o7E0T2Yv3fkwtf7CE	2026-04-20 18:03:44.25+00	f	2026-03-21 18:03:44.250424+00
86	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTc1MTMsImV4cCI6MTc3NjcwOTUxM30.UN8j65E8GPoZspsa0hrD7Mfc6JezrUIVncWMlKM8AuA	2026-04-20 18:25:13.149+00	f	2026-03-21 18:25:13.149602+00
87	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTc4NzQsImV4cCI6MTc3NjcwOTg3NH0.4Zkj4Zy3hsyg3bslCUsQItwM5qWG9GEnm7BJWKVcOiQ	2026-04-20 18:31:14+00	f	2026-03-21 18:31:14.000742+00
88	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTgzMzYsImV4cCI6MTc3NjcxMDMzNn0.BCw-9kPQOgVh5njHWHad7Ew2LS6OqT23EqqVJtOk5FQ	2026-04-20 18:38:56.134+00	f	2026-03-21 18:38:56.135044+00
89	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTg0MDksImV4cCI6MTc3NjcxMDQwOX0.tw-cxFWKj4NREmpr5FOGlXHdv1_NVEoZKNJrUQgl4m8	2026-04-20 18:40:09.3+00	t	2026-03-21 18:40:09.300884+00
90	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTkxMTEsImV4cCI6MTc3NjcxMTExMX0.d-2k6g-WCBpbDBAZ0Aa6qGgZIulX-D-v2Z-oxUYoilg	2026-04-20 18:51:51.413+00	f	2026-03-21 18:51:51.414061+00
91	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTkyNTMsImV4cCI6MTc3NjcxMTI1M30.wUj3M6Klqcy0x9J5TJONyW18w0PELLRqHuMBlgikaZg	2026-04-20 18:54:13.021+00	f	2026-03-21 18:54:13.02196+00
92	5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwidHlwZSI6InJlZnJlc2giLCJpYXQiOjE3NzQxMTkyNzksImV4cCI6MTc3NjcxMTI3OX0.bhbIk1rz6at_QBN23IjRFMo-ZN_BLlS-hAJBv1ffAJY	2026-04-20 18:54:39.287+00	f	2026-03-21 18:54:39.287536+00
\.


--
-- Data for Name: report_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_runs (id, period, ran_at, status, detail) FROM stdin;
\.


--
-- Data for Name: request_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request_comments (id, request_id, user_id, body, created_at, edited_at) FROM stdin;
1	7	5	Test bardhi	2026-03-21 11:17:42.597144+00	\N
2	7	2	Test	2026-03-21 11:18:21.24482+00	\N
\.


--
-- Data for Name: request_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request_items (id, request_id, article_id, quantity, line_amount, created_at, barkod, lot_kod, cmimi_baze, rabat_pct, ddv_pct, cmimi_pas_rabateve, price_match_level, sifra_kup, sifra_obj, lejim_pct) FROM stdin;
1	1	3	15	0.00	2026-03-20 20:19:46.516381+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	2	3	12	0.00	2026-03-20 20:22:42.089723+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	3	38401	1	0.99	2026-03-20 22:57:56.740632+00	8718951577039                                     	5289it101a	1.364000	27.4893	18.0000	0.989046	buyer-object-article-lot	000007	11	\N
4	4	38401	1	0.99	2026-03-20 23:24:24.435753+00	8718951577039                                     	281124IT101a	1.299000	23.7880	18.0000	0.989994	buyer-article-lot	000007	32	\N
5	5	38401	13	12.85	2026-03-20 23:28:45.456707+00	8718951577039                                     	281	1.364000	27.5526	18.0000	0.988182	buyer-object-article	000007	8	\N
6	6	38401	12	11.87	2026-03-20 23:36:56.135993+00	8718951577039                                     	281	1.364000	27.4595	18.0000	0.989452	buyer-object-article	000018	20	\N
7	7	47577	12	51.88	2026-03-21 11:17:18.920473+00	8445291259355                                     	50180973y	5.713000	24.3232	18.0000	4.323416	buyer-object-article-lot (avg 7 dok)	000015	1	\N
8	8	47577	12	52.09	2026-03-21 12:17:52.301153+00	8445291259355                                     	60310973Y	5.713000	24.0179	18.0000	4.340856	buyer-article-lot (avg 5 dok)	000007	10804	\N
9	9	38401	12	11.86	2026-03-21 12:40:24.907635+00	8718951577039                                     	5295it10qa	1.364000	27.5526	18.0000	0.988182	buyer-object-article-lot	000007	8	\N
10	10	38401	12	11.86	2026-03-21 12:54:06.628917+00	8718951577039                                     	5295it10qa	1.364000	27.5526	18.0000	0.988182	buyer-object-article-lot	000007	8	\N
11	11	38401	1	1.00	2026-03-21 17:00:22.997405+00	8718951577039                                     	5295	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	\N
12	12	38401	22	22.09	2026-03-21 17:10:27.759124+00	8718951577039                                     	5295it	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	\N
13	13	38401	11	11.05	2026-03-21 17:19:41.225253+00	8718951577039                                     	589	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	0.0000
14	14	38401	12	12.05	2026-03-21 17:20:56.45501+00	8718951577039                                     	589	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	15.0000
15	15	38401	1	1.00	2026-03-21 17:32:22.358044+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	11.0000
16	16	38401	1	1.03	2026-03-21 17:37:26.535563+00	8718951577039                                     	529	1.366434	24.6014	18.0000	1.030121	buyer-object-article (avg 88 dok)	000015	1	3.0000
17	17	38401	1	1.00	2026-03-21 17:42:09.921944+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
18	18	38401	1	1.00	2026-03-21 17:46:57.929814+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
19	19	38401	1	1.00	2026-03-21 18:04:28.385007+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
20	20	38401	1	1.00	2026-03-21 18:26:10.316022+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
21	21	38401	1	1.00	2026-03-21 18:32:03.394121+00	8718951577039                                     	578	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
22	22	38401	1	1.00	2026-03-21 18:39:43.480748+00	8718951577039                                     	529	1.349057	25.5434	18.0000	1.004199	buyer-object-article (avg 5 dok)	000007	8	2.0000
\.


--
-- Data for Name: request_photos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request_photos (id, request_id, url, created_at) FROM stdin;
1	2	/uploads/1774038162065-wjfwqzo4ex.jpg	2026-03-20 20:22:42.092985+00
2	2	/uploads/1774038162066-9ypw4uedtah.jpg	2026-03-20 20:22:42.092985+00
3	3	/uploads/1774047476698-nwheokr2ftg.jpg	2026-03-20 22:57:56.744608+00
4	3	/uploads/1774047476699-cwnxjhl8pqi.jpg	2026-03-20 22:57:56.744608+00
5	8	/uploads/1774095472259-478z4vndgfo.jpg	2026-03-21 12:17:52.304556+00
6	8	/uploads/1774095472260-hp49j8ewsck.jpg	2026-03-21 12:17:52.304556+00
7	8	/uploads/1774095472261-0vsydal252r.jpg	2026-03-21 12:17:52.304556+00
8	9	/uploads/1774096824871-v6s7ze3773.jpg	2026-03-21 12:40:24.910732+00
9	9	/uploads/1774096824872-jca8n1khtld.jpg	2026-03-21 12:40:24.910732+00
10	9	/uploads/1774096824873-zbq1unqh76.jpg	2026-03-21 12:40:24.910732+00
11	10	/uploads/1774097646603-2dq0ko5t8xv.jpg	2026-03-21 12:54:06.631284+00
12	10	/uploads/1774097646604-o79strriqhq.jpg	2026-03-21 12:54:06.631284+00
13	11	/uploads/1774112422962-1siyevcq7q1.jpg	2026-03-21 17:00:23.000981+00
14	11	/uploads/1774112422962-5u3zpds9uk3.jpg	2026-03-21 17:00:23.000981+00
15	11	/uploads/1774112422962-tgz5umv6kw.jpg	2026-03-21 17:00:23.000981+00
16	11	/uploads/1774112422962-1n88rm2egqx.jpg	2026-03-21 17:00:23.000981+00
17	12	/uploads/1774113027732-vuoamo1ykxf.jpg	2026-03-21 17:10:27.761224+00
18	13	/uploads/1774113581191-9n2f75uw4d.jpg	2026-03-21 17:19:41.235254+00
19	13	/uploads/1774113581191-9wg3potv3s7.jpg	2026-03-21 17:19:41.235254+00
20	15	/uploads/1774114342328-tlesue3m9p.jpg	2026-03-21 17:32:22.360872+00
21	15	/uploads/1774114342329-q55dk4stl4.jpg	2026-03-21 17:32:22.360872+00
22	16	/uploads/1774114646505-fylu3ebmnqa.jpg	2026-03-21 17:37:26.538558+00
23	17	/uploads/1774114929895-3brexfqpqlz.jpg	2026-03-21 17:42:09.924736+00
24	17	/uploads/1774114929896-6igyq8rhwz5.jpg	2026-03-21 17:42:09.924736+00
25	18	/uploads/1774115217899-ihbywiwvk6o.jpg	2026-03-21 17:46:57.932203+00
26	18	/uploads/1774115217899-hnkbezeu64.jpg	2026-03-21 17:46:57.932203+00
27	19	/uploads/1774116268359-p5qlabx3ad.jpg	2026-03-21 18:04:28.387988+00
28	19	/uploads/1774116268360-ol0ej7mlzc.jpg	2026-03-21 18:04:28.387988+00
29	20	/uploads/1774117570281-3vuwazc8hut.jpg	2026-03-21 18:26:10.319292+00
30	21	/uploads/1774117923371-v1dv5wku8e.jpg	2026-03-21 18:32:03.396357+00
31	22	/uploads/1774118383457-36kdmmati7g.jpg	2026-03-21 18:39:43.483283+00
\.


--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requests (id, agent_id, division_id, buyer_id, site_id, article_id, quantity, amount, invoice_ref, reason, status, required_role, created_at, assigned_to_user_id, assigned_reason, assigned_at, photo_url) FROM stdin;
1	5	1	3005	\N	\N	\N	0.00	\N	\N	pending	team_lead	2026-03-20 20:19:46.510905+00	2	fallback.team_lead	2026-03-20 20:19:46.51+00	\N
2	5	1	3005	\N	\N	\N	0.00	asd	\N	pending	team_lead	2026-03-20 20:22:42.085152+00	2	fallback.team_lead	2026-03-20 20:22:42.084+00	/uploads/1774038162065-wjfwqzo4ex.jpg
3	5	1	1201	10809	\N	\N	0.99	asd	asd	approved	team_lead	2026-03-20 22:57:56.732984+00	2	fallback.team_lead	2026-03-20 22:57:56.732+00	/uploads/1774047476698-nwheokr2ftg.jpg
4	5	1	1201	10788	\N	\N	0.99	\N	\N	pending	team_lead	2026-03-20 23:24:24.431497+00	2	fallback.team_lead	2026-03-20 23:24:24.431+00	\N
5	5	1	1201	10804	\N	\N	12.85	\N	\N	pending	team_lead	2026-03-20 23:28:45.453232+00	2	fallback.team_lead	2026-03-20 23:28:45.453+00	\N
6	5	1	3005	1266	\N	\N	11.87	As	As	pending	team_lead	2026-03-20 23:36:56.132948+00	2	fallback.team_lead	2026-03-20 23:36:56.132+00	\N
7	5	1	3303	1439	\N	\N	51.88	Asd	Asd	approved	team_lead	2026-03-21 11:17:18.908501+00	2	fallback.team_lead	2026-03-21 11:17:18.907+00	\N
8	5	1	1201	10804	\N	\N	52.09	\N	\N	approved	team_lead	2026-03-21 12:17:52.295098+00	2	fallback.team_lead	2026-03-21 12:17:52.294+00	/uploads/1774095472259-478z4vndgfo.jpg
9	5	1	1201	10804	\N	\N	11.86	asd	asd	approved	team_lead	2026-03-21 12:40:24.903249+00	2	fallback.team_lead	2026-03-21 12:40:24.903+00	/uploads/1774096824871-v6s7ze3773.jpg
10	5	1	1201	10804	\N	\N	11.86	aasda	sddddddd	approved	team_lead	2026-03-21 12:54:06.62597+00	2	fallback.team_lead	2026-03-21 12:54:06.625+00	/uploads/1774097646603-2dq0ko5t8xv.jpg
11	5	1	1201	10804	\N	\N	1.00	asd	asd	approved	team_lead	2026-03-21 17:00:22.993688+00	2	fallback.team_lead	2026-03-21 17:00:22.993+00	/uploads/1774112422962-1siyevcq7q1.jpg
12	5	1	1201	10804	\N	\N	22.09	asd	asd	pending	team_lead	2026-03-21 17:10:27.755742+00	2	fallback.team_lead	2026-03-21 17:10:27.755+00	/uploads/1774113027732-vuoamo1ykxf.jpg
13	5	1	1201	10804	\N	\N	11.05	asd	asd	pending	team_lead	2026-03-21 17:19:41.221956+00	2	fallback.team_lead	2026-03-21 17:19:41.221+00	/uploads/1774113581191-9n2f75uw4d.jpg
14	5	1	1201	10804	\N	\N	12.05	\N	\N	pending	team_lead	2026-03-21 17:20:56.451727+00	2	fallback.team_lead	2026-03-21 17:20:56.451+00	\N
15	5	1	1201	10804	\N	\N	1.00	\N	\N	pending	team_lead	2026-03-21 17:32:22.355295+00	2	fallback.team_lead	2026-03-21 17:32:22.355+00	/uploads/1774114342328-tlesue3m9p.jpg
16	5	1	3303	1439	\N	\N	1.03	\N	\N	pending	team_lead	2026-03-21 17:37:26.531858+00	2	fallback.team_lead	2026-03-21 17:37:26.531+00	/uploads/1774114646505-fylu3ebmnqa.jpg
17	5	1	1201	10804	\N	\N	1.00	\N	\N	pending	team_lead	2026-03-21 17:42:09.918758+00	2	fallback.team_lead	2026-03-21 17:42:09.918+00	/uploads/1774114929895-3brexfqpqlz.jpg
18	5	1	1201	10804	\N	\N	1.00	asd	asd	pending	team_lead	2026-03-21 17:46:57.926616+00	2	fallback.team_lead	2026-03-21 17:46:57.926+00	/uploads/1774115217899-ihbywiwvk6o.jpg
19	5	1	1201	10804	\N	\N	1.00	asd	asddddddddddddddddd	pending	team_lead	2026-03-21 18:04:28.381468+00	2	fallback.team_lead	2026-03-21 18:04:28.381+00	/uploads/1774116268359-p5qlabx3ad.jpg
20	5	1	1201	10804	\N	\N	1.00	asad	\N	pending	team_lead	2026-03-21 18:26:10.31289+00	2	fallback.team_lead	2026-03-21 18:26:10.312+00	/uploads/1774117570281-3vuwazc8hut.jpg
21	5	1	1201	10804	\N	\N	1.00	asd	asd	pending	team_lead	2026-03-21 18:32:03.391276+00	2	fallback.team_lead	2026-03-21 18:32:03.391+00	/uploads/1774117923371-v1dv5wku8e.jpg
22	5	1	1201	10804	\N	\N	1.00	asd233333	asd233333	pending	team_lead	2026-03-21 18:39:43.478091+00	2	fallback.team_lead	2026-03-21 18:39:43.477+00	/uploads/1774118383457-36kdmmati7g.jpg
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, token_hash, device_name, ip, user_agent, last_active, created_at, revoked) FROM stdin;
84	5	51415b0cde6edfd81c573a8f0dff7d26b3662142b0a16474c941ba7667a32ff9	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:46:14.002512+00	2026-03-21 17:46:14.002512+00	f
1	1	884aeb074b7c4a9195d61486a198427858804bcde4bb47ee7eeb637dfb81d842	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:06:13.29514+00	2026-03-20 20:06:13.29514+00	t
89	5	ad2ff0b7c68f936b01ced0dbe07c7d9344eb51861bfa5a8c4794c1951d7db75c	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:40:09.30311+00	2026-03-21 18:40:09.30311+00	t
3	1	1881a4e4783285f030a923a8d50bb9b5538f429d99bdbc02fad7e5d19608d63c	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:08:09.037476+00	2026-03-20 20:08:09.037476+00	t
4	1	7982beb144b058b49b1ef34ac016c8fc5a11b4fbe2614ed72698ebb38ef9c82e	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:11:36.233885+00	2026-03-20 20:11:36.233885+00	t
5	1	9999c400dac167e27706fb1963fd61dac86fd80c5541181c9f086d4e4eef60f2	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:14:20.509818+00	2026-03-20 20:14:20.509818+00	t
7	1	a5ecd69b73a764b8255b8f54e0a63bc35b5ce008cf61ebd04ccef6e7c92e34ce	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:18:03.345879+00	2026-03-20 20:18:03.345879+00	t
9	1	48619a33d9bae045243d10a58ebb342190486e9a4bd97060e9c5a0283943bd2a	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:21:27.075648+00	2026-03-20 20:21:27.075648+00	t
11	1	4ac9101e799d9b6921bd1f6fb28a4c449226b6912c53ca53c1f3a3c2029a47d9	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:23:09.641269+00	2026-03-20 20:23:09.641269+00	t
12	1	2d20ce1b95cc2f04a5fc4d019ae75993c471e03a78f12ac407c4b10e5344e679	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:30:25.504265+00	2026-03-20 20:30:25.504265+00	f
14	1	25ef5023a5a02154cad467ba04e3b4a93f1ff9a71aac1e01df6d8fa7328825da	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:34:45.494474+00	2026-03-20 20:34:45.494474+00	t
16	1	1dbecaa3840e64395e67deaa727da2d10153b9c7d756bea41d8903de8b755a0f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:41:36.997866+00	2026-03-20 20:41:36.997866+00	t
18	1	e74c55965ba51cd97e80da743aed12b5a4f33b80352639a54f1d11dfc36e031e	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:43:33.944065+00	2026-03-20 20:43:33.944065+00	t
21	1	7f7f1955d0a308f7f74ebf26a3a32172630906fc86fd0095d905a22504b128a7	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:54:29.124056+00	2026-03-20 20:54:29.124056+00	f
23	1	2a47eb399830f788912c959358acb837a0d148056830638a82008db207a7a5ff	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:28:44.670403+00	2026-03-20 21:28:44.670403+00	f
22	1	75f578fa67c904cb84235f0ea4ffbd9034eb7176292dabd1a465e78a46dc88b2	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:27:58.192579+00	2026-03-20 21:27:58.192579+00	t
2	5	89655ec75df573bf58a9b93dd5d84832a9ad7e0caaf5713eff1d134c84c74a85	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:07:22.757676+00	2026-03-20 20:07:22.757676+00	t
6	5	3a3fb1fc2692eae9b747e57298509488f4a3ecb7467094d1a6dc2b4acafcd84a	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:17:27.549295+00	2026-03-20 20:17:27.549295+00	t
8	5	6beb07fc271947cc43a4141635167e1b8276f813270d4ba8c1188da72e1793c2	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:19:28.55776+00	2026-03-20 20:19:28.55776+00	t
10	5	966a86d2f83b351f8b1bf46b06e42df2e1226c0ca8cb34540379355bb0ab9536	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:22:25.133799+00	2026-03-20 20:22:25.133799+00	t
13	5	f1d794de97c730b0aef61216572bc06fbfa0b059d9623f0b2fa1273319b2d3f4	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:30:38.218589+00	2026-03-20 20:30:38.218589+00	t
17	5	f8b628e776ff600bba115903cc9bd445a8e8427a17e8decf6cf58e19bdf09135	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:41:53.280041+00	2026-03-20 20:41:53.280041+00	t
24	1	78095587cb1cd35d2a5a422c833ec92ed36023eff727e03de35626e69680e5e5	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:32:51.332377+00	2026-03-20 21:32:51.332377+00	f
85	5	4b2a18636c22fc5a1bc5239060ba8fe52b7933b1175a8a4fd0cc8fe27df06d9f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:03:44.254124+00	2026-03-21 18:03:44.254124+00	f
25	1	8b54fbe65977c096ec30d172210f2659a8b634d067ea8f756c692e8f1a40d6b9	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:33:34.621737+00	2026-03-20 21:33:34.621737+00	t
26	1	395079f458a649715c83a564fccfeee8bfc93843a039b54e5ab0c237d684014c	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:43:43.409122+00	2026-03-20 21:43:43.409122+00	f
90	1	23f910bc9848195a173f8ed2b1178be10d26e90234f87e870628024a04c33d4b	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:51:51.416562+00	2026-03-21 18:51:51.416562+00	f
27	1	8fe5befcb2ffb681ed368c2df89189b61480b9f176b39ed2af735f218ecd8d15	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:44:40.279415+00	2026-03-20 21:44:40.279415+00	t
32	1	00201ed4c8790b79a007e787d0fc6f772c4bafd93c8ff12bdc050b59b0cbb05c	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:23:57.425682+00	2026-03-20 22:23:57.425682+00	t
40	1	63a34c8221d60c755d4f9460676bcdeb8e60ef18234549277e5d733837a6c634	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:47:26.897438+00	2026-03-20 22:47:26.897438+00	t
44	2	c616b1f0b7ebc07aeeb9280c596e030364f20d55f45dd3080fba536c115f8bb2	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:58:06.101033+00	2026-03-20 22:58:06.101033+00	t
45	4	6196173adbf3b8eb07e26458267b6dd189ebe9f75eace5933d1bb261877b3f27	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:59:10.689445+00	2026-03-20 22:59:10.689445+00	f
49	1	1b0fbf43d28fa363ec84c8c74ef054326bba4be40271f72e9756cec330b01ac9	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	2026-03-20 23:27:35.720514+00	2026-03-20 23:27:35.720514+00	f
29	5	97e2a6ffa55e1b73a4f426683cf513fb1f79e72c0e83193010775388613d25ad	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:50:29.882329+00	2026-03-20 21:50:29.882329+00	t
28	5	ec52e514ccff90e1f4cee21ae6b5095290eae0375373747c846a561bda61645d	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:48:51.503484+00	2026-03-20 21:48:51.503484+00	t
30	5	20df8e9dfa53738972262087408b9bf0eea22a73ce532f10f1b828ff2c5dcb57	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 21:51:17.807715+00	2026-03-20 21:51:17.807715+00	t
86	5	17d09a367df5d318d452fe9866657ff1797fd2a1dc5e0c7b16eb6e31b9b59e85	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:25:13.152413+00	2026-03-21 18:25:13.152413+00	f
91	1	5c92a1a15fc7264f384367b19d7f40aedb1d251e0805a6f6dba7f0743255d7e4	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:54:13.025755+00	2026-03-21 18:54:13.025755+00	f
52	4	a7dab64f063f30fd1b4da9b22283c37c5da0e94c4af9e714ea5dfc1337932b8c	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-20 23:37:41.578608+00	2026-03-20 23:37:41.578608+00	t
53	3	2fe181391d191e64699013ee108d745061ccbf3c6c57752e68fb3e4b77f8ec14	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 00:55:15.35395+00	2026-03-21 00:55:15.35395+00	t
54	1	52de55d807e7a01200b14efe5e4163ba01236496caab0c868fa16f71587b2c9c	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 00:56:18.369025+00	2026-03-21 00:56:18.369025+00	f
55	1	a2499372d489b030b6f2a0f6b5b203a918414b18b2e1014c59c08d50c8ff2858	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 10:57:24.568261+00	2026-03-21 10:57:24.568261+00	t
59	2	1bac9c7b54a990847b885db8536a671010710f7f1a347fc78a791b95b1ac1183	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 11:17:56.823328+00	2026-03-21 11:17:56.823328+00	t
60	4	9b862cd9ce70e4a2bb0732ee735a26b3756d4e6c4306e80fcaec62aa3f145d2e	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 11:18:44.512564+00	2026-03-21 11:18:44.512564+00	t
61	1	a2884bddab0ae25fa1272cb824e94a97c33083d30a6beaa5222edd2f9d858375	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 11:19:34.66669+00	2026-03-21 11:19:34.66669+00	t
66	2	ef9298ee3cf0366ef431261cfcd9e66ca7813076c6dabbd306ae64823ad83f0d	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:18:07.202057+00	2026-03-21 12:18:07.202057+00	t
70	2	c13554e6c44842a97c4cae26b4904538093df7295be9748251eb83524aae41f8	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:40:43.187579+00	2026-03-21 12:40:43.187579+00	f
73	2	c70e0fbf45e5748aeee2f00cc770f71034e191ec6e0fe4689d85ab8ac205ab0e	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:54:17.374351+00	2026-03-21 12:54:17.374351+00	t
76	2	30ef44d72c978c06bb0363767b481b370ca5373beeb1888f88a911308461bf6f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:08:05.422628+00	2026-03-21 17:08:05.422628+00	t
51	5	c3ff2a35503fa2b6119dc8ec39e99fb783c4504efa1691394067cf3e0f03cc0d	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-20 23:36:05.795963+00	2026-03-20 23:36:05.795963+00	t
87	5	ef1d95176794d1eda8343aebe279f07d1990c96b1cfd31a1c3630343fd64224e	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:31:14.003649+00	2026-03-21 18:31:14.003649+00	f
92	5	2d7fe2b0eac66fd25aeb875cf8627278b313b9603e220402047fb5e054cbfc7f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:54:39.28989+00	2026-03-21 18:54:39.28989+00	f
15	5	e3a0887ae7dab028ea37c3ebbce4cf4df893f568a84059377c5cfd3f7bcd4673	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:35:04.704087+00	2026-03-20 20:35:04.704087+00	t
20	5	15af13482903720df6039b974f96585fece370ceb76a38d5f6ca1e88940d0154	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:46:47.248685+00	2026-03-20 20:46:47.248685+00	t
19	5	98d3c7dc28392c5fe5ea25d69b49bc7bfc50b1edfa7f54e7bfe367784c4592d8	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 20:46:24.471359+00	2026-03-20 20:46:24.471359+00	t
31	5	ffa44ad905d872a1dcc8bd2c171894c7c87fca97a2e6caf1f0b04d206f30dca6	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:19:20.965285+00	2026-03-20 22:19:20.965285+00	t
34	5	8ad3fb0851b6820dee144b2a1bc80ee874c22d6de5af6c906bc25b95f6a5d4f7	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:27:33.811182+00	2026-03-20 22:27:33.811182+00	t
33	5	be05c9575e8c7b83c48e3b320fd91ae0eaae261affe816f103fbcbaba7e312af	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:24:10.917346+00	2026-03-20 22:24:10.917346+00	t
35	5	592155b14db08412861ce1e0eb26885c6584983a91fe2c68ec84badf43eeb975	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:35:48.810853+00	2026-03-20 22:35:48.810853+00	t
36	5	801b29e81c664df307936dd04c8e61a776c0d7aa0733631fd1815adb4e1a1ff5	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:36:10.027535+00	2026-03-20 22:36:10.027535+00	t
37	5	c9e9270e119621a8f90dd85c2f5475d2c5833e3619df14061cd02d49494eb456	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:38:17.207041+00	2026-03-20 22:38:17.207041+00	t
38	5	c6a3a03e419f6744f385011b0c6045cec467b770cd4b3cd7477c46167e60844e	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:40:14.28317+00	2026-03-20 22:40:14.28317+00	t
39	5	03d0154bf3d9900ecaf7e70126da554df36acb244241eddcc1ad0cca5cc4bede	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:40:41.284622+00	2026-03-20 22:40:41.284622+00	t
41	5	d8e5eff199cd8253fd34563190c32d0109a8143a5ced4f5382be44df87be4307	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:47:54.150503+00	2026-03-20 22:47:54.150503+00	t
42	5	b1050ff682a66d0c8917d3ffc321ee56a79a077f74b72f16902a41e4c9e3abe7	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:52:19.878236+00	2026-03-20 22:52:19.878236+00	t
43	5	5baea5b94550449af0c167fdd48efc47ff1626934405736a9d9526c5b8d54df2	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 22:57:09.344834+00	2026-03-20 22:57:09.344834+00	t
46	5	91e0a0b4b43186e078608317a8070eafd557f114aa18db66fd947b9b3d4d5d1b	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-20 23:02:40.548722+00	2026-03-20 23:02:40.548722+00	t
47	5	42c0e9a420b9e83afb92b31e133fe39e4af32c33a73f27831573f2d37056a09a	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-20 23:21:44.283284+00	2026-03-20 23:21:44.283284+00	t
48	5	52ea40c604d8eec52c2a04bbe086682ebaa0312de8562a1f27666ba64a8385e7	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-20 23:25:15.279933+00	2026-03-20 23:25:15.279933+00	t
50	5	282968678ae21b664cfd90e96451964eb236992ff95e05f416f381c21cd4c202	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	2026-03-20 23:27:56.347575+00	2026-03-20 23:27:56.347575+00	t
56	5	2434df209cdd934759cbbd84414d3cc57d98724dae3a04a278898f8893591f4b	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 10:58:51.978275+00	2026-03-21 10:58:51.978275+00	t
57	5	50cac9e3a7d312487c0c9467d4ecd03e2e751c3dc147de98376d3a2b1d16e8cd	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 11:00:47.407314+00	2026-03-21 11:00:47.407314+00	t
58	5	fe2c781c49cb269a502ed3635e6cf050047fe6d3b2388bfe5ab5ba4a2027cfd9	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 11:16:14.026174+00	2026-03-21 11:16:14.026174+00	t
62	5	179e1f4127bc441b91ca9cb9d0fb8ba1cd0ef900c7d43eda4e1a61377f23b53f	Telefon	172.18.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1	2026-03-21 12:07:34.026481+00	2026-03-21 12:07:34.026481+00	t
63	5	6c56a0b55da785d181f1d06ec0f2f2c31d5282d0f307f7c450ec00e746d14b7a	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:09:33.556893+00	2026-03-21 12:09:33.556893+00	t
64	5	e82e61f86d540588721213915a650fe1ec9795b8ea6e366ed3a867667782ae27	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:16:22.869553+00	2026-03-21 12:16:22.869553+00	t
65	5	141296f6325aebe57369db757170d9eacc5fea3621e8cd13067d0f2ee8207bf1	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:17:06.168703+00	2026-03-21 12:17:06.168703+00	t
81	5	cf201677a06f0b6999c3e9b0ed7d52e96e03a887f13dd3f39752f0a54e8c478f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:30:59.763675+00	2026-03-21 17:30:59.763675+00	t
67	5	5c0eecc460e787d5975ad1fa213b34474991c979a0501649c5b9de24a78aca54	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:20:29.157522+00	2026-03-21 12:20:29.157522+00	t
68	5	d21b12112fe57ec5d2f1a1d3c49a58870cedd4ae996b62d5902598d42e86eab9	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:38:14.969016+00	2026-03-21 12:38:14.969016+00	t
69	5	00b24567a5b0d5d927dde9bfaf3d51029b01152888cafc545cf63e1e321b2363	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:39:11.334459+00	2026-03-21 12:39:11.334459+00	t
71	5	adc36a05ec4141e1157f7a1a36ce8b2240ed7eed0388ec586f5fdfdd909f030d	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:52:35.9214+00	2026-03-21 12:52:35.9214+00	t
72	5	d5c2e7ad4e3d851f7ce1a7ea1d5d361d4227082b21df11821294a2b123b87d7f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 12:53:04.142822+00	2026-03-21 12:53:04.142822+00	t
74	5	eb02258d3e0f1cb5a2a7eed9f8607be36880070c0c8297d3efd465c4a54fda3a	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 13:00:34.730635+00	2026-03-21 13:00:34.730635+00	t
75	5	fa8dbad5332d8ed844d7e2218759de51dc6fe1fc489f44852cb30bdfbdc50ae6	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 16:57:47.363831+00	2026-03-21 16:57:47.363831+00	t
77	5	1b72b7f5cbb41a61a84c2c1d17f896dcf24d91cc2273ff9967e470725792595f	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:09:32.442847+00	2026-03-21 17:09:32.442847+00	t
78	5	05c719284e49948a8e4567adbcce9fbf356e7207117f4da5c2f079d810777d49	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:12:57.307527+00	2026-03-21 17:12:57.307527+00	t
79	5	a66dad8db5ea1dba6cd807d8fab0b6ab35812a813143d400e45016b9d9daf5a1	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:18:32.075216+00	2026-03-21 17:18:32.075216+00	t
80	5	bd46881868e78ba8218bf096fbb8ef92599203094168b47fe5e33975f39e7120	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:20:03.290845+00	2026-03-21 17:20:03.290845+00	t
82	5	8e969bea19cb0541c780133dd4d67981dbefc66911ac6e1771b22b2d225c9e04	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:36:18.035845+00	2026-03-21 17:36:18.035845+00	t
83	5	62b33ba0947e2f07cef52e7e69e35458cea2e58e6eacdbbf9185d7bbe2f841a3	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 17:38:07.651019+00	2026-03-21 17:38:07.651019+00	t
88	5	9e80e82a3a33403dfcfad092a1ef3fd31e4889a00e1d5a1309ea72d366658ab5	Desktop/Web	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-21 18:38:56.13799+00	2026-03-21 18:38:56.13799+00	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, last_name, email, password_hash, role, division_id, pda_number, created_at, team_leader_id, last_login, totp_secret, totp_enabled, totp_verified) FROM stdin;
1	Admin	User	admin@local	$2a$10$km7g285YmcPhd74bv3fXoeUnIEsX72g9.gDk105U6jGQo5b.rq40q	admin	1	\N	2026-03-20 20:05:15.34253+00	\N	2026-03-21 18:54:13.016054+00	\N	f	f
5	Agim	Agent	agent@local	$2a$10$V8mhBDMqEXhLG7o2tfJbV.o/cL6gvkRfqJHeVK2b/dnz2JczctaRy	agent	1	PDA-123	2026-03-20 20:05:15.352294+00	\N	2026-03-21 18:54:39.282653+00	\N	f	f
3	Diva	Manager	div@local	$2a$10$rfWD3NVTeF8RAhmuVtnnnOspM1SZYoYvoSzWUsqQuUX6pycz4L67i	division_manager	1	\N	2026-03-20 20:05:15.347579+00	\N	2026-03-21 00:55:15.34621+00	\N	f	f
4	Sale	Director	dir@local	$2a$10$9TaIQqGBT7AJfNw2MFjrR..5CogR2qdYuFmFkhX2uFYPnu29TX9gS	sales_director	\N	\N	2026-03-20 20:05:15.350021+00	\N	2026-03-21 11:18:44.506736+00	\N	f	f
2	Tea	Lead	lead@local	$2a$10$q6W7V7tvi7QhUfQBuAzlyucZJgUiDIuX9NbX8PQte5EvoHluKBlEm	team_lead	1	\N	2026-03-20 20:05:15.345266+00	\N	2026-03-21 17:08:05.414809+00	\N	f	f
\.


--
-- Name: agent_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agent_limits_id_seq', 2, true);


--
-- Name: approval_delegations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approval_delegations_id_seq', 1, false);


--
-- Name: approval_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approval_thresholds_id_seq', 8, true);


--
-- Name: approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approvals_id_seq', 6, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 84280, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 3, true);


--
-- Name: buyer_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buyer_sites_id_seq', 47362, true);


--
-- Name: buyers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buyers_id_seq', 106554, true);


--
-- Name: divisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.divisions_id_seq', 222, true);


--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ip_whitelist_id_seq', 1, false);


--
-- Name: known_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.known_devices_id_seq', 16, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 92, true);


--
-- Name: report_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_runs_id_seq', 1, false);


--
-- Name: request_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.request_comments_id_seq', 2, true);


--
-- Name: request_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.request_items_id_seq', 22, true);


--
-- Name: request_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.request_photos_id_seq', 31, true);


--
-- Name: requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requests_id_seq', 22, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 92, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: agent_limits agent_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_limits
    ADD CONSTRAINT agent_limits_pkey PRIMARY KEY (id);


--
-- Name: agent_limits agent_limits_user_id_period_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_limits
    ADD CONSTRAINT agent_limits_user_id_period_key UNIQUE (user_id, period);


--
-- Name: approval_delegations approval_delegations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_delegations
    ADD CONSTRAINT approval_delegations_pkey PRIMARY KEY (id);


--
-- Name: approval_thresholds approval_thresholds_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_thresholds
    ADD CONSTRAINT approval_thresholds_key_key UNIQUE (key);


--
-- Name: approval_thresholds approval_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_thresholds
    ADD CONSTRAINT approval_thresholds_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_sku_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_sku_key UNIQUE (sku);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: buyer_sites buyer_sites_buyer_id_site_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyer_sites
    ADD CONSTRAINT buyer_sites_buyer_id_site_code_key UNIQUE (buyer_id, site_code);


--
-- Name: buyer_sites buyer_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyer_sites
    ADD CONSTRAINT buyer_sites_pkey PRIMARY KEY (id);


--
-- Name: buyers buyers_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers
    ADD CONSTRAINT buyers_code_key UNIQUE (code);


--
-- Name: buyers buyers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyers
    ADD CONSTRAINT buyers_pkey PRIMARY KEY (id);


--
-- Name: divisions divisions_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_name_key UNIQUE (name);


--
-- Name: divisions divisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_pkey PRIMARY KEY (id);


--
-- Name: ip_whitelist ip_whitelist_cidr_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_cidr_key UNIQUE (cidr);


--
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- Name: known_devices known_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.known_devices
    ADD CONSTRAINT known_devices_pkey PRIMARY KEY (id);


--
-- Name: known_devices known_devices_user_id_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.known_devices
    ADD CONSTRAINT known_devices_user_id_fingerprint_key UNIQUE (user_id, fingerprint);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: report_runs report_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_runs
    ADD CONSTRAINT report_runs_pkey PRIMARY KEY (id);


--
-- Name: request_comments request_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_comments
    ADD CONSTRAINT request_comments_pkey PRIMARY KEY (id);


--
-- Name: request_items request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_items
    ADD CONSTRAINT request_items_pkey PRIMARY KEY (id);


--
-- Name: request_photos request_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_photos
    ADD CONSTRAINT request_photos_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_approvals_approver; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_approver ON public.approvals USING btree (approver_id);


--
-- Name: idx_approvals_approver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_approver_id ON public.approvals USING btree (approver_id);


--
-- Name: idx_approvals_approver_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_approver_role ON public.approvals USING btree (approver_role);


--
-- Name: idx_approvals_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_role ON public.approvals USING btree (approver_role);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_comments_request; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_request ON public.request_comments USING btree (request_id);


--
-- Name: idx_delegations_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegations_active ON public.approval_delegations USING btree (active, start_date, end_date);


--
-- Name: idx_delegations_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_delegations_from ON public.approval_delegations USING btree (from_user_id);


--
-- Name: idx_known_devices_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_known_devices_user ON public.known_devices USING btree (user_id);


--
-- Name: idx_refresh_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: idx_request_items_req; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_request_items_req ON public.request_items USING btree (request_id);


--
-- Name: idx_request_photos_req; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_request_photos_req ON public.request_photos USING btree (request_id);


--
-- Name: idx_requests_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_agent_id ON public.requests USING btree (agent_id);


--
-- Name: idx_requests_assigned; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_assigned ON public.requests USING btree (assigned_to_user_id);


--
-- Name: idx_requests_assigned_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_assigned_to ON public.requests USING btree (assigned_to_user_id);


--
-- Name: idx_requests_required_role_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_required_role_status ON public.requests USING btree (required_role, status);


--
-- Name: idx_requests_role_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_role_status ON public.requests USING btree (required_role, status);


--
-- Name: idx_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requests_status ON public.requests USING btree (status);


--
-- Name: idx_sessions_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_active ON public.user_sessions USING btree (revoked, last_active);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_token ON public.user_sessions USING btree (token_hash);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: agent_limits agent_limits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_limits
    ADD CONSTRAINT agent_limits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_delegations approval_delegations_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_delegations
    ADD CONSTRAINT approval_delegations_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_delegations approval_delegations_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_delegations
    ADD CONSTRAINT approval_delegations_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: approval_thresholds approval_thresholds_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_thresholds
    ADD CONSTRAINT approval_thresholds_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approvals approvals_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);


--
-- Name: approvals approvals_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: buyer_sites buyer_sites_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buyer_sites
    ADD CONSTRAINT buyer_sites_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.buyers(id) ON DELETE CASCADE;


--
-- Name: divisions divisions_default_team_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_default_team_leader_id_fkey FOREIGN KEY (default_team_leader_id) REFERENCES public.users(id);


--
-- Name: ip_whitelist ip_whitelist_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: known_devices known_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.known_devices
    ADD CONSTRAINT known_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: request_comments request_comments_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_comments
    ADD CONSTRAINT request_comments_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON DELETE CASCADE;


--
-- Name: request_comments request_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_comments
    ADD CONSTRAINT request_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: request_items request_items_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_items
    ADD CONSTRAINT request_items_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.articles(id);


--
-- Name: request_items request_items_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_items
    ADD CONSTRAINT request_items_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON DELETE CASCADE;


--
-- Name: request_photos request_photos_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_photos
    ADD CONSTRAINT request_photos_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(id) ON DELETE CASCADE;


--
-- Name: requests requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: requests requests_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.articles(id);


--
-- Name: requests requests_assigned_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_assigned_to_user_id_fkey FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id);


--
-- Name: requests requests_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.buyers(id);


--
-- Name: requests requests_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.divisions(id);


--
-- Name: requests requests_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.buyer_sites(id);


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.divisions(id);


--
-- Name: users users_team_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_leader_id_fkey FOREIGN KEY (team_leader_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7nuy2SeBmTWmezfPM5gg1MPVPuFLsFTJbbAdc4XykThMxDOVhBvlWYFxVX5rg1f

